// Copie le moteur OCR, les langues et le lecteur PDF dans public/ pour qu'ils soient DANS l'APK.
import fs from "node:fs";
import path from "node:path";

const nm = "node_modules";
const out = "public";

function copy(from, to) {
  if (!fs.existsSync(from)) {
    console.warn("MANQUANT:", from);
    return false;
  }
  fs.mkdirSync(path.dirname(to), { recursive: true });
  fs.copyFileSync(from, to);
  console.log("OK:", to);
  return true;
}

function findFile(dir, name) {
  if (!fs.existsSync(dir)) return null;
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      const hit = findFile(full, name);
      if (hit) return hit;
    } else if (entry.name === name) return full;
  }
  return null;
}

const tdist = path.join(nm, "tesseract.js", "dist");
copy(path.join(tdist, "tesseract.min.js"), path.join(out, "tesseract", "tesseract.min.js"));
copy(path.join(tdist, "worker.min.js"), path.join(out, "tesseract", "worker.min.js"));

const core = path.join(nm, "tesseract.js-core");
if (fs.existsSync(core)) {
  for (const f of fs.readdirSync(core)) {
    if (/^tesseract-core.*\.(js|wasm)$/.test(f)) copy(path.join(core, f), path.join(out, "tesseract", f));
  }
}

for (const lang of ["eng", "fra", "spa", "deu", "por", "ita", "ara", "chi_sim", "swa"]) {
  const file = findFile(path.join(nm, "@tesseract.js-data", lang), `${lang}.traineddata.gz`);
  if (file) copy(file, path.join(out, "tessdata", `${lang}.traineddata.gz`));
  else console.warn("Langue OCR absente:", lang);
}

const pdf = path.join(nm, "pdfjs-dist", "build");
copy(path.join(pdf, "pdf.min.mjs"), path.join(out, "pdfjs", "pdf.min.mjs"));
copy(path.join(pdf, "pdf.worker.min.mjs"), path.join(out, "pdfjs", "pdf.worker.min.mjs"));

// Whisper (transcription hors ligne) : moteur + fichiers wasm
const tfDist = path.join(nm, "@huggingface", "transformers", "dist");
const tfFile = ["transformers.web.min.js", "transformers.min.js"].find((f) => fs.existsSync(path.join(tfDist, f)));
if (tfFile) copy(path.join(tfDist, tfFile), path.join(out, "whisper", "transformers.js"));
else console.warn("MANQUANT: transformers.js");
for (const dir of [tfDist, path.join(nm, "onnxruntime-web", "dist"), path.join(nm, "@huggingface", "transformers", "node_modules", "onnxruntime-web", "dist")]) {
  if (!fs.existsSync(dir)) continue;
  for (const f of fs.readdirSync(dir)) {
    if (/^ort-wasm-simd-threaded.*\.(wasm|mjs)$/.test(f)) copy(path.join(dir, f), path.join(out, "ort", f));
  }
}
