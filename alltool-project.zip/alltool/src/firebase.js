import {initializeApp} from 'firebase/app';
import {getAuth,createUserWithEmailAndPassword,signInWithEmailAndPassword,onAuthStateChanged} from 'firebase/auth';
import {getFirestore,doc,getDoc,setDoc,updateDoc} from 'firebase/firestore';
const app=initializeApp({apiKey:"AIzaSyADpl3JgmItKe_NMXRDkpHrSwS0qwJ7aNs",authDomain:"alltool-1a8e6.firebaseapp.com",projectId:"alltool-1a8e6",storageBucket:"alltool-1a8e6.firebasestorage.app",messagingSenderId:"332529144114",appId:"1:332529144114:web:a6932cdc8a5ed2eb6cc72b"});
export const auth=getAuth(app),db=getFirestore(app);
export const onUser=cb=>onAuthStateChanged(auth,cb);
export async function signUpOrIn(name,email,pw){
  try{const c=await createUserWithEmailAndPassword(auth,email,pw);
    await setDoc(doc(db,'users',c.user.uid),{name,email,premium:false,premiumUntil:null,usage:{}});return c.user;
  }catch(e){if(e.code==='auth/email-already-in-use')return (await signInWithEmailAndPassword(auth,email,pw)).user;throw e}}
export const loadProfile=async u=>{const s=await getDoc(doc(db,'users',u.uid));return s.exists()?s.data():{name:'',premium:false,usage:{}}};
export const saveUsage=(u,usage)=>updateDoc(doc(db,'users',u.uid),{usage});
