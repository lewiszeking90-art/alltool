import {createWorker} from 'tesseract.js';
import * as pdfjs from 'pdfjs-dist/legacy/build/pdf.js';
import {pipeline,env} from '@xenova/transformers';
pdfjs.GlobalWorkerOptions.workerSrc=location.origin+'/pdf.worker.min.js';
env.allowRemoteModels=false;env.allowLocalModels=true;env.localModelPath=location.origin+'/models/';
env.backends.onnx.wasm.wasmPaths=location.origin+'/ort/';env.backends.onnx.wasm.numThreads=1;
const vmime=()=>['video/webm;codecs=vp9,opus','video/webm;codecs=vp8,opus','video/webm','video/mp4'].find(m=>MediaRecorder.isTypeSupported(m));
const loadVid=f=>new Promise((res,rej)=>{const v=document.createElement('video');v.playsInline=true;v.preload='auto';v.src=URL.createObjectURL(f);v.onloadedmetadata=()=>res(v);v.onerror=()=>rej(new Error('Vidéo illisible'))});
const loadImg=f=>new Promise((r,j)=>{const i=new Image();i.onload=()=>r(i);i.onerror=j;i.src=URL.createObjectURL(f)});
// Ré-encode 1..n vidéos : l'audio passe par WebAudio (une seule piste continue) => son synchronisé à chaque raccord
async function recode(files,kbps,maxH,c){
  const vids=[];for(const f of files)vids.push(await loadVid(f));
  const total=vids.reduce((a,v)=>a+v.duration,0),H=Math.min(maxH,vids[0].videoHeight),W=Math.round(vids[0].videoWidth*H/vids[0].videoHeight/2)*2;
  const cv=document.createElement('canvas');cv.width=W;cv.height=H;const x=cv.getContext('2d');
  const ac=new AudioContext(),dest=ac.createMediaStreamDestination();
  vids.forEach(v=>ac.createMediaElementSource(v).connect(dest));
  const st=new MediaStream([...cv.captureStream(30).getVideoTracks(),...dest.stream.getAudioTracks()]);
  const rec=new MediaRecorder(st,{mimeType:vmime(),videoBitsPerSecond:kbps*1000,audioBitsPerSecond:96000});
  const parts=[];rec.ondataavailable=e=>e.data.size&&parts.push(e.data);
  const stopped=new Promise(r=>rec.onstop=r);rec.start(1000);let before=0;
  try{await ac.resume();
    for(const v of vids){await v.play();
      await new Promise((res,rej)=>{const draw=()=>{
        if(c.signal.aborted){v.pause();return rej(new Error('Annulée'))}
        const s=Math.min(W/v.videoWidth,H/v.videoHeight),w=v.videoWidth*s,h=v.videoHeight*s;
        x.fillStyle='#000';x.fillRect(0,0,W,H);x.drawImage(v,(W-w)/2,(H-h)/2,w,h);
        c.progress((before+v.currentTime)/total*.98);
        v.ended?res():setTimeout(draw,33)};draw()});
      before+=v.duration}
  }finally{if(rec.state!=='inactive')rec.stop();await stopped;ac.close()}
  return new Blob(parts,{type:rec.mimeType.split(';')[0]});
}
const ext=m=>m.includes('mp4')?'mp4':'webm';
async function pages(f,c,gray){
  let cvs=[];
  if(f.type==='application/pdf'||/\.pdf$/i.test(f.name)){const d=await pdfjs.getDocument({data:await f.arrayBuffer()}).promise;
    for(let i=1;i<=d.numPages;i++){const p=await d.getPage(i),vp=p.getViewport({scale:2}),cv=document.createElement('canvas');
      cv.width=vp.width;cv.height=vp.height;await p.render({canvasContext:cv.getContext('2d'),viewport:vp}).promise;cvs.push(cv);c.check()}}
  else{const im=await loadImg(f),cv=document.createElement('canvas');cv.width=im.width;cv.height=im.height;cv.getContext('2d').drawImage(im,0,0);cvs=[cv]}
  if(gray)cvs=cvs.map(s=>{const o=document.createElement('canvas');o.width=s.width;o.height=s.height;const x=o.getContext('2d');x.filter='grayscale(1) contrast(1.7) brightness(1.05)';x.drawImage(s,0,0);return o});
  return cvs}
async function ocr(f,lang,c,gray){
  const B=location.origin+'/tess/',w=await createWorker(lang,1,{workerPath:B+'worker.min.js',corePath:B,langPath:B,workerBlobURL:false});
  try{const ps=await pages(f,c,gray);let out=[];
    for(let i=0;i<ps.length;i++){c.check();out.push((await w.recognize(ps[i])).data.text);c.progress((i+1)/ps.length)}
    const text=out.join('\n\n').trim();if(!text)throw new Error('Aucun texte reconnu');
    return{text,blob:new Blob([text],{type:'text/plain'}),name:'texte.txt',mime:'text/plain',label:'Texte'}
  }finally{await w.terminate()}}
const srtT=s=>{const p=(n,l=2)=>String(Math.floor(n)).padStart(l,'0'),h=s/3600,m=s%3600/60,q=s%60;return `${p(h)}:${p(m)}:${p(q)},${p((s%1)*1000,3)}`};
let asr;
async function transcribe(f,language,c){
  if(!f)throw new Error('Aucun fichier audio');c.progress(.05);
  const ac=new AudioContext({sampleRate:16000}),a=await ac.decodeAudioData(await f.arrayBuffer());c.check();c.progress(.15);
  asr=asr||await pipeline('automatic-speech-recognition','whisper-tiny',{quantized:true});c.check();c.progress(.3);c.touch();
  const r=await asr(a.getChannelData(0),{language,task:'transcribe',chunk_length_s:30,stride_length_s:5,return_timestamps:true});
  const ch=r.chunks||[{text:r.text,timestamp:[0,a.duration]}];
  const srt=ch.map((k,i)=>`${i+1}\n${srtT(k.timestamp[0])} --> ${srtT(k.timestamp[1]??a.duration)}\n${k.text.trim()}\n`).join('\n');
  c.progress(1);return{text:r.text.trim(),blob:new Blob([srt],{type:'application/x-subrip'}),name:'sous-titres.srt',mime:'application/x-subrip',label:'Sous-titres'}}
const LG=[['french','Français'],['english','English'],['spanish','Español'],['german','Deutsch'],['portuguese','Português'],['italian','Italiano'],['arabic','العربية'],['chinese','中文'],['swahili','Kiswahili'],['lingala','Lingála']];
export const EXTRA=[
{id:'compress',icon:'🗜️',name:'Compresseur de vidéo',inputs:[{k:'files',type:'file',accept:'video/*'},{k:'q',type:'select',label:'Qualité',opts:[['500','Petite taille'],['1000','Équilibrée'],['2000','Haute']]}],
 async run({files,q},c){const f=files[0];if(!f)throw new Error('Choisis une vidéo');const b=await recode([f],+q,720,c);
  if(b.size>=f.size)return{blob:f,name:f.name,mime:f.type,label:'Vidéo',note:'Vidéo déjà légère : original conservé'};
  return{blob:b,name:'compresse.'+ext(b.type),mime:b.type,label:'Vidéo'}}},
{id:'merge',icon:'🎞️',name:'Fusion de vidéos',inputs:[{k:'files',type:'file',accept:'video/*',multiple:true}],
 async run({files},c){if(files.length<2)throw new Error('Choisis au moins 2 vidéos');const b=await recode(files,2000,720,c);
  return{blob:b,name:'fusion.'+ext(b.type),mime:b.type,label:'Vidéo'}}},
{id:'ocr',icon:'🔎',name:'Texte d\'une photo / PDF (OCR)',inputs:[{k:'files',type:'file',accept:'image/*,application/pdf'}],
 run:({files},c)=>ocr(files[0],'fra+eng',c,false)},
{id:'hand',icon:'✍️',name:'Lecture de manuscrit',inputs:[{k:'files',type:'file',accept:'image/*,application/pdf'}],
 run:({files},c)=>ocr(files[0],'fra+eng',c,true)},
{id:'stt',icon:'📝',name:'Transcription + sous-titres',inputs:[{k:'files',type:'file',accept:'audio/*,video/*'},{k:'lang',type:'select',label:'Langue parlée',opts:LG}],
 run:({files,lang},c)=>transcribe(files[0],lang,c)},
{id:'mic',icon:'🎙️',name:'Micro → texte',inputs:[{k:'mic',type:'mic'},{k:'lang',type:'select',label:'Langue parlée',opts:LG}],
 run:({mic,lang},c)=>transcribe(mic,lang,c)}
];
