import {jsPDF} from 'jspdf';
import {TextToSpeech} from '@capacitor-community/text-to-speech';
const fileURL=f=>URL.createObjectURL(f);
const img=f=>new Promise((r,j)=>{const i=new Image();i.onload=()=>r(i);i.onerror=j;i.src=fileURL(f)});
const toBlob=(c,type='image/png',q)=>new Promise(r=>c.toBlob(r,type,q));
const guess=t=>/[\u0600-\u06FF]/.test(t)?'ar-SA':/[\u4e00-\u9fff]/.test(t)?'zh-CN':null;
export const TOOLS=[
{id:'img2pdf',icon:'🖼️',name:'Images → PDF',inputs:[{k:'files',type:'file',accept:'image/*',multiple:true}],
 async run({files},c){const pdf=new jsPDF();for(let i=0;i<files.length;i++){c.check();const im=await img(files[i]);
  const cv=document.createElement('canvas');cv.width=im.width;cv.height=im.height;cv.getContext('2d').drawImage(im,0,0);
  const w=210,h=Math.min(297,w*im.height/im.width);if(i)pdf.addPage();pdf.addImage(cv.toDataURL('image/jpeg',.85),'JPEG',0,0,w,h);c.progress((i+1)/files.length)}
  return{blob:pdf.output('blob'),name:'images.pdf',mime:'application/pdf',label:'PDF'}}},
{id:'combine',icon:'🧩',name:'Combiner des images',inputs:[{k:'files',type:'file',accept:'image/*',multiple:true}],
 async run({files},c){const ims=[];for(const f of files){ims.push(await img(f));c.check()}
  const W=Math.max(...ims.map(i=>i.width));const H=ims.reduce((a,i)=>a+i.height*W/i.width,0);
  const cv=document.createElement('canvas');cv.width=W;cv.height=H;const x=cv.getContext('2d');let y=0;
  ims.forEach((i,n)=>{const h=i.height*W/i.width;x.drawImage(i,0,y,W,h);y+=h;c.progress((n+1)/ims.length)});
  return{blob:await toBlob(cv),name:'combine.png',mime:'image/png',label:'Image'}}},
{id:'enhance',icon:'✨',name:'Améliorer une image',inputs:[{k:'files',type:'file',accept:'image/*'}],
 async run({files},c){const im=await img(files[0]);const s=Math.min(2,4096/Math.max(im.width,im.height));
  const cv=document.createElement('canvas');cv.width=im.width*s;cv.height=im.height*s;const x=cv.getContext('2d');
  x.imageSmoothingQuality='high';x.filter='contrast(1.08) saturate(1.12) brightness(1.03)';x.drawImage(im,0,0,cv.width,cv.height);c.progress(1);
  return{blob:await toBlob(cv,'image/jpeg',.92),name:'amelioree.jpg',mime:'image/jpeg',label:'Image'}}},
{id:'txt2pdf',icon:'📄',name:'Texte → PDF',inputs:[{k:'text',type:'text'}],
 async run({text},c){const p=new jsPDF();p.text(p.splitTextToSize(text,180),15,20);c.progress(1);
  return{blob:p.output('blob'),name:'texte.pdf',mime:'application/pdf',label:'PDF'}}},
{id:'audio',icon:'🎧',name:'Vidéo → Audio (WAV)',inputs:[{k:'files',type:'file',accept:'video/*'}],
 async run({files},c){const buf=await files[0].arrayBuffer();c.check();
  const ac=new (window.AudioContext||window.webkitAudioContext)();const a=await ac.decodeAudioData(buf);c.progress(.6);
  const n=a.length,ch=Math.min(2,a.numberOfChannels),out=new DataView(new ArrayBuffer(44+n*ch*2));
  const s=(o,t)=>[...t].forEach((q,i)=>out.setUint8(o+i,q.charCodeAt(0)));
  s(0,'RIFF');out.setUint32(4,36+n*ch*2,true);s(8,'WAVEfmt ');out.setUint32(16,16,true);out.setUint16(20,1,true);out.setUint16(22,ch,true);
  out.setUint32(24,a.sampleRate,true);out.setUint32(28,a.sampleRate*ch*2,true);out.setUint16(32,ch*2,true);out.setUint16(34,16,true);s(36,'data');out.setUint32(40,n*ch*2,true);
  const d=[...Array(ch).keys()].map(i=>a.getChannelData(i));let o=44;
  for(let i=0;i<n;i++)for(let k=0;k<ch;k++){out.setInt16(o,Math.max(-1,Math.min(1,d[k][i]))*32767,true);o+=2}
  c.progress(1);return{blob:new Blob([out],{type:'audio/wav'}),name:'audio.wav',mime:'audio/wav',label:'Audio'}}},
{id:'tts',icon:'🔊',name:'Texte → Voix',inputs:[{k:'text',type:'text'}],
 async run({text},c,L){await TextToSpeech.speak({text,lang:guess(text)||({fr:'fr-FR',en:'en-US',es:'es-ES',de:'de-DE',pt:'pt-PT',it:'it-IT',ar:'ar-SA',zh:'zh-CN'}[L]||'fr-FR')});c.progress(1);return null}},
{id:'translate',icon:'🌍',name:'Traduction (internet)',inputs:[{k:'text',type:'text'},{k:'to',type:'lang'}],
 async run({text,to},c){const r=await fetch('https://api.mymemory.translated.net/get?q='+encodeURIComponent(text.slice(0,450))+'&langpair=Autodetect|'+to,{signal:c.signal});
  const j=await r.json();c.progress(1);return{text:j.responseData.translatedText}}},
{id:'video',icon:'⬇️',name:'Télécharger une vidéo',inputs:[{k:'text',type:'link'},{k:'server',type:'server'}],
 async run({text,server},c){if(!server)throw new Error('URL du serveur manquante');
  const r=await fetch(server.replace(/\/$/,'')+'/dl?url='+encodeURIComponent(text),{signal:c.signal});if(!r.ok)throw new Error('Serveur: '+r.status);
  const tot=+r.headers.get('content-length')||0,rd=r.body.getReader(),parts=[];let got=0;
  for(;;){const{done,value}=await rd.read();if(done)break;parts.push(value);got+=value.length;c.progress(tot?got/tot:.5);c.touch()}
  return{blob:new Blob(parts,{type:'video/mp4'}),name:'video.mp4',mime:'video/mp4',label:'Vidéo'}}}
];
