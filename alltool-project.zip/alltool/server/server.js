// Serveur de téléchargement : node server.js  (nécessite yt-dlp + ffmpeg installés)
const http=require('http'),{spawn}=require('child_process');
const KEY=process.env.ALLTOOL_KEY||'';
http.createServer((req,res)=>{
  const u=new URL(req.url,'http://x');res.setHeader('Access-Control-Allow-Origin','*');
  if(u.pathname!=='/dl'||(KEY&&u.searchParams.get('key')!==KEY)){res.statusCode=404;return res.end();}
  const link=u.searchParams.get('url')||'';
  if(!/^https?:\/\//.test(link)){res.statusCode=400;return res.end('bad url');}
  res.setHeader('Content-Type','video/mp4');
  const p=spawn('yt-dlp',['-f','mp4/best','-o','-','--no-playlist',link]);
  p.stdout.pipe(res);p.on('error',()=>res.end());req.on('close',()=>p.kill());
}).listen(process.env.PORT||8080);
