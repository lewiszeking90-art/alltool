# Activer les comptes (Firebase, gratuit)

1. console.firebase.google.com → Ajouter un projet.
2. Build → Authentication → Commencer → activer « E-mail/Mot de passe ».
3. Build → Firestore Database → Créer (mode production).
4. Firestore → Règles → coller :

rules_version = '2';
service cloud.firestore {
  match /databases/{db}/documents {
    match /users/{uid} {
      allow read: if request.auth != null && request.auth.uid == uid;
      allow create: if request.auth != null && request.auth.uid == uid && request.resource.data.premium == false;
      allow update: if request.auth != null && request.auth.uid == uid
        && request.resource.data.diff(resource.data).affectedKeys().hasOnly(['name', 'usage']);
    }
  }
}

5. Paramètres du projet → Vos applications → ajouter une app Web (</>) → copier les valeurs
   (apiKey, authDomain, projectId, storageBucket, messagingSenderId, appId) dans un fichier nommé
   firebaseConfig.ts (même contenu que src/firebaseConfig.ts) et l'envoyer à la RACINE du dépôt GitHub,
   à côté de alltool-project.zip : le build l'utilisera automatiquement.
6. Pour activer Premium à quelqu'un : Firestore → users → son document → champ premium = true
   (et premiumUntil = date de fin, type timestamp). Désactiver : premium = false.
