import { createContext, useContext, useEffect, useMemo, useState } from "react";
import type { ReactNode } from "react";
import {
  createUserWithEmailAndPassword,
  onAuthStateChanged,
  sendPasswordResetEmail,
  signInWithEmailAndPassword,
  signOut as fbSignOut,
  updateProfile,
} from "firebase/auth";
import { doc, onSnapshot, serverTimestamp, setDoc } from "firebase/firestore";
import { auth, authEnabled, db } from "./lib/firebase";

export type AccountUser = { uid: string; name: string; email: string };
export type PremiumState = { active: boolean; until: number | null };

type AuthApi = {
  enabled: boolean;
  loading: boolean;
  user: AccountUser | null;
  premium: PremiumState;
  remoteUsage: Record<string, number> | null;
  pushUsage: (usage: Record<string, number>) => void;
  signUp: (name: string, email: string, password: string) => Promise<void>;
  signIn: (email: string, password: string) => Promise<void>;
  signOut: () => Promise<void>;
  reset: (email: string) => Promise<void>;
};

const Ctx = createContext<AuthApi | null>(null);
const NO_PREMIUM: PremiumState = { active: false, until: null };

function evalPremium(data: { premium?: boolean; premiumUntil?: { toMillis?: () => number } | number | null } | undefined): PremiumState {
  if (!data || data.premium !== true) return NO_PREMIUM;
  const raw = data.premiumUntil;
  const until = typeof raw === "number" ? raw : raw && typeof raw.toMillis === "function" ? raw.toMillis() : null;
  if (until && until < Date.now()) return NO_PREMIUM;
  return { active: true, until };
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [loading, setLoading] = useState(authEnabled);
  const [user, setUser] = useState<AccountUser | null>(null);
  const [premium, setPremium] = useState<PremiumState>(NO_PREMIUM);
  const [remoteUsage, setRemoteUsage] = useState<Record<string, number> | null>(null);

  useEffect(() => {
    if (!auth) return;
    return onAuthStateChanged(auth, (u) => {
      setUser(u ? { uid: u.uid, name: u.displayName || "", email: u.email || "" } : null);
      if (!u) setPremium(NO_PREMIUM);
      setLoading(false);
    });
  }, []);

  useEffect(() => {
    if (!db || !user) return;
    const cacheKey = `alltool-premium-${user.uid}`;
    try {
      const cached = localStorage.getItem(cacheKey);
      if (cached) setPremium(JSON.parse(cached) as PremiumState);
    } catch {
      /* ignore */
    }
    return onSnapshot(
      doc(db, "users", user.uid),
      (snap) => {
        const state = evalPremium(snap.data());
        setPremium(state);
        const u = snap.data()?.usage;
        if (u && typeof u === "object") setRemoteUsage(u as Record<string, number>);
        try {
          localStorage.setItem(cacheKey, JSON.stringify(state));
        } catch {
          /* ignore */
        }
      },
      () => undefined,
    );
  }, [user?.uid]);

  const api = useMemo<AuthApi>(
    () => ({
      enabled: authEnabled,
      loading,
      user,
      premium,
      remoteUsage,
      pushUsage: (usage) => {
        if (!db || !user || !Object.keys(usage).length) return;
        void setDoc(doc(db, "users", user.uid), { usage }, { merge: true }).catch(() => undefined);
      },
      signUp: async (name, email, password) => {
        if (!auth || !db) return;
        const cred = await createUserWithEmailAndPassword(auth, email.trim(), password);
        await updateProfile(cred.user, { displayName: name.trim() });
        setUser({ uid: cred.user.uid, name: name.trim(), email: cred.user.email || email.trim() });
        try {
          await setDoc(doc(db, "users", cred.user.uid), {
            name: name.trim(),
            email: cred.user.email || email.trim(),
            premium: false,
            createdAt: serverTimestamp(),
          });
        } catch {
          /* le profil sera recréé à la prochaine connexion */
        }
      },
      signIn: async (email, password) => {
        if (!auth) return;
        await signInWithEmailAndPassword(auth, email.trim(), password);
      },
      signOut: async () => {
        if (auth) await fbSignOut(auth);
      },
      reset: async (email) => {
        if (auth) await sendPasswordResetEmail(auth, email.trim());
      },
    }),
    [loading, user, premium, remoteUsage],
  );

  return <Ctx.Provider value={api}>{children}</Ctx.Provider>;
}

export function useAuth() {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("auth");
  return ctx;
}
