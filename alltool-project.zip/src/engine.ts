import type { QueueItem, RunCtx, StoredResult, TaskResult, ToolId } from "./types";
import { AppError, abortError, idbSet, isAbort, notify, uid } from "./lib/util";

export type EngineTask = {
  tool: ToolId;
  title: string;
  run: (ctx: RunCtx & { finish: AbortSignal }) => Promise<TaskResult>;
};

type Listener = (items: QueueItem[]) => void;

type Live = { abort: AbortController; finish: AbortController };

const items: QueueItem[] = [];
const lives = new Map<string, Live>();
const pending = new Map<string, EngineTask>();
const memory = new Map<string, { stored: StoredResult; blob?: Blob; extras: { blob: Blob; fileName: string; labelKey: string }[] }>();
const listeners = new Set<Listener>();
let pumping = false;
let onDone: (item: QueueItem, stored: StoredResult) => void = () => undefined;
let onFail: (item: QueueItem, key: string, detail: string) => void = () => undefined;

function emit() {
  const snap = items.map((i) => ({ ...i }));
  listeners.forEach((fn) => fn(snap));
}

function patch(id: string, partial: Partial<QueueItem>) {
  const hit = items.find((i) => i.id === id);
  if (!hit) return;
  Object.assign(hit, partial);
  emit();
}

export function bindEngine(handlers: { onDone: typeof onDone; onFail: typeof onFail }) {
  onDone = handlers.onDone;
  onFail = handlers.onFail;
}

export function subscribe(listener: Listener) {
  listeners.add(listener);
  listener(items.map((i) => ({ ...i })));
  return () => {
    listeners.delete(listener);
  };
}

export function remember(id: string) {
  return memory.get(id);
}

export function startTask(task: EngineTask) {
  const id = uid();
  lives.set(id, { abort: new AbortController(), finish: new AbortController() });
  pending.set(id, task);
  items.unshift({
    id,
    tool: task.tool,
    title: task.title,
    status: "queued",
    progress: 0,
    createdAt: Date.now(),
  });
  emit();
  kick();
  return id;
}

export function cancelTask(id: string) {
  lives.get(id)?.abort.abort();
  pending.delete(id);
  const hit = items.find((i) => i.id === id);
  if (hit && (hit.status === "queued" || hit.status === "running")) {
    patch(id, { status: "cancelled", finishedAt: Date.now() });
  }
}

export function finishTask(id: string) {
  lives.get(id)?.finish.abort();
}

export function clearFinished() {
  for (let i = items.length - 1; i >= 0; i--) {
    const st = items[i].status;
    if (st === "done" || st === "cancelled" || st === "error") items.splice(i, 1);
  }
  emit();
}

function kick() {
  if (pumping) return;
  const next = [...items].reverse().find((i) => i.status === "queued" && pending.has(i.id));
  if (!next) return;
  const task = pending.get(next.id);
  pending.delete(next.id);
  if (!task) return;
  pumping = true;
  void run(task, next.id);
}

async function run(task: EngineTask, id: string) {
  const live = lives.get(id);
  if (!live) {
    pumping = false;
    kick();
    return;
  }
  patch(id, { status: "running", progress: 1 });
  notify("AllTool", task.title, "alltool-progress");
  let lastNote = 0;
  const ctx: RunCtx & { finish: AbortSignal } = {
    signal: live.abort.signal,
    finish: live.finish.signal,
    progress: (pct, statusKey) => {
      const value = Math.max(0, Math.min(100, pct));
      patch(id, { progress: value, statusKey });
      if (value - lastNote >= 18) {
        lastNote = value;
        notify("AllTool", `${task.title} · ${Math.round(value)}%`, "alltool-progress");
      }
    },
  };
  try {
    const result = await task.run(ctx);
    if (live.abort.signal.aborted) throw abortError();
    const resultId = uid();
    const stored: StoredResult = {
      id: resultId,
      fileName: result.fileName,
      mime: result.mime,
      preview: result.preview,
      text: result.text,
      noteKey: result.noteKey,
      beforeBytes: result.beforeBytes,
      afterBytes: result.afterBytes ?? result.blob?.size,
      replay: result.replay,
      extras: result.extras?.map((e) => ({ fileName: e.fileName, labelKey: e.labelKey })),
    };
    memory.set(resultId, { stored, blob: result.blob, extras: result.extras || [] });
    const keepBlob = result.blob && result.blob.size <= 6_000_000 ? result.blob : undefined;
    await idbSet(resultId, {
      blob: keepBlob,
      fileName: result.fileName,
      mime: result.mime,
      text: result.text,
      preview: result.preview,
      noteKey: result.noteKey,
      replay: result.replay,
      extras: keepBlob ? result.extras : undefined,
    });
    patch(id, { status: "done", progress: 100, resultId, finishedAt: Date.now(), statusKey: undefined });
    const doneItem = items.find((i) => i.id === id);
    if (doneItem) onDone({ ...doneItem }, stored);
  } catch (e) {
    if (isAbort(e) || live.abort.signal.aborted) {
      patch(id, { status: "cancelled", finishedAt: Date.now() });
    } else {
      const key = e instanceof AppError ? e.key : "err.generic";
      const detail = e instanceof Error ? `${e.name}: ${e.message}\n${e.stack || ""}` : String(e);
      patch(id, { status: "error", errorKey: key, errorDetail: detail, finishedAt: Date.now() });
      const failed = items.find((i) => i.id === id);
      if (failed) onFail({ ...failed }, key, detail);
    }
  } finally {
    lives.delete(id);
    pumping = false;
    kick();
  }
}
