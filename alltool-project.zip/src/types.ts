export type ToolId =
  | "browser"
  | "video-download"
  | "video-compress"
  | "video-merge"
  | "audio-extract"
  | "audio-merge"
  | "tts"
  | "transcribe"
  | "images-pdf"
  | "images-combine"
  | "image-enhance"
  | "ocr"
  | "handwriting"
  | "text-pdf"
  | "translate";

export type CategoryId = "browser" | "video" | "audio" | "image" | "pdf" | "voice";

export type Lang = "fr" | "en" | "es" | "de" | "pt" | "it" | "ar" | "zh" | "sw" | "ln";

export type ThemeMode = "light" | "dark" | "system";

export type PreviewKind = "image" | "video" | "audio" | "pdf" | "text" | "none";

export type QueueStatus = "queued" | "running" | "done" | "error" | "cancelled";

export type View =
  | { name: "home" }
  | { name: "browser" }
  | { name: "favorites" }
  | { name: "history" }
  | { name: "queue" }
  | { name: "settings" }
  | { name: "errors" }
  | { name: "privacy" }
  | { name: "premium" }
  | { name: "tool"; tool: ToolId };

export type RunCtx = {
  signal: AbortSignal;
  progress: (pct: number, statusKey?: string) => void;
};

export type ExtraFile = {
  blob: Blob;
  fileName: string;
  labelKey: string;
};

export type TaskResult = {
  blob?: Blob;
  fileName: string;
  mime?: string;
  preview: PreviewKind;
  text?: string;
  extras?: ExtraFile[];
  beforeBytes?: number;
  afterBytes?: number;
  noteKey?: string;
  replay?: { rate: number; pitch: number };
};

export type QueueItem = {
  id: string;
  tool: ToolId;
  title: string;
  status: QueueStatus;
  progress: number;
  statusKey?: string;
  errorKey?: string;
  errorDetail?: string;
  resultId?: string;
  createdAt: number;
  finishedAt?: number;
};

export type HistoryItem = {
  id: string;
  tool: ToolId;
  fileName: string;
  at: number;
  resultId?: string;
  preview: PreviewKind;
  text?: string;
  noteKey?: string;
};

export type ErrorItem = {
  id: string;
  at: number;
  tool?: ToolId;
  messageKey: string;
  detail: string;
};

export type PickedFile = {
  id: string;
  file: File;
  url: string;
  thumb?: string;
  duration?: number;
  width?: number;
  height?: number;
  rotation: number;
};

export type StoredResult = {
  id: string;
  fileName: string;
  mime?: string;
  preview: PreviewKind;
  text?: string;
  noteKey?: string;
  beforeBytes?: number;
  afterBytes?: number;
  replay?: { rate: number; pitch: number };
  extras?: { fileName: string; labelKey: string }[];
};

export const CATEGORIES: CategoryId[] = ["browser", "video", "audio", "image", "pdf", "voice"];

export const TOOLS_BY_CAT: Record<CategoryId, ToolId[]> = {
  browser: ["browser", "video-download"],
  video: ["video-compress", "video-merge", "audio-extract"],
  audio: ["audio-merge"],
  image: ["images-pdf", "images-combine", "image-enhance"],
  pdf: ["ocr", "handwriting", "text-pdf", "translate"],
  voice: ["tts", "transcribe"],
};

export const ALL_TOOLS: ToolId[] = CATEGORIES.flatMap((c) => TOOLS_BY_CAT[c]);

export const TOOL_META: Record<ToolId, { cat: CategoryId; online: boolean }> = {
  browser: { cat: "browser", online: true },
  "video-download": { cat: "browser", online: true },
  "video-compress": { cat: "video", online: false },
  "video-merge": { cat: "video", online: false },
  "audio-extract": { cat: "video", online: false },
  "audio-merge": { cat: "audio", online: false },
  tts: { cat: "voice", online: false },
  transcribe: { cat: "voice", online: true },
  "images-pdf": { cat: "image", online: false },
  "images-combine": { cat: "image", online: false },
  "image-enhance": { cat: "image", online: false },
  ocr: { cat: "pdf", online: true },
  handwriting: { cat: "pdf", online: true },
  "text-pdf": { cat: "pdf", online: false },
  translate: { cat: "pdf", online: true },
};

export const CAT_COLOR: Record<CategoryId, string> = {
  browser: "#3B6CFF",
  video: "#7C3AED",
  audio: "#DB2777",
  image: "#0F9F8F",
  pdf: "#D97706",
  voice: "#059669",
};
