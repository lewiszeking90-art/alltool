// À remplir avec les valeurs de TON projet Firebase (voir FIREBASE.md).
// Tant que apiKey et projectId sont vides, l'app fonctionne SANS compte (mode local).
export const firebaseConfig = {
  apiKey: "",
  authDomain: "",
  projectId: "",
  storageBucket: "",
  messagingSenderId: "",
  appId: "",
};
