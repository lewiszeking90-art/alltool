import { createContext, useContext, useEffect, useMemo, useState } from "react";
import type { ReactNode } from "react";
import type { ErrorItem, HistoryItem, Lang, QueueItem, StoredResult, ThemeMode, ToolId, View } from "./types";
import type { MsgKey } from "./i18n";
import { translate } from "./i18n";
import { bindEngine, cancelTask, clearFinished, finishTask, remember, startTask, subscribe, type EngineTask } from "./engine";
import { checkNotifPermission, idbClear, idbGet, isNative, notify, saveBlob, savedKeys, uid } from "./lib/util";

type Persisted = {
  theme: ThemeMode;
  lang: Lang;
  name: string;
  onboarded: boolean;
  favorites: ToolId[];
  recents: ToolId[];
  history: HistoryItem[];
  errors: ErrorItem[];
  links: string[];
  usage: Record<string, number>;
  trialSeen: boolean;
};

type Viewer = { url: string; kind: StoredResult["preview"]; name: string; text?: string; tool?: ToolId; replay?: StoredResult["replay"] };

type DoneState = { item: QueueItem; stored: StoredResult };

export const FREE_LIMIT = 3;

const KEY = "alltool-v1";

const defaults: Persisted = {
  theme: "system",
  lang: "fr",
  name: "Brayan",
  onboarded: false,
  favorites: [],
  recents: [],
  history: [],
  errors: [],
  links: [],
  usage: {},
  trialSeen: false,
};

function loadPersisted(): Persisted {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return defaults;
    return { ...defaults, ...JSON.parse(raw) };
  } catch {
    return defaults;
  }
}

type Api = Persisted & {
  view: View;
  queue: QueueItem[];
  online: boolean;
  done: DoneState | null;
  toast: string | null;
  viewer: Viewer | null;
  notif: NotificationPermission | "unknown";
  premium: boolean;
  needAuth: boolean;
  authPrompt: boolean;
  hasPending: boolean;
  setNeedAuth: (value: boolean) => void;
  closeAuthPrompt: () => void;
  resumePending: () => void;
  paywall: { tool?: ToolId } | null;
  setPremium: (value: boolean) => void;
  closePaywall: () => void;
  openPaywall: () => void;
  markTrialSeen: () => void;
  mergeUsage: (remote: Record<string, number>) => void;
  t: (key: MsgKey, vars?: Record<string, string | number>) => string;
  setLang: (lang: Lang) => void;
  setTheme: (theme: ThemeMode) => void;
  setName: (name: string) => void;
  finishOnboarding: () => void;
  go: (view: View) => void;
  openTool: (tool: ToolId) => void;
  toggleFav: (id: ToolId) => void;
  clearHistory: () => void;
  clearFavorites: () => void;
  clearErrors: () => void;
  pushError: (tool: ToolId | undefined, messageKey: string, detail: string) => void;
  start: (task: EngineTask) => void;
  cancel: (id: string) => void;
  finish: (id: string) => void;
  clearDoneQueue: () => void;
  dismissDone: () => void;
  showToast: (text: string) => void;
  addLink: (url: string) => void;
  openStored: (resultId?: string, fallback?: Partial<Viewer>) => Promise<void>;
  closeViewer: () => void;
  setNotif: (value: NotificationPermission | "unknown") => void;
};

const Ctx = createContext<Api | null>(null);

export function AppProvider({ children }: { children: ReactNode }) {
  const [persisted, setPersisted] = useState<Persisted>(loadPersisted);
  const [view, setView] = useState<View>({ name: "home" });
  const [queue, setQueue] = useState<QueueItem[]>([]);
  const [online, setOnline] = useState(typeof navigator !== "undefined" ? navigator.onLine : true);
  const [done, setDone] = useState<DoneState | null>(null);
  const [toast, setToast] = useState<string | null>(null);
  const [viewer, setViewer] = useState<Viewer | null>(null);
  const [notif, setNotif] = useState<NotificationPermission | "unknown">("unknown");
  const [premium, setPremium] = useState(false);
  const [needAuth, setNeedAuth] = useState(false);
  const [authPrompt, setAuthPrompt] = useState(false);
  const [pending, setPending] = useState<EngineTask | null>(null);
  const [paywall, setPaywall] = useState<{ tool?: ToolId } | null>(null);

  const patch = (partial: Partial<Persisted>) => setPersisted((p) => ({ ...p, ...partial }));

  useEffect(() => {
    localStorage.setItem(KEY, JSON.stringify(persisted));
  }, [persisted]);

  useEffect(() => {
    const media = window.matchMedia("(prefers-color-scheme: dark)");
    const apply = () => {
      const dark = persisted.theme === "dark" || (persisted.theme === "system" && media.matches);
      document.documentElement.classList.toggle("dark", dark);
      document.documentElement.lang = persisted.lang;
      document.documentElement.dir = persisted.lang === "ar" ? "rtl" : "ltr";
      const meta = document.querySelector('meta[name="theme-color"]');
      meta?.setAttribute("content", dark ? "#0c0a12" : "#f3efe7");
    };
    apply();
    media.addEventListener("change", apply);
    return () => media.removeEventListener("change", apply);
  }, [persisted.theme, persisted.lang]);

  useEffect(() => {
    void checkNotifPermission().then(setNotif);
    const raw = sessionStorage.getItem("alltool-active");
    if (!raw) return;
    sessionStorage.removeItem("alltool-active");
    try {
      const data = JSON.parse(raw) as { tool?: ToolId; title?: string };
      setPersisted((p) => ({
        ...p,
        errors: [
          {
            id: uid(),
            at: Date.now(),
            tool: data.tool,
            messageKey: "err.closed",
            detail: data.title || "interrupted",
          },
          ...p.errors,
        ].slice(0, 40),
      }));
    } catch {
      /* ignore */
    }
  }, []);

  useEffect(() => subscribe(setQueue), []);

  useEffect(() => {
    const active = queue.find((q) => q.status === "running" || q.status === "queued");
    if (active) sessionStorage.setItem("alltool-active", JSON.stringify({ tool: active.tool, title: active.title }));
    else sessionStorage.removeItem("alltool-active");
  }, [queue]);

  useEffect(() => {
    const on = () => setOnline(true);
    const off = () => setOnline(false);
    const unlock = () => {
      const Ctor = window.AudioContext || (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      if (Ctor) {
        const ctx = new Ctor();
        void ctx.resume().finally(() => void ctx.close());
      }
      window.speechSynthesis?.resume();
      const warm = window.speechSynthesis ? new SpeechSynthesisUtterance(" ") : null;
      if (warm) {
        warm.volume = 0;
        window.speechSynthesis.speak(warm);
      }
    };
    window.addEventListener("online", on);
    window.addEventListener("offline", off);
    window.addEventListener("pointerdown", unlock, { once: true });
    return () => {
      window.removeEventListener("online", on);
      window.removeEventListener("offline", off);
      window.removeEventListener("pointerdown", unlock);
    };
  }, []);

  useEffect(() => {
    bindEngine({
      onDone: (item, stored) => {
        const mem = remember(stored.id);
        if (mem?.blob && !isNative()) {
          void saveBlob(mem.blob, stored.fileName);
          savedKeys.add(`${stored.id}:${stored.fileName}`);
        }
        setPersisted((p) => ({ ...p, usage: { ...p.usage, [item.tool]: (p.usage[item.tool] || 0) + 1 } }));
        setDone({ item, stored });
        notify("AllTool", translate(persisted.lang, "done.notif", { name: stored.fileName }), "alltool-done");
        setPersisted((p) => ({
          ...p,
          history: [
            {
              id: uid(),
              tool: item.tool,
              fileName: stored.fileName,
              at: Date.now(),
              resultId: stored.id,
              preview: stored.preview,
              text: stored.text?.slice(0, 4000),
              noteKey: stored.noteKey,
            },
            ...p.history,
          ].slice(0, 40),
        }));
      },
      onFail: (item, key, detail) => {
        notify("AllTool", translate(persisted.lang, "notif.fail", { name: item.title }), "alltool-fail");
        setPersisted((p) => ({
          ...p,
          errors: [{ id: uid(), at: Date.now(), tool: item.tool, messageKey: key, detail }, ...p.errors].slice(0, 40),
        }));
        setToast(translate(persisted.lang, (key in { "err.generic": 1 } ? key : key) as MsgKey));
      },
    });
  }, [persisted.lang]);

  useEffect(() => {
    if (!toast) return;
    const t = window.setTimeout(() => setToast(null), 4200);
    return () => window.clearTimeout(t);
  }, [toast]);

  const api = useMemo<Api>(() => {
    const t = (key: MsgKey, vars?: Record<string, string | number>) => translate(persisted.lang, key, vars);
    return {
      ...persisted,
      view,
      queue,
      online,
      done,
      toast,
      viewer,
      notif,
      premium,
      needAuth,
      authPrompt,
      hasPending: pending !== null,
      setNeedAuth,
      closeAuthPrompt: () => {
        setAuthPrompt(false);
        setPending(null);
      },
      resumePending: () => {
        if (!pending) return;
        const task = pending;
        setPending(null);
        setAuthPrompt(false);
        if (!premium) {
          const inflight = queue.filter((q) => q.tool === task.tool && (q.status === "queued" || q.status === "running")).length;
          if ((persisted.usage[task.tool] || 0) + inflight >= FREE_LIMIT) {
            setPaywall({ tool: task.tool });
            return;
          }
        }
        startTask(task);
      },
      paywall,
      setPremium,
      closePaywall: () => setPaywall(null),
      openPaywall: () => setPaywall({}),
      markTrialSeen: () => patch({ trialSeen: true }),
      mergeUsage: (remote) =>
        setPersisted((p) => {
          let changed = false;
          const usage = { ...p.usage };
          for (const [k, v] of Object.entries(remote)) {
            if (typeof v === "number" && v > (usage[k] || 0)) {
              usage[k] = v;
              changed = true;
            }
          }
          return changed ? { ...p, usage } : p;
        }),
      t,
      setLang: (lang) => patch({ lang }),
      setTheme: (theme) => patch({ theme }),
      setName: (name) => patch({ name }),
      finishOnboarding: () => patch({ onboarded: true }),
      go: (next) => setView(next),
      openTool: (tool) => {
        setPersisted((p) => ({ ...p, recents: [tool, ...p.recents.filter((id) => id !== tool)].slice(0, 8) }));
        setView(tool === "browser" ? { name: "browser" } : { name: "tool", tool });
      },
      toggleFav: (id) =>
        setPersisted((p) => ({
          ...p,
          favorites: p.favorites.includes(id) ? p.favorites.filter((x) => x !== id) : [id, ...p.favorites],
        })),
      clearHistory: () => {
        patch({ history: [], recents: [] });
        void idbClear();
      },
      clearFavorites: () => patch({ favorites: [] }),
      clearErrors: () => patch({ errors: [] }),
      pushError: (tool, messageKey, detail) =>
        setPersisted((p) => ({
          ...p,
          errors: [{ id: uid(), at: Date.now(), tool, messageKey, detail }, ...p.errors].slice(0, 40),
        })),
      start: (task) => {
        if (needAuth) {
          setPending(task);
          setAuthPrompt(true);
          return;
        }
        if (!premium) {
          const inflight = queue.filter((q) => q.tool === task.tool && (q.status === "queued" || q.status === "running")).length;
          if ((persisted.usage[task.tool] || 0) + inflight >= FREE_LIMIT) {
            setPaywall({ tool: task.tool });
            return;
          }
        }
        startTask(task);
      },
      cancel: cancelTask,
      finish: finishTask,
      clearDoneQueue: clearFinished,
      dismissDone: () => setDone(null),
      showToast: (text) => setToast(text),
      addLink: (url) =>
        setPersisted((p) => ({ ...p, links: [url, ...p.links.filter((x) => x !== url)].slice(0, 8) })),
      openStored: async (resultId, fallback) => {
        if (resultId) {
          const mem = remember(resultId);
          const blob = mem?.blob || (await idbGet<{ blob?: Blob; text?: string; fileName?: string; preview?: Viewer["kind"] }>(resultId))?.blob;
          const text = mem?.stored.text || fallback?.text;
          if (blob) {
            setViewer({
              url: URL.createObjectURL(blob),
              kind: mem?.stored.preview || fallback?.kind || "none",
              name: mem?.stored.fileName || fallback?.name || "AllTool",
              text,
              tool: fallback?.tool,
              replay: mem?.stored.replay,
            });
            return;
          }
          if (text) {
            setViewer({ url: "", kind: "text", name: fallback?.name || "AllTool", text, tool: fallback?.tool, replay: fallback?.replay });
            return;
          }
        }
        setToast(t("history.missing"));
      },
      closeViewer: () => {
        setViewer((v) => {
          if (v?.url) URL.revokeObjectURL(v.url);
          return null;
        });
      },
      setNotif,
    };
  }, [persisted, view, queue, online, done, toast, viewer, notif, premium, paywall, needAuth, authPrompt, pending]);

  return <Ctx.Provider value={api}>{children}</Ctx.Provider>;
}

export function useApp() {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("store");
  return ctx;
}
