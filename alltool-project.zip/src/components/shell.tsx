import { useEffect, useMemo, useState } from "react";
import type { ReactNode } from "react";
import { LANGS } from "../i18n";
import type { MsgKey } from "../i18n";
import { useApp } from "../store";
import { remember } from "../engine";
import { formatBytes, requestNotifPermission, saveBlob, shareBlob } from "../lib/util";
import { speakText } from "../lib/speech";
import { Logo, Icon, IconButton } from "./ui";
import { cn } from "../utils/cn";
import type { ToolId } from "../types";
import { TOOL_META } from "../types";

const NAV: { id: "home" | "browser" | "favorites" | "history" | "queue" | "settings"; icon: "home" | "compass" | "star" | "clock" | "layers" | "sliders"; key: MsgKey; short: MsgKey }[] = [
  { id: "home", icon: "home", key: "nav.home", short: "nav.home.s" },
  { id: "browser", icon: "compass", key: "nav.browser", short: "nav.browser.s" },
  { id: "favorites", icon: "star", key: "nav.favorites", short: "nav.favorites.s" },
  { id: "history", icon: "clock", key: "nav.history", short: "nav.history.s" },
  { id: "queue", icon: "layers", key: "nav.queue", short: "nav.queue.s" },
  { id: "settings", icon: "sliders", key: "nav.settings", short: "nav.settings.s" },
];

function activeNav(name: string) {
  if (name === "tool") return "home";
  if (name === "errors" || name === "privacy" || name === "premium") return "settings";
  return name;
}

export function Shell({ children }: { children: ReactNode }) {
  const app = useApp();
  const running = app.queue.filter((q) => q.status === "running" || q.status === "queued").length;
  const dark = app.theme === "dark" || (app.theme === "system" && document.documentElement.classList.contains("dark"));
  return (
    <div className="min-h-dvh">
      <aside className="fixed inset-y-0 start-0 z-30 hidden w-[248px] flex-col border-e border-[var(--line)] bg-[var(--card-solid)]/80 px-4 py-5 backdrop-blur-xl lg:flex">
        <button type="button" onClick={() => app.go({ name: "home" })} className="mb-8 flex items-center gap-3 px-2 text-start">
          <Logo size={44} />
          <div>
            <p className="display text-xl font-extrabold leading-none">AllTool</p>
            <p className="muted mt-1 text-xs">{app.online ? app.t("common.online") : app.t("common.offline")}</p>
          </div>
        </button>
        <nav className="flex flex-1 flex-col gap-1">
          {NAV.map((item) => {
            const on = activeNav(app.view.name) === item.id;
            return (
              <button key={item.id} type="button" onClick={() => app.go({ name: item.id })} className={cn("flex items-center gap-3 rounded-2xl px-3 py-3 text-start text-sm font-semibold", on ? "bg-[var(--ink)] text-[var(--bg)]" : "text-[var(--muted)] hover:bg-black/5 dark:hover:bg-white/5")}>
                <Icon name={item.icon} />
                <span className="flex-1">{app.t(item.key)}</span>
                {item.id === "queue" && running > 0 && <span className="rounded-full bg-[#5344f0] px-2 py-0.5 text-[11px] text-white">{running}</span>}
              </button>
            );
          })}
        </nav>
        <button type="button" onClick={() => app.go({ name: "premium" })} className="mt-4 rounded-3xl bg-gradient-to-br from-indigo-500 to-violet-500 p-4 text-start text-white">
          <p className="text-xs font-semibold uppercase tracking-[0.14em] text-white/75">{app.t("premium.kicker")}</p>
          <p className="display mt-1 text-lg font-extrabold">{app.t("premium.title")}</p>
        </button>
      </aside>

      <div className="lg:ps-[248px]">
        <header className="sticky top-0 z-20 flex items-center gap-3 bg-[var(--bg)]/80 px-4 py-3 backdrop-blur-xl lg:px-8">
          <button type="button" className="lg:hidden" onClick={() => app.go({ name: "home" })} aria-label="AllTool">
            <Logo size={40} />
          </button>
          <div className="min-w-0 flex-1">
            <p className="display truncate text-lg font-extrabold leading-none">AllTool</p>
            <p className="muted text-xs">{app.online ? app.t("common.online") : app.t("common.offline")}</p>
          </div>
          <IconButton label={app.t("settings.theme")} onClick={() => app.setTheme(dark ? "light" : "dark")}>
            <Icon name={dark ? "sun" : "moon"} />
          </IconButton>
        </header>
        <main className="px-4 pb-nav lg:px-8 lg:pb-16">{children}</main>
      </div>

      <nav className="fixed inset-x-0 bottom-0 z-40 px-3 pb-[max(10px,env(safe-area-inset-bottom))] lg:hidden">
        <div className="mx-auto flex max-w-lg items-center gap-1 rounded-[28px] border border-[var(--line)] bg-[var(--card-solid)]/92 p-1.5 shadow-[var(--shadow)] backdrop-blur-xl">
          {NAV.map((item) => {
            const on = activeNav(app.view.name) === item.id;
            return (
              <button key={item.id} type="button" onClick={() => app.go({ name: item.id })} className={cn("relative flex h-11 items-center justify-center gap-1 rounded-2xl text-[11px] font-semibold", on ? "min-w-0 flex-1 bg-gradient-to-br from-indigo-500 to-violet-500 px-2 text-white" : "w-9 shrink-0 text-[var(--muted)]")}>
                <Icon name={item.icon} className="h-[18px] w-[18px]" />
                {on && <span className="truncate">{app.t(item.short)}</span>}
                {item.id === "queue" && running > 0 && !on && <span className="absolute -end-0.5 -top-0.5 h-2 w-2 rounded-full bg-[#5344f0]" />}
              </button>
            );
          })}
        </div>
      </nav>

      <TaskDock />
      <DoneModal />
      <Viewer />
      {app.toast && (
        <div className="fixed inset-x-0 bottom-28 z-[70] flex justify-center px-4 lg:bottom-8">
          <div className="max-w-md rounded-2xl bg-[var(--ink)] px-4 py-3 text-sm text-[var(--bg)] shadow-lg">{app.toast}</div>
        </div>
      )}
      {!app.onboarded && <Onboarding />}
    </div>
  );
}

function TaskDock() {
  const app = useApp();
  const job = app.queue.find((q) => q.status === "running");
  if (!job) return null;
  if (app.view.name === "tool" || app.view.name === "queue") return null;
  return (
    <button type="button" onClick={() => app.openTool(job.tool)} className="fixed inset-x-4 bottom-[5.6rem] z-[45] mx-auto flex max-w-lg items-center gap-3 rounded-2xl bg-[var(--ink)] px-4 py-3 text-start text-[var(--bg)] shadow-lg lg:bottom-6 lg:start-[272px]">
      <span className="text-sm font-semibold tabular-nums">{Math.round(job.progress)}%</span>
      <span className="min-w-0 flex-1 truncate text-sm">{job.title}</span>
      <span className="h-1.5 w-16 overflow-hidden rounded-full bg-white/20">
        <span className="block h-full bg-white" style={{ width: `${job.progress}%` }} />
      </span>
    </button>
  );
}

function DoneModal() {
  const app = useApp();
  const stored = app.done?.stored;
  const item = app.done?.item;
  const blob = stored ? remember(stored.id)?.blob : undefined;
  const previewUrl = useMemo(() => (blob ? URL.createObjectURL(blob) : ""), [blob, stored?.id]);
  useEffect(() => {
    return () => {
      if (previewUrl) URL.revokeObjectURL(previewUrl);
    };
  }, [previewUrl]);
  if (!app.done || !stored || !item) return null;
  const mem = remember(stored.id);
  const save = (target = blob, name = stored.fileName) => {
    if (!target) {
      app.showToast(app.t("viewer.missing"));
      return;
    }
    saveBlob(target, name);
  };
  const share = async () => {
    if (!blob) {
      app.showToast(app.t("viewer.missing"));
      return;
    }
    try {
      const mode = await shareBlob(blob, stored.fileName, "AllTool");
      if (mode === "saved") app.showToast(app.t("err.share"));
    } catch (e) {
      if (e instanceof DOMException && e.name === "AbortError") return;
      save();
      app.showToast(app.t("err.share"));
    }
  };
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/45 p-3 sm:items-center" onClick={app.dismissDone}>
      <div className="rise w-full max-w-md overflow-hidden rounded-[28px] solid hairline shadow-2xl" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center gap-3 bg-gradient-to-br from-indigo-500 to-violet-500 px-5 py-4 text-white">
          <span className="pop grid h-11 w-11 place-items-center rounded-2xl bg-white/15">
            <Icon name="check" />
          </span>
          <div>
            <p className="display text-2xl font-extrabold">{app.t("done.title")}</p>
            <p className="text-sm text-white/80">{app.t(`tool.${item.tool}` as MsgKey)}</p>
          </div>
        </div>
        <div className="space-y-4 px-5 py-5">
          {stored.preview === "image" && previewUrl && <img src={previewUrl} alt="" className="max-h-52 w-full rounded-2xl object-contain bg-black/5" />}
          {stored.preview === "video" && previewUrl && <video src={previewUrl} controls playsInline className="max-h-52 w-full rounded-2xl bg-black" />}
          {stored.preview === "audio" && previewUrl && <audio src={previewUrl} controls className="w-full" />}
          {stored.text && <pre className="max-h-40 overflow-auto whitespace-pre-wrap rounded-2xl bg-black/5 p-3 text-sm leading-relaxed" dir="auto">{stored.text}</pre>}
          {stored.noteKey && <p className="text-sm leading-relaxed">{app.t(stored.noteKey as MsgKey)}</p>}
          {stored.beforeBytes != null && stored.afterBytes != null && (
            <p className="text-sm font-semibold">{app.t("done.compare", { before: formatBytes(stored.beforeBytes, app.lang), after: formatBytes(stored.afterBytes, app.lang) })}</p>
          )}
          <div className="rounded-2xl border border-dashed border-[var(--line)] px-3 py-3">
            <p className="muted text-[11px] font-semibold uppercase tracking-[0.14em]">{app.t("done.folder")}</p>
            <p className="mt-1 break-all text-sm font-semibold" dir="ltr">{stored.fileName}</p>
            {stored.afterBytes != null && <p className="muted mt-1 text-xs">{formatBytes(stored.afterBytes, app.lang)}</p>}
          </div>
          {item.tool === "tts" && stored.text && (
            <button type="button" className="ghost-btn h-12 w-full rounded-2xl font-semibold" onClick={() => void speakText(stored.text || "", stored.replay?.rate || 1, stored.replay?.pitch || 1, { signal: new AbortController().signal, progress: () => undefined }, app.lang)}>
              {app.t("action.replay")}
            </button>
          )}
          <div className="grid grid-cols-3 gap-2">
            <button type="button" className="brand-btn h-12 rounded-2xl text-sm font-semibold" onClick={() => save()}>{app.t("action.save")}</button>
            <button type="button" className="ghost-btn h-12 rounded-2xl text-sm font-semibold" onClick={() => void share()}>{app.t("action.share")}</button>
            <button type="button" className="ghost-btn h-12 rounded-2xl text-sm font-semibold" onClick={() => void app.openStored(stored.id, { name: stored.fileName, kind: stored.preview, text: stored.text, tool: item.tool, replay: stored.replay })}>{app.t("action.open")}</button>
          </div>
          {mem?.extras.map((extra) => (
            <button key={extra.fileName} type="button" className="ghost-btn h-11 w-full rounded-2xl text-sm font-semibold" onClick={() => save(extra.blob, extra.fileName)}>
              {app.t("action.save")} · {extra.fileName.split(".").pop()?.toUpperCase()}
            </button>
          ))}
          <button type="button" className="w-full py-1 text-sm font-semibold text-[var(--muted)]" onClick={app.dismissDone}>{app.t("action.close")}</button>
        </div>
      </div>
    </div>
  );
}

function Viewer() {
  const app = useApp();
  if (!app.viewer) return null;
  const v = app.viewer;
  return (
    <div className="fixed inset-0 z-[60] flex flex-col bg-black/80 p-3" onClick={app.closeViewer}>
      <div className="mx-auto flex w-full max-w-3xl items-center justify-between py-2 text-white">
        <p className="truncate text-sm font-semibold" dir="ltr">{v.name}</p>
        <IconButton label={app.t("action.close")} onClick={app.closeViewer} className="bg-white/10 text-white">
          <Icon name="close" />
        </IconButton>
      </div>
      <div className="mx-auto w-full max-w-3xl flex-1 overflow-auto rounded-3xl bg-[var(--card-solid)] p-3" onClick={(e) => e.stopPropagation()}>
        {v.kind === "image" && v.url && <img src={v.url} alt="" className="mx-auto max-h-[70vh] rounded-2xl" />}
        {v.kind === "video" && v.url && <video src={v.url} controls autoPlay playsInline className="max-h-[70vh] w-full rounded-2xl bg-black" />}
        {v.kind === "audio" && v.url && <audio src={v.url} controls autoPlay className="mt-8 w-full" />}
        {v.kind === "pdf" && v.url && <iframe title={v.name} src={v.url} className="h-[70vh] w-full rounded-2xl" />}
        {v.text && <pre className="whitespace-pre-wrap p-3 text-sm leading-relaxed" dir="auto">{v.text}</pre>}
        {!v.url && !v.text && <p className="p-6 text-center">{app.t("viewer.missing")}</p>}
      </div>
    </div>
  );
}

function Onboarding() {
  const app = useApp();
  const [step, setStep] = useState(0);
  const [mic, setMic] = useState(false);
  const askNotif = async () => {
    const res = await requestNotifPermission();
    app.setNotif(res);
  };
  const askMic = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      stream.getTracks().forEach((t) => t.stop());
      setMic(true);
    } catch {
      setMic(false);
    }
  };
  return (
    <div className="fixed inset-0 z-[65] overflow-auto bg-[var(--bg)]">
      <div className="mx-auto flex min-h-dvh max-w-lg flex-col px-5 py-8">
        <div className="mb-8 flex items-center justify-between">
          <Logo size={48} />
          <button type="button" className="text-sm font-semibold text-[var(--muted)]" onClick={app.finishOnboarding}>{app.t("onb.skip")}</button>
        </div>
        {step === 0 && (
          <div className="rise flex flex-1 flex-col">
            <div className="relative mb-6 overflow-hidden rounded-[32px] bg-gradient-to-br from-[#4f46e5] via-[#6842ee] to-[#8b5cf6] px-5 py-8 text-white">
              <div className="pointer-events-none absolute -end-4 -top-6 opacity-25">
                <Logo size={140} />
              </div>
              <Logo size={64} />
              <p className="mt-6 text-sm text-white/80">{app.name}</p>
              <h1 className="display mt-1 text-4xl font-extrabold leading-[0.95]">{app.t("onb.title")}</h1>
            </div>
            <p className="text-lg leading-relaxed">{app.t("onb.body")}</p>
            <div className="mt-6 grid grid-cols-2 gap-3">
              {(["cat.video", "cat.image", "cat.pdf", "cat.voice"] as MsgKey[]).map((key) => (
                <div key={key} className="solid hairline rounded-3xl p-4 text-sm font-semibold">{app.t(key)}</div>
              ))}
            </div>
          </div>
        )}
        {step === 1 && (
          <div className="rise flex-1 space-y-3">
            <h1 className="display text-4xl font-extrabold">{app.t("onb.permTitle")}</h1>
            <p className="muted">{app.t("onb.permBody")}</p>
            <PermCard title={app.t("onb.notif")} body={app.t("onb.notifBody")} ok={app.notif === "granted"} okLabel={app.t("onb.allowed")} action={app.t("onb.allow")} onClick={() => void askNotif()} />
            <PermCard title={app.t("onb.mic")} body={app.t("onb.micBody")} ok={mic} okLabel={app.t("onb.allowed")} action={app.t("onb.allow")} onClick={() => void askMic()} />
            <PermCard title={app.t("onb.files")} body={app.t("onb.filesBody")} ok={false} okLabel={app.t("onb.allowed")} action={app.t("onb.later")} onClick={() => undefined} />
          </div>
        )}
        {step === 2 && (
          <div className="rise flex-1">
            <h1 className="display text-4xl font-extrabold">{app.t("onb.readyTitle")}</h1>
            <p className="muted mt-2">{app.t("onb.readyBody")}</p>
            <p className="mb-2 mt-6 text-xs font-semibold uppercase tracking-[0.14em] text-[var(--muted)]">{app.t("settings.language")}</p>
            <div className="grid grid-cols-2 gap-2">
              {LANGS.map((l) => (
                <button key={l.id} type="button" onClick={() => app.setLang(l.id)} className={cn("rounded-2xl border px-3 py-3 text-start text-sm font-semibold", app.lang === l.id ? "border-transparent bg-[var(--ink)] text-[var(--bg)]" : "border-[var(--line)]")}>
                  {l.native}
                </button>
              ))}
            </div>
            <p className="mb-2 mt-6 text-xs font-semibold uppercase tracking-[0.14em] text-[var(--muted)]">{app.t("settings.theme")}</p>
            <div className="flex gap-2">
              {(["light", "dark", "system"] as const).map((mode) => (
                <button key={mode} type="button" onClick={() => app.setTheme(mode)} className={cn("chip flex-1", app.theme === mode && "chip-on")}>
                  {app.t(mode === "light" ? "settings.light" : mode === "dark" ? "settings.dark" : "settings.system")}
                </button>
              ))}
            </div>
          </div>
        )}
        <button type="button" className="brand-btn mt-8 h-14 rounded-2xl text-base font-semibold" onClick={() => (step < 2 ? setStep(step + 1) : app.finishOnboarding())}>
          {step < 2 ? app.t("onb.next") : app.t("onb.start")}
        </button>
        <div className="mt-4 flex justify-center gap-2">
          {[0, 1, 2].map((i) => (
            <span key={i} className={cn("h-1.5 rounded-full", i === step ? "w-6 bg-[#5344f0]" : "w-1.5 bg-[var(--line)]")} />
          ))}
        </div>
      </div>
    </div>
  );
}

function PermCard({ title, body, ok, okLabel, action, onClick }: { title: string; body: string; ok: boolean; okLabel: string; action: string; onClick: () => void }) {
  return (
    <div className="surface hairline rounded-3xl p-4">
      <div className="flex items-start justify-between gap-3">
        <p className="font-semibold">{title}</p>
        <button type="button" onClick={onClick} className={cn("rounded-full px-3 py-1 text-xs font-semibold", ok ? "bg-emerald-500/15 text-emerald-700" : "bg-[var(--ink)] text-[var(--bg)]")}>
          {ok ? okLabel : action}
        </button>
      </div>
      <p className="muted mt-2 text-sm leading-relaxed">{body}</p>
    </div>
  );
}

export function toolLabel(id: ToolId, t: (key: MsgKey) => string) {
  return t(`tool.${id}` as MsgKey);
}

export function isOnlineTool(id: ToolId) {
  return TOOL_META[id].online;
}
