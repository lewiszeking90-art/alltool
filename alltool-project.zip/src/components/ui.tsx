import { useEffect, useId, useRef, useState } from "react";
import type { ReactNode } from "react";
import { cn } from "../utils/cn";
import type { CategoryId, ToolId } from "../types";
import { CAT_COLOR } from "../types";

export function Logo({ size = 48, className }: { size?: number; className?: string }) {
  const id = useId().replace(/:/g, "");
  return (
    <svg width={size} height={size} viewBox="0 0 64 64" className={className} aria-hidden>
      <defs>
        <linearGradient id={id} x1="8" y1="4" x2="58" y2="62" gradientUnits="userSpaceOnUse">
          <stop offset="0" stopColor="#5A6BFF" />
          <stop offset="0.55" stopColor="#6A52F6" />
          <stop offset="1" stopColor="#8A45F8" />
        </linearGradient>
      </defs>
      <rect width="64" height="64" rx="16" fill={`url(#${id})`} />
      <rect x="10" y="10" width="20" height="20" rx="5.5" fill="white" />
      <rect x="34" y="10" width="20" height="20" rx="5.5" fill="white" />
      <rect x="10" y="34" width="20" height="20" rx="5.5" fill="white" />
      <path d="M39 34h9.2a5.6 5.6 0 0 1 5.6 5.6V47.2L46.4 58.2 37.4 49.4a6.2 6.2 0 0 1-3.4-5.5V39.6A5.6 5.6 0 0 1 39.6 34H39z" fill="white" />
    </svg>
  );
}

type IconName =
  | "home"
  | "compass"
  | "star"
  | "starFill"
  | "clock"
  | "layers"
  | "sliders"
  | "sun"
  | "moon"
  | "search"
  | "back"
  | "close"
  | "check"
  | "download"
  | "film"
  | "music"
  | "mic"
  | "image"
  | "file"
  | "languages"
  | "wand"
  | "scan"
  | "pen"
  | "plus"
  | "trash"
  | "up"
  | "down"
  | "rotate"
  | "share"
  | "folder"
  | "alert"
  | "copy"
  | "play"
  | "split"
  | "globe";

export function Icon({ name, className }: { name: IconName; className?: string }) {
  const common = { fill: "none", stroke: "currentColor", strokeWidth: 1.8, strokeLinecap: "round" as const, strokeLinejoin: "round" as const };
  const paths: Record<IconName, ReactNode> = {
    home: <path d="M4 11.5 12 5l8 6.5V20a1 1 0 0 1-1 1h-5v-5H10v5H5a1 1 0 0 1-1-1v-8.5Z" />,
    compass: (
      <>
        <circle cx="12" cy="12" r="8" />
        <path d="m14.8 9.2-1.3 4.3-4.3 1.3 1.3-4.3 4.3-1.3Z" />
      </>
    ),
    star: <path d="m12 3.6 2.1 4.6 5 .6-3.7 3.4.9 5-4.3-2.4L7.7 17.2l.9-5L4.9 8.8l5-.6L12 3.6Z" />,
    starFill: <path d="m12 3.2 2.3 5 5.5.6-4.1 3.7 1.1 5.4L12 15.2 7.2 18l1.1-5.4L4.2 8.8l5.5-.6L12 3.2Z" fill="currentColor" stroke="none" />,
    clock: (
      <>
        <circle cx="12" cy="12" r="8" />
        <path d="M12 8v4.5l3 2" />
      </>
    ),
    layers: (
      <>
        <path d="m12 4 8 4-8 4-8-4 8-4Z" />
        <path d="m4 12 8 4 8-4" />
        <path d="m4 16 8 4 8-4" />
      </>
    ),
    sliders: (
      <>
        <path d="M4 8h16M4 16h16" />
        <circle cx="9" cy="8" r="2" fill="currentColor" />
        <circle cx="15" cy="16" r="2" fill="currentColor" />
      </>
    ),
    sun: (
      <>
        <circle cx="12" cy="12" r="3.2" />
        <path d="M12 3.5v1.8M12 18.7v1.8M3.5 12h1.8M18.7 12h1.8M6.1 6.1l1.3 1.3M16.6 16.6l1.3 1.3M17.9 6.1l-1.3 1.3M7.4 16.6l-1.3 1.3" />
      </>
    ),
    moon: <path d="M16 14.5A6.5 6.5 0 0 1 9.2 6 6.5 6.5 0 1 0 16 14.5Z" />,
    search: (
      <>
        <circle cx="11" cy="11" r="6" />
        <path d="m16 16 3.5 3.5" />
      </>
    ),
    back: <path d="M15 5 8 12l7 7M8 12h12" />,
    close: <path d="M6 6l12 12M18 6 6 18" />,
    check: <path d="m5 12.5 4.2 4.2L19 7.5" />,
    download: (
      <>
        <path d="M12 4v10" />
        <path d="m8 10 4 4 4-4" />
        <path d="M5 19h14" />
      </>
    ),
    film: (
      <>
        <rect x="4" y="5" width="16" height="14" rx="2" />
        <path d="M8 5v14M16 5v14M4 9h4M4 15h4M16 9h4M16 15h4" />
      </>
    ),
    music: (
      <>
        <path d="M9 17V6l10-2v11" />
        <circle cx="7" cy="17" r="2.2" />
        <circle cx="17" cy="15" r="2.2" />
      </>
    ),
    mic: (
      <>
        <rect x="9" y="3.5" width="6" height="10" rx="3" />
        <path d="M6.5 11a5.5 5.5 0 0 0 11 0M12 16.5V20" />
      </>
    ),
    image: (
      <>
        <rect x="4" y="5" width="16" height="14" rx="2" />
        <circle cx="9" cy="10" r="1.3" />
        <path d="m7 16 3.2-3.2a1 1 0 0 1 1.4 0L16 17" />
      </>
    ),
    file: (
      <>
        <path d="M7 3.5h7l4 4V20a1 1 0 0 1-1 1H7a1 1 0 0 1-1-1V4.5a1 1 0 0 1 1-1Z" />
        <path d="M14 3.5V8h4M8.5 12h7M8.5 15.5h5" />
      </>
    ),
    languages: (
      <>
        <path d="M4 6h8M8 6c0 6-3 8-5 9" />
        <path d="M6 10c1.2 1.4 2.8 2.4 5 3" />
        <path d="m13 20 4-9 4 9M14.4 17.2h5.2" />
      </>
    ),
    wand: (
      <>
        <path d="m4 20 10-10" />
        <path d="m13 5 1.2 2.3L16.5 8.5 14.2 9.7 13 12l-1.2-2.3L9.5 8.5l2.3-1.2L13 5Z" />
        <path d="M18 13v2M17 14h2" />
      </>
    ),
    scan: (
      <>
        <path d="M5 8V5h3M16 5h3v3M19 16v3h-3M8 19H5v-3" />
        <path d="M6 12h12" />
      </>
    ),
    pen: (
      <>
        <path d="M14 4.5 19.5 10 9 20.5H4V15.5L14 4.5Z" />
        <path d="m12.5 6.5 5 5" />
      </>
    ),
    plus: <path d="M12 5v14M5 12h14" />,
    trash: (
      <>
        <path d="M5 7h14M9 7V5h6v2M7 7l1 13h8l1-13" />
      </>
    ),
    up: <path d="m6 14 6-6 6 6" />,
    down: <path d="m6 10 6 6 6-6" />,
    rotate: (
      <>
        <path d="M20 12a8 8 0 1 1-2.2-5.5" />
        <path d="M20 4v4h-4" />
      </>
    ),
    share: (
      <>
        <circle cx="6.5" cy="12" r="2" />
        <circle cx="17" cy="6.5" r="2" />
        <circle cx="17" cy="17.5" r="2" />
        <path d="m8.2 11 7-3.4M8.2 13l7 3.4" />
      </>
    ),
    folder: (
      <>
        <path d="M3.5 8.5V6.8A1.8 1.8 0 0 1 5.3 5h4l1.6 2h7.8A1.8 1.8 0 0 1 20.5 8.8v8.4a1.8 1.8 0 0 1-1.8 1.8H5.3a1.8 1.8 0 0 1-1.8-1.8V8.5Z" />
      </>
    ),
    alert: (
      <>
        <path d="M12 4.5 21 19H3L12 4.5Z" />
        <path d="M12 10v4M12 16.5h.01" />
      </>
    ),
    copy: (
      <>
        <rect x="8" y="8" width="11" height="12" rx="2" />
        <path d="M6 15.5H5a1 1 0 0 1-1-1V5a1 1 0 0 1 1-1h9.5a1 1 0 0 1 1 1v1" />
      </>
    ),
    play: <path d="m9 7 8 5-8 5V7Z" fill="currentColor" stroke="none" />,
    split: <path d="M8 8 5 12l3 4M16 8l3 4-3 4M5 12h14" />,
    globe: (
      <>
        <circle cx="12" cy="12" r="8" />
        <path d="M4 12h16M12 4c2.2 2.4 3.2 5.1 3.2 8s-1 5.6-3.2 8c-2.2-2.4-3.2-5.1-3.2-8s1-5.6 3.2-8Z" />
      </>
    ),
  };
  return (
    <svg viewBox="0 0 24 24" className={cn("h-5 w-5", className)} {...common}>
      {paths[name]}
    </svg>
  );
}

export function toolIcon(id: ToolId): IconName {
  const map: Record<ToolId, IconName> = {
    browser: "compass",
    "video-download": "download",
    "video-compress": "film",
    "video-merge": "layers",
    "audio-extract": "music",
    "audio-merge": "music",
    tts: "play",
    transcribe: "mic",
    "images-pdf": "file",
    "images-combine": "image",
    "image-enhance": "wand",
    ocr: "scan",
    handwriting: "pen",
    "text-pdf": "file",
    translate: "languages",
  };
  return map[id];
}

export function catIcon(id: CategoryId): IconName {
  const map: Record<CategoryId, IconName> = {
    browser: "compass",
    video: "film",
    audio: "music",
    image: "image",
    pdf: "file",
    voice: "mic",
  };
  return map[id];
}

export function Badge({ online, label }: { online: boolean; label: string }) {
  return (
    <span className={cn("inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[11px] font-semibold", online ? "bg-amber-500/15 text-amber-700 dark:text-amber-300" : "bg-emerald-500/12 text-emerald-700 dark:text-emerald-300")}>
      <span className={cn("h-1.5 w-1.5 rounded-full", online ? "bg-amber-500" : "bg-emerald-500")} />
      {label}
    </span>
  );
}

export function IconButton({ label, onClick, children, className }: { label: string; onClick?: () => void; children: ReactNode; className?: string }) {
  return (
    <button type="button" aria-label={label} onClick={onClick} className={cn("icon-btn grid h-11 w-11 place-items-center rounded-2xl hairline solid", className)}>
      {children}
    </button>
  );
}

export function EmptyState({ title, body }: { title: string; body: string }) {
  return (
    <div className="surface hairline rounded-[28px] px-6 py-12 text-center">
      <div className="mx-auto mb-4 w-fit">
        <Logo size={58} />
      </div>
      <p className="display text-2xl font-extrabold">{title}</p>
      <p className="muted mx-auto mt-2 max-w-xs text-sm leading-relaxed">{body}</p>
    </div>
  );
}

export function Picker({ accept, multiple, label, hint, onFiles }: { accept: string; multiple?: boolean; label: string; hint?: string; onFiles: (files: FileList) => void }) {
  const ref = useRef<HTMLInputElement>(null);
  return (
    <button
      type="button"
      className="dropzone"
      onClick={() => ref.current?.click()}
      onDragOver={(e) => e.preventDefault()}
      onDrop={(e) => {
        e.preventDefault();
        if (e.dataTransfer.files.length) onFiles(e.dataTransfer.files);
      }}
    >
      <span className="grid h-11 w-11 place-items-center rounded-2xl bg-[var(--ink)] text-[var(--bg)]">
        <Icon name="plus" />
      </span>
      <span className="font-semibold">{label}</span>
      {hint && <span className="muted text-xs">{hint}</span>}
      <input
        ref={ref}
        hidden
        type="file"
        accept={accept}
        multiple={multiple}
        onChange={(e) => {
          if (e.target.files?.length) onFiles(e.target.files);
          e.target.value = "";
        }}
      />
    </button>
  );
}

export function Compare({ before, after, beforeLabel, afterLabel }: { before: string; after: string; beforeLabel: string; afterLabel: string }) {
  const ref = useRef<HTMLDivElement>(null);
  const [pos, setPos] = useState(56);
  const [width, setWidth] = useState(0);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const apply = () => setWidth(el.clientWidth);
    apply();
    const ro = new ResizeObserver(apply);
    ro.observe(el);
    return () => ro.disconnect();
  }, [before, after]);
  const fromX = (clientX: number) => {
    const el = ref.current;
    if (!el) return;
    const r = el.getBoundingClientRect();
    const x = Math.min(r.width, Math.max(0, clientX - r.left));
    setPos((x / Math.max(1, r.width)) * 100);
  };
  return (
    <div className="space-y-3">
      <div
        ref={ref}
        className="relative overflow-hidden rounded-[24px] bg-black select-none touch-none"
        onPointerDown={(e) => {
          (e.currentTarget as HTMLDivElement).setPointerCapture(e.pointerId);
          fromX(e.clientX);
        }}
        onPointerMove={(e) => {
          if (e.currentTarget.hasPointerCapture(e.pointerId)) fromX(e.clientX);
        }}
      >
        <img src={after} alt="" draggable={false} className="block w-full h-auto" />
        <div className="absolute inset-y-0 overflow-hidden" style={{ width: `${pos}%`, left: 0 }}>
          <img src={before} alt="" draggable={false} className="absolute top-0 h-full max-w-none" style={{ width: width || "100%", left: 0 }} />
        </div>
        <div className="pointer-events-none absolute inset-y-0 w-0.5 bg-white" style={{ left: `${pos}%` }} />
        <div className="pointer-events-none absolute top-1/2 grid h-11 w-11 -translate-x-1/2 -translate-y-1/2 place-items-center rounded-full bg-white text-[var(--ink)] shadow-lg" style={{ left: `${pos}%` }}>
          <Icon name="split" />
        </div>
        <span className="absolute start-3 top-3 rounded-full bg-black/55 px-2 py-1 text-[11px] font-semibold text-white">{beforeLabel}</span>
        <span className="absolute end-3 top-3 rounded-full bg-black/55 px-2 py-1 text-[11px] font-semibold text-white">{afterLabel}</span>
      </div>
      <input aria-label={`${beforeLabel} ${afterLabel}`} type="range" min={0} max={100} value={pos} onChange={(e) => setPos(Number(e.target.value))} />
    </div>
  );
}

export function FieldLabel({ children }: { children: ReactNode }) {
  return <p className="mb-2 text-xs font-semibold uppercase tracking-[0.14em] text-[var(--muted)]">{children}</p>;
}

export function Seg({ value, options, onChange }: { value: string; options: { id: string; label: string; disabled?: boolean }[]; onChange: (id: string) => void }) {
  return (
    <div className="flex flex-wrap gap-2">
      {options.map((opt) => (
        <button key={opt.id} type="button" disabled={opt.disabled} onClick={() => onChange(opt.id)} className={cn("chip", value === opt.id && "chip-on", opt.disabled && "opacity-40")}>
          {opt.label}
        </button>
      ))}
    </div>
  );
}

export function colorOf(cat: CategoryId) {
  return CAT_COLOR[cat];
}

/** Future ad placement. Intentionally empty. */
export function AdSlot() {
  return null;
}
