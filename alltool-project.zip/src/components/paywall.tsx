import { useApp, FREE_LIMIT } from "../store";

const PRICE = "1 500 FCFA";

function txt(lang: string) {
  const fr = lang === "fr" || lang === "ln";
  return fr
    ? {
        introTitle: "Version gratuite",
        introBody: `Tu peux tester chaque outil ${FREE_LIMIT} fois gratuitement. Ensuite, Premium à vie (${PRICE}, paiement unique) débloque tout, sans publicité.`,
        ok: "J'ai compris",
        wallTitle: "Essais gratuits terminés",
        wallBody: `Tu as utilisé tes ${FREE_LIMIT} essais pour cet outil. Passe à Premium à vie (${PRICE}, une seule fois) pour tout débloquer.`,
        see: "Voir Premium",
        later: "Plus tard",
      }
    : {
        introTitle: "Free version",
        introBody: `You can try each tool ${FREE_LIMIT} times for free. After that, lifetime Premium (${PRICE}, one-time payment) unlocks everything, with no ads.`,
        ok: "Got it",
        wallTitle: "Free tries used up",
        wallBody: `You used your ${FREE_LIMIT} tries for this tool. Get lifetime Premium (${PRICE}, one time) to unlock everything.`,
        see: "See Premium",
        later: "Later",
      };
}

function Card({ title, body, primary, onPrimary, secondary, onSecondary }: { title: string; body: string; primary: string; onPrimary: () => void; secondary?: string; onSecondary?: () => void }) {
  return (
    <div className="fixed inset-0 z-[70] grid place-items-center bg-black/50 px-5">
      <div className="solid hairline w-full max-w-sm rounded-[28px] p-6 text-center shadow-2xl">
        <h2 className="display text-2xl font-extrabold">{title}</h2>
        <p className="muted mt-3 text-sm leading-relaxed">{body}</p>
        <button type="button" onClick={onPrimary} className="brand-btn mt-5 h-12 w-full rounded-2xl font-semibold">{primary}</button>
        {secondary && (
          <button type="button" onClick={onSecondary} className="mt-3 w-full text-sm font-semibold text-[var(--muted)]">{secondary}</button>
        )}
      </div>
    </div>
  );
}

export function TrialModals() {
  const app = useApp();
  const x = txt(app.lang);
  if (app.paywall) {
    return (
      <Card
        title={x.wallTitle}
        body={x.wallBody}
        primary={x.see}
        onPrimary={() => {
          app.closePaywall();
          app.go({ name: "premium" });
        }}
        secondary={x.later}
        onSecondary={app.closePaywall}
      />
    );
  }
  if (app.onboarded && !app.trialSeen && !app.premium) {
    return <Card title={x.introTitle} body={x.introBody} primary={x.ok} onPrimary={app.markTrialSeen} />;
  }
  return null;
}
