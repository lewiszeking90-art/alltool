import { useEffect, useMemo, useState } from "react";
import type { ReactNode } from "react";
import { LANGS } from "../i18n";
import type { MsgKey } from "../i18n";
import { useApp } from "../store";
import { TOOL_META } from "../types";
import type { PickedFile, ToolId } from "../types";
import { AppError } from "../lib/util";
import { formatBytes, formatClock, makeName, toSrt, uid } from "../lib/util";
import {
  audioFromFiles,
  combineImages,
  compressVideo,
  enhanceImage,
  estimateVideo,
  imagesToPdf,
  loadImage,
  mergeVideos,
  pickVideoMime,
  probeAudio,
  probeVideo,
  renderEnhanced,
  searchablePdf,
  textToPdf,
  type EnhanceOpts,
  type MarginName,
  type Orientation,
  type PageFormat,
} from "../lib/media";
import { downloadVideo, recognizeCanvas, renderPdfPages, translateText } from "../lib/net";
import { speakText } from "../lib/speech";
import { recordMic, whisperTranscribe } from "../lib/whisper";
import { FREE_LIMIT } from "../store";
import { Badge, Compare, FieldLabel, Icon, IconButton, Picker, Seg } from "../components/ui";
import { cn } from "../utils/cn";

const liveText = {
  value: "",
  subs: new Set<(s: string) => void>(),
  set(s: string) {
    this.value = s;
    this.subs.forEach((fn) => fn(s));
  },
};

export function ToolScreen({ id }: { id: ToolId }) {
  switch (id) {
    case "video-download":
      return <DownloadTool />;
    case "video-compress":
      return <CompressTool />;
    case "video-merge":
      return <MergeVideoTool />;
    case "audio-extract":
      return <ExtractTool />;
    case "audio-merge":
      return <MergeAudioTool />;
    case "tts":
      return <TtsTool />;
    case "transcribe":
      return <TranscribeTool />;
    case "images-pdf":
      return <ImagesPdfTool />;
    case "images-combine":
      return <CombineTool />;
    case "image-enhance":
      return <EnhanceTool />;
    case "ocr":
      return <OcrTool handwriting={false} />;
    case "handwriting":
      return <OcrTool handwriting />;
    case "text-pdf":
      return <TextPdfTool />;
    case "translate":
      return <TranslateTool />;
    default:
      return null;
  }
}

function ToolFrame({ id, children, canStart, onStart, finishable }: { id: ToolId; children: ReactNode; canStart: boolean; onStart: () => void; finishable?: boolean }) {
  const app = useApp();
  const job = [...app.queue].find((q) => q.tool === id && (q.status === "running" || q.status === "queued"));
  const fav = app.favorites.includes(id);
  const left = Math.max(0, FREE_LIMIT - (app.usage[id] || 0));
  const fr = app.lang === "fr" || app.lang === "ln";
  return (
    <div className="rise mx-auto w-full max-w-3xl">
      <header className="mb-5 flex items-start gap-3">
        <IconButton label={app.t("action.back")} onClick={() => app.go({ name: "home" })}>
          <Icon name="back" className="rtl:scale-x-[-1]" />
        </IconButton>
        <div className="min-w-0 flex-1">
          <Badge online={TOOL_META[id].online} label={app.t(TOOL_META[id].online ? "badge.online" : "badge.local")} />
          <h1 className="display mt-2 text-3xl font-extrabold leading-none">{app.t(`tool.${id}` as MsgKey)}</h1>
          <p className="muted mt-2 text-sm leading-relaxed">{app.t(`tool.${id}.d` as MsgKey)}</p>
          {!app.premium && (
            <p className="mt-2 inline-block rounded-full bg-black/5 px-3 py-1 text-xs font-semibold">
              {left > 0 ? (fr ? `${left} essai${left > 1 ? "s" : ""} gratuit${left > 1 ? "s" : ""} restant${left > 1 ? "s" : ""}` : `${left} free ${left > 1 ? "tries" : "try"} left`) : fr ? "Essais gratuits terminés" : "Free tries used up"}
            </p>
          )}
        </div>
        <button type="button" aria-label={app.t("home.favorites")} onClick={() => app.toggleFav(id)} className={cn("grid h-11 w-11 place-items-center rounded-2xl", fav ? "text-amber-500" : "text-[var(--muted)]")}>
          <Icon name={fav ? "starFill" : "star"} />
        </button>
      </header>
      <div className="space-y-4">{children}</div>
      <div className="sticky bottom-24 z-20 mt-6 lg:bottom-4">
        {job ? (
          <div className="solid hairline rounded-[24px] p-4 shadow-lg">
            <div className="mb-2 flex justify-between text-sm font-semibold">
              <span>{job.status === "queued" ? app.t("progress.waiting") : app.t("progress.working")}</span>
              <span className="tabular-nums">{Math.round(job.progress)}%</span>
            </div>
            <div className="h-2 overflow-hidden rounded-full bg-[var(--line)]">
              <div className="h-full rounded-full bg-gradient-to-r from-indigo-500 to-violet-500 transition-[width]" style={{ width: `${job.progress}%` }} />
            </div>
            {job.statusKey && <p className="mt-2 text-xs leading-relaxed">{app.t(job.statusKey as MsgKey)}</p>}
            <div className="mt-3 grid grid-cols-2 gap-2">
              {finishable && job.status === "running" && (
                <button type="button" className="brand-btn h-12 rounded-2xl font-semibold" onClick={() => app.finish(job.id)}>
                  {app.t("action.finish")}
                </button>
              )}
              <button type="button" className={cn("ghost-btn h-12 rounded-2xl font-semibold", !(finishable && job.status === "running") && "col-span-2")} onClick={() => app.cancel(job.id)}>
                {app.t("action.cancel")}
              </button>
            </div>
          </div>
        ) : (
          <button type="button" className="brand-btn h-14 w-full rounded-2xl text-base font-semibold" disabled={!canStart} onClick={onStart}>
            {app.t("action.start")}
          </button>
        )}
      </div>
    </div>
  );
}

function usePicked(kind: "image" | "video" | "audio" | "doc", single = false) {
  const [files, setFiles] = useState<PickedFile[]>([]);
  async function add(list: FileList) {
    const next: PickedFile[] = [];
    for (const file of Array.from(list).slice(0, single ? 1 : list.length)) {
      const url = URL.createObjectURL(file);
      const item: PickedFile = { id: uid(), file, url, rotation: 0 };
      if (file.type.startsWith("image/") || kind === "image") {
        item.thumb = url;
        try {
          const img = await loadImage(url);
          item.width = img.naturalWidth;
          item.height = img.naturalHeight;
        } catch {
          /* thumb still usable */
        }
      } else if (file.type.startsWith("video/") || kind === "video") {
        try {
          const meta = await probeVideo(file);
          item.thumb = meta.thumb;
          item.duration = meta.duration;
          item.width = meta.width;
          item.height = meta.height;
        } catch {
          /* optional */
        }
      } else if (kind === "audio" || file.type.startsWith("audio/")) {
        item.duration = await probeAudio(file);
      }
      next.push(item);
    }
    setFiles((prev) => {
      if (single) prev.forEach((f) => URL.revokeObjectURL(f.url));
      return single ? next : [...prev, ...next];
    });
  }
  function remove(id: string) {
    setFiles((prev) => {
      const hit = prev.find((f) => f.id === id);
      if (hit) URL.revokeObjectURL(hit.url);
      return prev.filter((f) => f.id !== id);
    });
  }
  function move(id: string, dir: -1 | 1) {
    setFiles((prev) => {
      const i = prev.findIndex((f) => f.id === id);
      const j = i + dir;
      if (i < 0 || j < 0 || j >= prev.length) return prev;
      const copy = [...prev];
      const [item] = copy.splice(i, 1);
      copy.splice(j, 0, item);
      return copy;
    });
  }
  function rotate(id: string) {
    setFiles((prev) => prev.map((f) => (f.id === id ? { ...f, rotation: (f.rotation + 90) % 360 } : f)));
  }
  return { files, add, remove, move, rotate };
}

function FileCards({ files, lang, onRemove, onMove, onRotate, showRotate }: { files: PickedFile[]; lang: "fr" | "en" | "es" | "de" | "pt" | "it" | "ar" | "zh" | "sw" | "ln"; onRemove: (id: string) => void; onMove?: (id: string, dir: -1 | 1) => void; onRotate?: (id: string) => void; showRotate?: boolean }) {
  const app = useApp();
  if (!files.length) return null;
  return (
    <div className="space-y-2">
      {files.map((file, index) => (
        <article key={file.id} className="solid hairline flex items-center gap-3 rounded-[22px] p-2">
          <div className="grid h-16 w-16 shrink-0 place-items-center overflow-hidden rounded-2xl bg-black/5">
            {file.thumb ? (
              <img src={file.thumb} alt="" className="h-full w-full object-cover" style={{ transform: `rotate(${file.rotation}deg)` }} />
            ) : (
              <Icon name="file" />
            )}
          </div>
          <div className="min-w-0 flex-1">
            <p className="truncate text-sm font-semibold">{file.file.name}</p>
            <p className="muted text-xs">
              {formatBytes(file.file.size, lang)}
              {file.duration ? ` · ${formatClock(file.duration)}` : ""}
              {file.width ? ` · ${file.width}×${file.height}` : ""}
            </p>
          </div>
          <div className="flex shrink-0">
            {onMove && (
              <>
                <button type="button" aria-label="up" disabled={index === 0} className="grid h-10 w-9 place-items-center disabled:opacity-30" onClick={() => onMove(file.id, -1)}>
                  <Icon name="up" className="h-4 w-4" />
                </button>
                <button type="button" aria-label="down" disabled={index === files.length - 1} className="grid h-10 w-9 place-items-center disabled:opacity-30" onClick={() => onMove(file.id, 1)}>
                  <Icon name="down" className="h-4 w-4" />
                </button>
              </>
            )}
            {showRotate && onRotate && (
              <button type="button" aria-label={app.t("common.rotate")} className="grid h-10 w-9 place-items-center" onClick={() => onRotate(file.id)}>
                <Icon name="rotate" className="h-4 w-4" />
              </button>
            )}
            <button type="button" aria-label={app.t("common.remove")} className="grid h-10 w-9 place-items-center text-rose-600" onClick={() => onRemove(file.id)}>
              <Icon name="trash" className="h-4 w-4" />
            </button>
          </div>
        </article>
      ))}
    </div>
  );
}

function NameField({ value, onChange }: { value: string; onChange: (v: string) => void }) {
  const app = useApp();
  return (
    <div>
      <FieldLabel>{app.t("common.filename")}</FieldLabel>
      <input className="field" value={value} onChange={(e) => onChange(e.target.value)} />
    </div>
  );
}

function DownloadTool() {
  const app = useApp();
  const [url, setUrl] = useState("");
  return (
    <ToolFrame
      id="video-download"
      canStart={url.trim().length > 4}
      onStart={() => {
        const link = url.trim();
        app.addLink(link.startsWith("http") ? link : `https://${link}`);
        app.start({
          tool: "video-download",
          title: link.replace(/^https?:\/\//, "").slice(0, 48),
          run: (ctx) => downloadVideo(link, ctx),
        });
      }}
    >
      <div className="flex gap-2">
        <input className="field" dir="ltr" placeholder={app.t("browser.placeholder")} value={url} onChange={(e) => setUrl(e.target.value)} />
        <button
          type="button"
          className="ghost-btn h-12 shrink-0 rounded-2xl px-3 text-sm font-semibold"
          onClick={() => void navigator.clipboard.readText().then(setUrl).catch(() => undefined)}
        >
          {app.t("action.paste")}
        </button>
      </div>
    </ToolFrame>
  );
}

function CompressTool() {
  const app = useApp();
  const picked = usePicked("video", true);
  const file = picked.files[0];
  const [preset, setPreset] = useState<"space" | "low" | "standard" | "high" | "custom">("standard");
  const [format, setFormat] = useState<"mp4" | "webm">(pickVideoMime("mp4") ? "mp4" : "webm");
  const [maxW, setMaxW] = useState(1280);
  const [bitrate, setBitrate] = useState(1600);
  const [name, setName] = useState("");
  const rates = { space: 450000, low: 800000, standard: 1600000, high: 4000000, custom: bitrate * 1000 };
  const estimate = file?.duration ? estimateVideo(file.duration, rates[preset]) : 0;
  return (
    <ToolFrame
      id="video-compress"
      canStart={!!file}
      onStart={() => {
        const current = file;
        app.start({
          tool: "video-compress",
          title: current.file.name,
          run: (ctx) => compressVideo(current.file, { preset, format, maxW, bitrate: bitrate * 1000, name: name || current.file.name }, ctx),
        });
      }}
    >
      <Picker accept="video/*" label={app.t("common.pick")} onFiles={(list) => void picked.add(list)} />
      <FileCards files={picked.files.slice(0, 1)} lang={app.lang} onRemove={picked.remove} />
      <div>
        <FieldLabel>{app.t("common.quality")}</FieldLabel>
        <Seg
          value={preset}
          onChange={(id) => setPreset(id as typeof preset)}
          options={["space", "low", "standard", "high", "custom"].map((id) => ({ id, label: app.t(`preset.${id}` as MsgKey) }))}
        />
      </div>
      {preset === "custom" && (
        <div className="space-y-3">
          <label className="block text-sm font-semibold">
            {maxW}px
            <input type="range" min={360} max={1920} step={2} value={maxW} onChange={(e) => setMaxW(Number(e.target.value))} />
          </label>
          <label className="block text-sm font-semibold">
            {bitrate} kbps
            <input type="range" min={200} max={8000} step={50} value={bitrate} onChange={(e) => setBitrate(Number(e.target.value))} />
          </label>
        </div>
      )}
      <div>
        <FieldLabel>{app.t("common.format")}</FieldLabel>
        <Seg
          value={format}
          onChange={(id) => setFormat(id as "mp4" | "webm")}
          options={[
            { id: "mp4", label: pickVideoMime("mp4") ? "MP4" : `${"MP4"} · ${app.t("common.unavailable")}`, disabled: !pickVideoMime("mp4") },
            { id: "webm", label: "WebM", disabled: !pickVideoMime("webm") },
          ]}
        />
      </div>
      {estimate > 0 && (
        <p className="text-sm">
          <span className="muted">{app.t("common.estimate")} · </span>
          <span className="font-semibold">{formatBytes(estimate, app.lang)}</span>
        </p>
      )}
      {file?.duration && file.duration > 90 && <p className="text-sm leading-relaxed">{app.t("common.long")}</p>}
      <NameField value={name} onChange={setName} />
    </ToolFrame>
  );
}

function MergeVideoTool() {
  const app = useApp();
  const picked = usePicked("video");
  const [name, setName] = useState("");
  return (
    <ToolFrame
      id="video-merge"
      canStart={picked.files.length >= 2}
      onStart={() => {
        const files = picked.files.map((f) => f.file);
        app.start({
          tool: "video-merge",
          title: files[0].name,
          run: (ctx) => mergeVideos(files, name || "fusion", ctx),
        });
      }}
    >
      <Picker accept="video/*" multiple label={app.t("common.pick")} onFiles={(list) => void picked.add(list)} />
      <FileCards files={picked.files} lang={app.lang} onRemove={picked.remove} onMove={picked.move} />
      {picked.files.some((f) => (f.duration || 0) > 60) && <p className="text-sm">{app.t("common.long")}</p>}
      <NameField value={name} onChange={setName} />
    </ToolFrame>
  );
}

function ExtractTool() {
  const app = useApp();
  const picked = usePicked("video", true);
  const file = picked.files[0];
  const [format, setFormat] = useState<"mp3" | "wav" | "m4a">("mp3");
  const [kbps, setKbps] = useState(192);
  const [name, setName] = useState("");
  return (
    <ToolFrame
      id="audio-extract"
      canStart={!!file}
      onStart={() => {
        const current = file.file;
        app.start({
          tool: "audio-extract",
          title: current.name,
          run: (ctx) => audioFromFiles([current], format, kbps, name || current.name, ctx),
        });
      }}
    >
      <Picker accept="video/*,audio/*" label={app.t("common.pick")} onFiles={(list) => void picked.add(list)} />
      <FileCards files={picked.files.slice(0, 1)} lang={app.lang} onRemove={picked.remove} />
      <div>
        <FieldLabel>{app.t("common.format")}</FieldLabel>
        <Seg value={format} onChange={(id) => setFormat(id as typeof format)} options={[{ id: "mp3", label: "MP3" }, { id: "m4a", label: "M4A" }, { id: "wav", label: "WAV" }]} />
      </div>
      {format === "mp3" && (
        <label className="block text-sm font-semibold">
          {kbps} kbps
          <input type="range" min={96} max={320} step={32} value={kbps} onChange={(e) => setKbps(Number(e.target.value))} />
        </label>
      )}
      <NameField value={name} onChange={setName} />
    </ToolFrame>
  );
}

function MergeAudioTool() {
  const app = useApp();
  const picked = usePicked("audio");
  const [format, setFormat] = useState<"mp3" | "wav" | "m4a">("mp3");
  const [kbps, setKbps] = useState(192);
  const [name, setName] = useState("");
  return (
    <ToolFrame
      id="audio-merge"
      canStart={picked.files.length >= 2}
      onStart={() => {
        const files = picked.files.map((f) => f.file);
        app.start({
          tool: "audio-merge",
          title: files[0].name,
          run: (ctx) => audioFromFiles(files, format, kbps, name || "audio", ctx),
        });
      }}
    >
      <Picker accept="audio/*,.opus,.ogg,.m4a,.mp3,.wav,.aac" multiple label={app.t("common.pick")} onFiles={(list) => void picked.add(list)} />
      <FileCards files={picked.files} lang={app.lang} onRemove={picked.remove} onMove={picked.move} />
      <Seg value={format} onChange={(id) => setFormat(id as typeof format)} options={[{ id: "mp3", label: "MP3" }, { id: "m4a", label: "M4A" }, { id: "wav", label: "WAV" }]} />
      {format === "mp3" && (
        <label className="block text-sm font-semibold">
          {kbps} kbps
          <input type="range" min={96} max={320} step={32} value={kbps} onChange={(e) => setKbps(Number(e.target.value))} />
        </label>
      )}
      <NameField value={name} onChange={setName} />
    </ToolFrame>
  );
}

function TtsTool() {
  const app = useApp();
  const [text, setText] = useState("");
  const [rate, setRate] = useState(1);
  const [pitch, setPitch] = useState(1);
  return (
    <ToolFrame
      id="tts"
      canStart={text.trim().length > 0}
      onStart={() => {
        const value = text;
        const r = rate;
        const p = pitch;
        app.start({
          tool: "tts",
          title: value.slice(0, 42),
          run: async (ctx) => {
            await speakText(value, r, p, ctx, app.lang);
            return {
              blob: new Blob([value], { type: "text/plain;charset=utf-8" }),
              fileName: makeName("voix", "txt"),
              mime: "text/plain",
              preview: "text",
              text: value,
              noteKey: "tts.noFile",
              replay: { rate: r, pitch: p },
            };
          },
        });
      }}
    >
      <textarea className="field" dir="auto" placeholder={app.t("tts.placeholder")} value={text} onChange={(e) => setText(e.target.value)} />
      <ImportTxt onText={setText} />
      <label className="block text-sm font-semibold">
        {app.t("common.speed")} · {rate.toFixed(1)}
        <input type="range" min={0.6} max={1.6} step={0.1} value={rate} onChange={(e) => setRate(Number(e.target.value))} />
      </label>
      <label className="block text-sm font-semibold">
        {app.t("common.pitch")} · {pitch.toFixed(1)}
        <input type="range" min={0.6} max={1.6} step={0.1} value={pitch} onChange={(e) => setPitch(Number(e.target.value))} />
      </label>
    </ToolFrame>
  );
}

function TranscribeTool() {
  const app = useApp();
  const picked = usePicked("audio", true);
  const [mode, setMode] = useState<"mic" | "file">("mic");
  const [lang, setLang] = useState("auto");
  const [partial, setPartial] = useState("");
  useEffect(() => {
    const fn = (s: string) => setPartial(s);
    liveText.subs.add(fn);
    return () => {
      liveText.subs.delete(fn);
    };
  }, []);
  const speechLang = lang === "auto" ? navigator.language : lang === "zh" ? "zh-CN" : lang;
  return (
    <ToolFrame
      id="transcribe"
      finishable={mode === "mic"}
      canStart={mode === "mic" || !!picked.files[0]}
      onStart={() => {
        liveText.set("");
        const fr = app.lang === "fr" || app.lang === "ln";
        const finish = (text: string, cues: { start: number; end: number; text: string }[]) => {
          if (!text.trim()) throw new AppError("err.noText");
          const srt = toSrt(cues.length ? cues : [{ start: 0, end: 2, text }]);
          return {
            blob: new Blob([text], { type: "text/plain;charset=utf-8" }),
            fileName: makeName("transcription", "txt"),
            mime: "text/plain",
            preview: "text" as const,
            text,
            extras: [{ blob: new Blob([srt], { type: "application/x-subrip" }), fileName: makeName("transcription", "srt"), labelKey: "action.save" }],
          };
        };
        if (mode === "file") {
          const file = picked.files[0].file;
          app.start({
            tool: "transcribe",
            title: file.name,
            run: async (ctx) => {
              const { text, cues } = await whisperTranscribe(file, lang, ctx, (s) => liveText.set(s), fr);
              return finish(text, cues);
            },
          });
          return;
        }
        app.start({
          tool: "transcribe",
          title: app.t("tr.mic"),
          run: async (ctx) => {
            const audio = await recordMic(ctx, (s) => liveText.set(s), fr);
            const { text, cues } = await whisperTranscribe(audio, lang, ctx, (s) => liveText.set(s), fr);
            return finish(text, cues);
          },
        });
      }}
    >
      <Seg value={mode} onChange={(id) => setMode(id as "mic" | "file")} options={[{ id: "mic", label: app.t("tr.mic") }, { id: "file", label: app.t("tr.file") }]} />
      {mode === "file" ? (
        <>
          <Picker accept="audio/*,video/*" label={app.t("common.pick")} onFiles={(list) => void picked.add(list)} />
          <FileCards files={picked.files.slice(0, 1)} lang={app.lang} onRemove={picked.remove} />
        </>
      ) : (
        <div className={cn("solid hairline rounded-[28px] p-6 text-center", partial && "listening")}>
          <Icon name="mic" className="mx-auto mb-2 h-8 w-8 text-[#5344f0]" />
          <p className="text-sm">{partial || app.t("tr.listening")}</p>
        </div>
      )}
      <div>
        <FieldLabel>{app.t("tr.lang")}</FieldLabel>
        <select className="field" value={lang} onChange={(e) => setLang(e.target.value)}>
          <option value="auto">{app.t("common.auto")}</option>
          {LANGS.map((l) => (
            <option key={l.id} value={l.id}>{l.native}</option>
          ))}
        </select>
      </div>
    </ToolFrame>
  );
}

function ImagesPdfTool() {
  const app = useApp();
  const picked = usePicked("image");
  const [format, setFormat] = useState<PageFormat>("a4");
  const [orientation, setOrientation] = useState<Orientation>("portrait");
  const [margin, setMargin] = useState<MarginName>("normal");
  const [quality, setQuality] = useState<"low" | "med" | "high">("med");
  const [name, setName] = useState("");
  return (
    <ToolFrame
      id="images-pdf"
      canStart={picked.files.length > 0}
      onStart={() => {
        const items = picked.files.map((f) => ({ file: f.file, rotation: f.rotation }));
        app.start({
          tool: "images-pdf",
          title: name || items[0].file.name,
          run: (ctx) => imagesToPdf(items, { format, orientation, margin, quality, name: name || "images" }, ctx),
        });
      }}
    >
      <Picker accept="image/*" multiple label={app.t("common.pick")} onFiles={(list) => void picked.add(list)} />
      <FileCards files={picked.files} lang={app.lang} onRemove={picked.remove} onMove={picked.move} onRotate={picked.rotate} showRotate />
      <FieldLabel>{app.t("common.page")}</FieldLabel>
      <Seg value={format} onChange={(id) => setFormat(id as PageFormat)} options={[{ id: "a4", label: "A4" }, { id: "letter", label: "Letter" }, { id: "a5", label: "A5" }]} />
      <FieldLabel>{app.t("common.orientation")}</FieldLabel>
      <Seg value={orientation} onChange={(id) => setOrientation(id as Orientation)} options={[{ id: "portrait", label: app.t("common.portrait") }, { id: "landscape", label: app.t("common.landscape") }]} />
      <FieldLabel>{app.t("common.margins")}</FieldLabel>
      <Seg value={margin} onChange={(id) => setMargin(id as MarginName)} options={[{ id: "none", label: app.t("common.none") }, { id: "small", label: app.t("common.small") }, { id: "normal", label: app.t("common.normal") }, { id: "large", label: app.t("common.large") }]} />
      <FieldLabel>{app.t("common.quality")}</FieldLabel>
      <Seg value={quality} onChange={(id) => setQuality(id as typeof quality)} options={[{ id: "low", label: app.t("preset.low") }, { id: "med", label: app.t("preset.standard") }, { id: "high", label: app.t("preset.high") }]} />
      <NameField value={name} onChange={setName} />
    </ToolFrame>
  );
}

function CombineTool() {
  const app = useApp();
  const picked = usePicked("image");
  const [dir, setDir] = useState<"vertical" | "horizontal">("vertical");
  const [gap, setGap] = useState(12);
  const [bg, setBg] = useState("#fffdf9");
  const [name, setName] = useState("");
  const [preview, setPreview] = useState("");
  const signature = picked.files.map((f) => `${f.id}:${f.rotation}`).join("|");
  useEffect(() => {
    if (picked.files.length < 2) {
      setPreview("");
      return;
    }
    let dead = false;
    const timer = window.setTimeout(() => {
      void combineImages(
        picked.files.map((f) => ({ file: f.file, rotation: f.rotation })),
        { dir, gap, bg, name: "preview" },
        { signal: new AbortController().signal, progress: () => undefined },
        900,
      )
        .then((res) => {
          if (dead || !res.blob) return;
          const url = URL.createObjectURL(res.blob);
          setPreview((old) => {
            if (old) URL.revokeObjectURL(old);
            return url;
          });
        })
        .catch(() => undefined);
    }, 280);
    return () => {
      dead = true;
      window.clearTimeout(timer);
    };
  }, [signature, dir, gap, bg, picked.files]);
  return (
    <ToolFrame
      id="images-combine"
      canStart={picked.files.length >= 2}
      onStart={() => {
        const items = picked.files.map((f) => ({ file: f.file, rotation: f.rotation }));
        app.start({
          tool: "images-combine",
          title: name || items[0].file.name,
          run: (ctx) => combineImages(items, { dir, gap, bg, name: name || "collage" }, ctx),
        });
      }}
    >
      <Picker accept="image/*" multiple label={app.t("common.pick")} onFiles={(list) => void picked.add(list)} />
      <FileCards files={picked.files} lang={app.lang} onRemove={picked.remove} onMove={picked.move} onRotate={picked.rotate} showRotate />
      <Seg value={dir} onChange={(id) => setDir(id as typeof dir)} options={[{ id: "vertical", label: app.t("common.vertical") }, { id: "horizontal", label: app.t("common.horizontal") }]} />
      <label className="block text-sm font-semibold">
        {app.t("common.gap")} · {gap}
        <input type="range" min={0} max={48} value={gap} onChange={(e) => setGap(Number(e.target.value))} />
      </label>
      <div>
        <FieldLabel>{app.t("common.background")}</FieldLabel>
        <div className="flex gap-2">
          {["#fffdf9", "#111111", "#eef2ff", "#fde68a"].map((c) => (
            <button key={c} type="button" aria-label={c} onClick={() => setBg(c)} className={cn("h-10 w-10 rounded-full border-2", bg === c ? "border-[#5344f0]" : "border-transparent")} style={{ background: c }} />
          ))}
          <input type="color" value={bg} onChange={(e) => setBg(e.target.value)} className="h-10 w-10 rounded-full border-0 bg-transparent" />
        </div>
      </div>
      {preview && <img src={preview} alt="" className="max-h-80 w-full rounded-[24px] object-contain bg-black/5" />}
      <NameField value={name} onChange={setName} />
    </ToolFrame>
  );
}

function EnhanceTool() {
  const app = useApp();
  const picked = usePicked("image", true);
  const file = picked.files[0];
  const [opts, setOpts] = useState<EnhanceOpts>({ sharp: 24, noise: 0, contrast: 10, brightness: 4, saturation: 8, scale: 1, format: "jpeg" });
  const [before, setBefore] = useState("");
  const [after, setAfter] = useState("");
  const [name, setName] = useState("");
  useEffect(() => {
    if (!file) {
      setBefore("");
      setAfter("");
      return;
    }
    let dead = false;
    const timer = window.setTimeout(() => {
      void loadImage(file.url).then(async (img) => {
        if (dead) return;
        const raw = document.createElement("canvas");
        const max = 900;
        const s = Math.min(1, max / Math.max(img.naturalWidth, img.naturalHeight));
        raw.width = Math.max(1, Math.round(img.naturalWidth * s));
        raw.height = Math.max(1, Math.round(img.naturalHeight * s));
        raw.getContext("2d")?.drawImage(img, 0, 0, raw.width, raw.height);
        const beforeUrl = raw.toDataURL("image/jpeg", 0.8);
        const out = await renderEnhanced(img, img.naturalWidth, img.naturalHeight, { ...opts, scale: 1 }, 900);
        if (dead) return;
        setBefore(beforeUrl);
        setAfter(out.toDataURL("image/jpeg", 0.82));
      });
    }, 80);
    return () => {
      dead = true;
      window.clearTimeout(timer);
    };
  }, [file, opts]);
  const set = (key: keyof EnhanceOpts, value: number | string) => setOpts((o) => ({ ...o, [key]: value }));
  return (
    <ToolFrame
      id="image-enhance"
      canStart={!!file}
      onStart={() => {
        const current = file.file;
        const chosen = opts;
        app.start({
          tool: "image-enhance",
          title: current.name,
          run: (ctx) => enhanceImage(current, chosen, name || current.name, ctx),
        });
      }}
    >
      <Picker accept="image/*" label={app.t("common.pick")} onFiles={(list) => void picked.add(list)} />
      <FileCards files={picked.files.slice(0, 1)} lang={app.lang} onRemove={picked.remove} />
      {before && after && <Compare before={before} after={after} beforeLabel={app.t("common.before")} afterLabel={app.t("common.after")} />}
      <Slider label={app.t("common.sharp")} value={opts.sharp} min={0} max={100} onChange={(v) => set("sharp", v)} />
      <Slider label={app.t("common.noise")} value={opts.noise} min={0} max={100} onChange={(v) => set("noise", v)} />
      <Slider label={app.t("common.contrast")} value={opts.contrast} min={-50} max={80} onChange={(v) => set("contrast", v)} />
      <Slider label={app.t("common.bright")} value={opts.brightness} min={-50} max={50} onChange={(v) => set("brightness", v)} />
      <Slider label={app.t("common.sat")} value={opts.saturation} min={-50} max={80} onChange={(v) => set("saturation", v)} />
      <FieldLabel>{app.t("common.scale")}</FieldLabel>
      <Seg value={String(opts.scale)} onChange={(id) => set("scale", Number(id))} options={[{ id: "1", label: "1×" }, { id: "1.5", label: "1.5×" }, { id: "2", label: "2×" }, { id: "3", label: "3×" }]} />
      <Seg value={opts.format} onChange={(id) => set("format", id)} options={[{ id: "jpeg", label: "JPEG" }, { id: "png", label: "PNG" }]} />
      <button type="button" className="text-sm font-semibold text-[var(--muted)]" onClick={() => setOpts({ sharp: 0, noise: 0, contrast: 0, brightness: 0, saturation: 0, scale: 1, format: "jpeg" })}>
        {app.t("action.reset")}
      </button>
      <NameField value={name} onChange={setName} />
    </ToolFrame>
  );
}

function Slider({ label, value, min, max, onChange }: { label: string; value: number; min: number; max: number; onChange: (v: number) => void }) {
  return (
    <label className="block text-sm font-semibold">
      <span className="flex justify-between"><span>{label}</span><span className="tabular-nums">{value}</span></span>
      <input type="range" min={min} max={max} value={value} onChange={(e) => onChange(Number(e.target.value))} />
    </label>
  );
}

function OcrTool({ handwriting }: { handwriting: boolean }) {
  const app = useApp();
  const id: ToolId = handwriting ? "handwriting" : "ocr";
  const picked = usePicked("doc", true);
  const file = picked.files[0];
  const [lang, setLang] = useState(app.lang === "ln" ? "fr" : app.lang);
  const [rotation, setRotation] = useState(0);
  const langs = LANGS.filter((l) => l.id !== "ln");
  return (
    <ToolFrame
      id={id}
      canStart={!!file}
      onStart={() => {
        const current = file;
        const chosen = lang;
        const rot = rotation;
        app.start({
          tool: id,
          title: current.file.name,
          run: async (ctx) => {
            const isPdf = current.file.type === "application/pdf" || current.file.name.toLowerCase().endsWith(".pdf");
            const pages: HTMLCanvasElement[] = [];
            let truncated = false;
            if (isPdf) {
              const rendered = await renderPdfPages(current.file, ctx);
              pages.push(...rendered.pages);
              truncated = rendered.truncated;
            } else {
              pages.push(await raster(current.file, rot));
            }
            const chunks: string[] = [];
            for (const page of pages) {
              const found = await recognizeCanvas(page, chosen, ctx, handwriting);
              chunks.push(found.text);
            }
            let text = chunks.filter(Boolean).join("\n\n").trim();
            if (!text) throw new AppError(handwriting ? "err.hand" : "err.ocr");
            if (truncated) text += `\n\n${app.t("ocr.limit")}`;
            const pdf = await searchablePdf(text, pages[0], current.file.name, ctx);
            return {
              blob: pdf,
              fileName: makeName(current.file.name, "pdf"),
              mime: "application/pdf",
              preview: "text",
              text,
              extras: [{ blob: new Blob([text], { type: "text/plain;charset=utf-8" }), fileName: makeName(current.file.name, "txt"), labelKey: "action.save" }],
            };
          },
        });
      }}
    >
      <Picker accept={handwriting ? "image/*" : "image/*,application/pdf"} label={app.t("common.pick")} onFiles={(list) => void picked.add(list)} />
      <FileCards files={picked.files.slice(0, 1)} lang={app.lang} onRemove={picked.remove} />
      {file && file.file.type.startsWith("image/") && (
        <button type="button" className="ghost-btn h-11 rounded-2xl px-4 text-sm font-semibold" onClick={() => setRotation((r) => (r + 90) % 360)}>
          {app.t("common.rotate")} · {rotation}°
        </button>
      )}
      <div>
        <FieldLabel>{app.t("ocr.lang")}</FieldLabel>
        <select className="field" value={lang} onChange={(e) => setLang(e.target.value as typeof lang)}>
          {langs.map((l) => (
            <option key={l.id} value={l.id}>{l.native}</option>
          ))}
        </select>
      </div>
    </ToolFrame>
  );
}

async function raster(file: File, rotation: number) {
  const url = URL.createObjectURL(file);
  try {
    const img = await loadImage(url);
    const rot = ((rotation % 360) + 360) % 360;
    const swap = rot === 90 || rot === 270;
    const canvas = document.createElement("canvas");
    const scale = Math.min(2, Math.max(1, 1600 / Math.max(img.naturalWidth, img.naturalHeight)));
    canvas.width = Math.round((swap ? img.naturalHeight : img.naturalWidth) * scale);
    canvas.height = Math.round((swap ? img.naturalWidth : img.naturalHeight) * scale);
    const c = canvas.getContext("2d");
    if (!c) throw new AppError("err.memory", "raster");
    c.fillStyle = "#fff";
    c.fillRect(0, 0, canvas.width, canvas.height);
    c.translate(canvas.width / 2, canvas.height / 2);
    c.rotate((rot * Math.PI) / 180);
    c.drawImage(img, (-img.naturalWidth * scale) / 2, (-img.naturalHeight * scale) / 2, img.naturalWidth * scale, img.naturalHeight * scale);
    return canvas;
  } finally {
    URL.revokeObjectURL(url);
  }
}

function TextPdfTool() {
  const app = useApp();
  const [text, setText] = useState("");
  const [title, setTitle] = useState("");
  const [format, setFormat] = useState<PageFormat>("a4");
  const [orientation, setOrientation] = useState<Orientation>("portrait");
  const [margin, setMargin] = useState<MarginName>("normal");
  const [fontPt, setFontPt] = useState(12);
  const [name, setName] = useState("");
  const preview = useMemo(() => text.split(/\s+/).filter(Boolean).length, [text]);
  return (
    <ToolFrame
      id="text-pdf"
      canStart={text.trim().length > 0}
      onStart={() => {
        const value = text;
        app.start({
          tool: "text-pdf",
          title: title || name || value.slice(0, 32),
          run: (ctx) => textToPdf(value, { format, orientation, margin, fontPt, title, name: name || title || "texte" }, ctx),
        });
      }}
    >
      <input className="field" placeholder={app.t("common.name")} value={title} onChange={(e) => setTitle(e.target.value)} />
      <textarea className="field" dir="auto" value={text} onChange={(e) => setText(e.target.value)} />
      <div className="flex items-center justify-between">
        <ImportTxt onText={setText} />
        <span className="muted text-xs">{preview} {app.t("common.words")}</span>
      </div>
      <Seg value={format} onChange={(id) => setFormat(id as PageFormat)} options={[{ id: "a4", label: "A4" }, { id: "letter", label: "Letter" }, { id: "a5", label: "A5" }]} />
      <Seg value={orientation} onChange={(id) => setOrientation(id as Orientation)} options={[{ id: "portrait", label: app.t("common.portrait") }, { id: "landscape", label: app.t("common.landscape") }]} />
      <Seg value={margin} onChange={(id) => setMargin(id as MarginName)} options={[{ id: "small", label: app.t("common.small") }, { id: "normal", label: app.t("common.normal") }, { id: "large", label: app.t("common.large") }]} />
      <Slider label={app.t("common.text")} value={fontPt} min={10} max={18} onChange={setFontPt} />
      <NameField value={name} onChange={setName} />
    </ToolFrame>
  );
}

function TranslateTool() {
  const app = useApp();
  const [text, setText] = useState("");
  const [from, setFrom] = useState("auto");
  const [to, setTo] = useState(app.lang === "fr" ? "en" : "fr");
  return (
    <ToolFrame
      id="translate"
      canStart={text.trim().length > 0 && from !== to}
      onStart={() => {
        const value = text;
        const source = from;
        const target = to;
        app.start({
          tool: "translate",
          title: value.slice(0, 42),
          run: async (ctx) => {
            const out = await translateText(value, source, target, ctx);
            return {
              blob: new Blob([out], { type: "text/plain;charset=utf-8" }),
              fileName: makeName("traduction", "txt"),
              mime: "text/plain",
              preview: "text",
              text: out,
            };
          },
        });
      }}
    >
      <div className="grid grid-cols-[1fr_auto_1fr] items-end gap-2">
        <div>
          <FieldLabel>{app.t("common.from")}</FieldLabel>
          <select className="field" value={from} onChange={(e) => setFrom(e.target.value)}>
            <option value="auto">{app.t("common.auto")}</option>
            {LANGS.map((l) => (
              <option key={l.id} value={l.id}>{l.native}</option>
            ))}
          </select>
        </div>
        <button type="button" aria-label="swap" className="mb-1 grid h-12 w-12 place-items-center rounded-2xl hairline" onClick={() => { if (from === "auto") return; const a = from; setFrom(to); setTo(a); }}>
          <Icon name="languages" />
        </button>
        <div>
          <FieldLabel>{app.t("common.to")}</FieldLabel>
          <select className="field" value={to} onChange={(e) => setTo(e.target.value)}>
            {LANGS.map((l) => (
              <option key={l.id} value={l.id}>{l.native}</option>
            ))}
          </select>
        </div>
      </div>
      <textarea className="field" dir="auto" placeholder={app.t("trsl.placeholder")} value={text} onChange={(e) => setText(e.target.value)} />
      <ImportTxt onText={setText} />
    </ToolFrame>
  );
}

function ImportTxt({ onText }: { onText: (value: string) => void }) {
  const app = useApp();
  return (
    <label className="chip inline-flex cursor-pointer">
      {app.t("common.import")}
      <input
        hidden
        type="file"
        accept=".txt,text/plain"
        onChange={(e) => {
          const f = e.target.files?.[0];
          if (f) void f.text().then(onText);
          e.target.value = "";
        }}
      />
    </label>
  );
}
