import { useState } from "react";
import { LANGS } from "../i18n";
import type { MsgKey } from "../i18n";
import { useApp } from "../store";
import { formatWhen, requestNotifPermission } from "../lib/util";
import { AdSlot, Icon } from "../components/ui";
import { cn } from "../utils/cn";
import { useAuth } from "../auth";

export function SettingsPage() {
  const app = useApp();
  const auth = useAuth();
  return (
    <div className="rise mx-auto max-w-xl">
      <h1 className="display mb-5 text-4xl font-extrabold">{app.t("settings.title")}</h1>
      {auth.user && (
        <div className="solid hairline mb-4 flex items-center justify-between gap-3 rounded-[24px] p-4">
          <div className="min-w-0">
            <p className="truncate text-sm font-semibold">{auth.user.name || auth.user.email}</p>
            <p className="muted truncate text-xs" dir="ltr">{auth.user.email}</p>
            <p className="mt-1 text-xs font-semibold">{auth.premium.active ? "Premium ✓" : "Gratuit"}</p>
          </div>
          <button type="button" onClick={() => void auth.signOut()} className="chip shrink-0">{app.lang === "fr" || app.lang === "ln" ? "Déconnexion" : "Sign out"}</button>
        </div>
      )}
      <div className="solid hairline mb-4 rounded-[24px] p-4">
        <label className="text-xs font-semibold uppercase tracking-[0.14em] text-[var(--muted)]">{app.t("settings.name")}</label>
        <input value={app.name} onChange={(e) => app.setName(e.target.value)} className="field mt-2" />
      </div>
      <Group title={app.t("settings.language")}>
        <div className="grid grid-cols-2 gap-2">
          {LANGS.map((l) => (
            <button key={l.id} type="button" onClick={() => app.setLang(l.id)} className={cn("rounded-2xl border px-3 py-3 text-start text-sm font-semibold", app.lang === l.id ? "border-transparent bg-[var(--ink)] text-[var(--bg)]" : "border-[var(--line)]")}>
              {l.native}
            </button>
          ))}
        </div>
      </Group>
      <Group title={app.t("settings.theme")}>
        <div className="flex gap-2">
          {(["light", "dark", "system"] as const).map((mode) => (
            <button key={mode} type="button" onClick={() => app.setTheme(mode)} className={cn("chip flex-1", app.theme === mode && "chip-on")}>
              {app.t(mode === "light" ? "settings.light" : mode === "dark" ? "settings.dark" : "settings.system")}
            </button>
          ))}
        </div>
      </Group>
      <div className="solid hairline mb-3 overflow-hidden rounded-[24px]">
        <Row label={app.t("settings.notifications")} value={app.notif === "granted" ? app.t("settings.notifOn") : app.t("settings.notifOff")} onClick={() => { void requestNotifPermission().then(app.setNotif); }} />
        <Row label={app.t("settings.errors")} onClick={() => app.go({ name: "errors" })} />
        <Row label={app.t("settings.privacy")} onClick={() => app.go({ name: "privacy" })} />
        <Row label={app.t("settings.premium")} onClick={() => app.go({ name: "premium" })} />
      </div>
      <div className="solid hairline mb-4 overflow-hidden rounded-[24px]">
        <Row label={app.t("settings.clearHistory")} danger onClick={() => { if (window.confirm(app.t("history.confirm"))) { app.clearHistory(); app.showToast(app.t("settings.cleared")); } }} />
        <Row label={app.t("settings.clearFavorites")} danger onClick={() => { if (window.confirm(app.t("fav.confirm"))) { app.clearFavorites(); app.showToast(app.t("settings.cleared")); } }} />
      </div>
      <AdSlot />
      <p className="mt-6 text-center text-sm font-semibold">AllTool — Version 1.0.0</p>
    </div>
  );
}

function Group({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="mb-4">
      <h2 className="mb-2 px-1 text-xs font-semibold uppercase tracking-[0.14em] text-[var(--muted)]">{title}</h2>
      {children}
    </section>
  );
}

function Row({ label, value, onClick, danger }: { label: string; value?: string; onClick: () => void; danger?: boolean }) {
  return (
    <button type="button" onClick={onClick} className={cn("flex w-full items-center justify-between gap-3 border-b border-[var(--line)] px-4 py-4 text-start last:border-b-0", danger && "text-rose-600")}>
      <span className="font-semibold">{label}</span>
      <span className="muted flex items-center gap-1 text-sm">
        {value}
        <Icon name="back" className="h-4 w-4 rotate-180 rtl:rotate-0" />
      </span>
    </button>
  );
}

export function ErrorsPage() {
  const app = useApp();
  const [open, setOpen] = useState<string | null>(null);
  const text = app.errors
    .map((e) => `${formatWhen(e.at, app.lang)} · ${e.tool || ""}\n${app.t(e.messageKey as MsgKey)}\n${e.detail}`)
    .join("\n\n");
  return (
    <div className="rise mx-auto max-w-xl">
      <button type="button" onClick={() => app.go({ name: "settings" })} className="mb-3 flex items-center gap-1 text-sm font-semibold text-[var(--muted)]">
        <Icon name="back" className="h-4 w-4 rtl:scale-x-[-1]" /> {app.t("action.back")}
      </button>
      <h1 className="display mb-4 text-4xl font-extrabold">{app.t("errors.title")}</h1>
      <div className="mb-4 flex gap-2">
        <button type="button" className="brand-btn h-11 rounded-2xl px-4 text-sm font-semibold" onClick={() => { void navigator.clipboard.writeText(text); app.showToast(app.t("action.copied")); }} disabled={!app.errors.length}>
          {app.t("errors.copyAll")}
        </button>
        <button type="button" className="ghost-btn h-11 rounded-2xl px-4 text-sm font-semibold" onClick={app.clearErrors} disabled={!app.errors.length}>
          {app.t("errors.clear")}
        </button>
      </div>
      {app.errors.length === 0 && <p className="muted">{app.t("errors.empty")}</p>}
      <div className="space-y-2">
        {app.errors.map((e) => (
          <article key={e.id} className="solid hairline rounded-2xl p-4">
            <p className="text-xs text-[var(--muted)]">{formatWhen(e.at, app.lang)} {e.tool ? `· ${app.t(`tool.${e.tool}` as MsgKey)}` : ""}</p>
            <p className="mt-1 font-semibold">{app.t(e.messageKey as MsgKey)}</p>
            <button type="button" className="mt-2 text-xs font-semibold text-[#5344f0]" onClick={() => setOpen(open === e.id ? null : e.id)}>{app.t("errors.tech")}</button>
            {open === e.id && (
              <pre className="mt-2 max-h-40 overflow-auto whitespace-pre-wrap rounded-xl bg-black/5 p-2 text-xs" dir="ltr">{e.detail}</pre>
            )}
            <button type="button" className="mt-2 text-xs font-semibold" onClick={() => { void navigator.clipboard.writeText(`${app.t(e.messageKey as MsgKey)}\n${e.detail}`); app.showToast(app.t("action.copied")); }}>{app.t("action.copy")}</button>
          </article>
        ))}
      </div>
    </div>
  );
}

export function PrivacyPage() {
  const app = useApp();
  return (
    <div className="rise mx-auto max-w-xl">
      <button type="button" onClick={() => app.go({ name: "settings" })} className="mb-3 flex items-center gap-1 text-sm font-semibold text-[var(--muted)]">
        <Icon name="back" className="h-4 w-4 rtl:scale-x-[-1]" /> {app.t("action.back")}
      </button>
      <h1 className="display mb-4 text-4xl font-extrabold">{app.t("privacy.title")}</h1>
      <div className="space-y-4 text-sm leading-relaxed">
        <p>{app.t("privacy.p1")}</p>
        <p>{app.t("privacy.p2")}</p>
        <p>{app.t("privacy.p3")}</p>
      </div>
    </div>
  );
}

export function PremiumPage() {
  const app = useApp();
  const auth = useAuth();
  const fr = app.lang === "fr" || app.lang === "ln";
  const until = auth.premium.until ? new Date(auth.premium.until).toLocaleDateString() : null;
  return (
    <div className="rise mx-auto max-w-xl">
      <button type="button" onClick={() => app.go({ name: "settings" })} className="mb-3 flex items-center gap-1 text-sm font-semibold text-[var(--muted)]">
        <Icon name="back" className="h-4 w-4 rtl:scale-x-[-1]" /> {app.t("action.back")}
      </button>
      <div className="overflow-hidden rounded-[32px] bg-gradient-to-br from-[#4f46e5] to-[#8b5cf6] p-6 text-white">
        <p className="text-xs font-semibold uppercase tracking-[0.16em] text-white/70">{fr ? "Premium à vie" : "Lifetime Premium"}</p>
        <h1 className="display mt-2 text-4xl font-extrabold">{"AllTool Premium"}</h1>
        <p className="mt-3 text-sm leading-relaxed text-white/85">{fr ? "Gratuit : 3 essais par outil. Pour tout débloquer sans limite : 1 500 FCFA, paiement unique, valable à vie." : "Free: 3 tries per tool. Unlock everything with no limit: 1,500 FCFA, one-time payment, valid for life."}</p>
        <ul className="mt-5 space-y-2 text-sm">
          <li>• {fr ? "Tous les outils, sans limite" : "Every tool, no limit"}</li>
          <li>• {fr ? "Un seul paiement, à vie" : "One payment, for life"}</li>
          <li>• {fr ? "Aucune publicité" : "No ads"}</li>
        </ul>
        {auth.user && (
          <div className="mt-5 rounded-2xl bg-white/15 p-3 text-sm">
            <p className="font-semibold">
              {auth.premium.active ? (fr ? "Ton abonnement Premium est actif" : "Your Premium is active") + (until ? ` · ${until}` : "") : fr ? "Compte gratuit" : "Free account"}
            </p>
            <p className="mt-1 text-xs text-white/80" dir="ltr">{auth.user.email} · {auth.user.uid.slice(0, 8)}</p>
          </div>
        )}
        <button type="button" disabled className="mt-6 h-12 w-full rounded-2xl bg-white/20 font-semibold">{fr ? "Paiement bientôt disponible" : "Payment coming soon"}</button>
      </div>
    </div>
  );
}
