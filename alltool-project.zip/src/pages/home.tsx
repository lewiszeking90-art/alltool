import { useMemo, useState } from "react";
import { CATEGORIES, TOOLS_BY_CAT, TOOL_META } from "../types";
import type { ToolId } from "../types";
import type { MsgKey } from "../i18n";
import { useApp } from "../store";
import { formatDate } from "../lib/util";
import { AdSlot, Icon, Logo, catIcon, colorOf, toolIcon } from "../components/ui";
import { cn } from "../utils/cn";

export function Home() {
  const app = useApp();
  const [q, setQ] = useState("");
  const hour = new Date().getHours();
  const greet = hour < 12 ? "greet.morning" : hour < 18 ? "greet.afternoon" : "greet.evening";
  const query = q.trim().toLowerCase();
  const matches = useMemo(() => {
    if (!query) return null;
    return (Object.keys(TOOL_META) as ToolId[]).filter((id) => {
      const name = app.t(`tool.${id}` as MsgKey).toLowerCase();
      const desc = app.t(`tool.${id}.d` as MsgKey).toLowerCase();
      return name.includes(query) || desc.includes(query) || id.includes(query);
    });
  }, [query, app]);

  return (
    <div className="rise mx-auto max-w-5xl">
      <section className="relative overflow-hidden rounded-[32px] bg-gradient-to-br from-[#4f46e5] via-[#6842ee] to-[#8b5cf6] px-5 py-6 text-white shadow-[0_24px_50px_-28px_rgba(79,70,229,0.9)] sm:px-7 sm:py-8">
        <div className="pointer-events-none absolute -end-6 -top-8 opacity-30">
          <Logo size={150} />
        </div>
        <p className="text-sm font-medium text-white/80">{formatDate(Date.now(), app.lang)}</p>
        <h1 className="display mt-3 text-4xl font-extrabold leading-[0.95] sm:text-5xl">
          {app.t(greet)}
          {app.name ? "," : ""}
        </h1>
        {app.name && <p className="display text-4xl font-extrabold leading-[0.95] sm:text-5xl">{app.name}</p>}
        <p className="mt-4 max-w-md text-sm leading-relaxed text-white/85 sm:text-base">{app.t("home.tagline")}</p>
      </section>

      <label className="mt-4 flex items-center gap-3 rounded-[22px] border border-[var(--line)] bg-[var(--card-solid)] px-4 py-3 shadow-[var(--shadow)]">
        <Icon name="search" className="text-[var(--muted)]" />
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder={app.t("home.search")} className="w-full bg-transparent outline-none" />
      </label>

      {matches && (
        <section className="mt-5">
          {matches.length === 0 ? (
            <p className="muted px-1 py-6 text-sm">{app.t("home.noResults")}</p>
          ) : (
            <div className="grid gap-2 sm:grid-cols-2">
              {matches.map((id) => (
                <ToolRow key={id} id={id} />
              ))}
            </div>
          )}
        </section>
      )}

      {!matches && (
        <>
          <Section title={app.t("home.recents")}>
            {app.recents.length === 0 ? (
              <p className="muted text-sm">{app.t("home.recentEmpty")}</p>
            ) : (
              <div className="scrollbar-none -mx-1 flex gap-2 overflow-x-auto px-1 pb-1">
                {app.recents.map((id) => (
                  <button key={id} type="button" onClick={() => app.openTool(id)} className="solid hairline flex shrink-0 items-center gap-2 rounded-2xl px-3 py-2 text-sm font-semibold">
                    <span className="grid h-8 w-8 place-items-center rounded-xl text-white" style={{ background: colorOf(TOOL_META[id].cat) }}>
                      <Icon name={toolIcon(id)} className="h-4 w-4" />
                    </span>
                    {app.t(`tool.${id}` as MsgKey)}
                  </button>
                ))}
              </div>
            )}
          </Section>

          <Section title={app.t("home.favorites")}>
            {app.favorites.length === 0 ? (
              <p className="muted text-sm">{app.t("home.favEmpty")}</p>
            ) : (
              <div className="grid gap-2 sm:grid-cols-2">
                {app.favorites.map((id) => (
                  <ToolRow key={id} id={id} />
                ))}
              </div>
            )}
          </Section>

          {CATEGORIES.map((cat, index) => (
            <section key={cat} className="mt-8">
              <div className="mb-3 flex items-end gap-3 px-1">
                <span className="display text-3xl font-extrabold text-[#5344f0]/70">{String(index + 1).padStart(2, "0")}</span>
                <div>
                  <p className="flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.16em] text-[var(--muted)]">
                    <Icon name={catIcon(cat)} className="h-4 w-4" />
                    {app.t(`cat.${cat}` as MsgKey)}
                  </p>
                </div>
              </div>
              <div className="grid gap-2 sm:grid-cols-2">
                {TOOLS_BY_CAT[cat].map((id) => (
                  <ToolRow key={id} id={id} />
                ))}
              </div>
            </section>
          ))}
          <AdSlot />
        </>
      )}
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="mt-7">
      <h2 className="mb-3 px-1 text-xs font-semibold uppercase tracking-[0.16em] text-[var(--muted)]">{title}</h2>
      {children}
    </section>
  );
}

function ToolRow({ id }: { id: ToolId }) {
  const app = useApp();
  const fav = app.favorites.includes(id);
  const cat = TOOL_META[id].cat;
  return (
    <div className={cn("solid hairline flex items-center gap-3 rounded-[22px] p-3 shadow-[var(--shadow)]")}>
      <button type="button" onClick={() => app.openTool(id)} className="flex min-w-0 flex-1 items-center gap-3 text-start">
        <span className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl text-white" style={{ background: colorOf(cat) }}>
          <Icon name={toolIcon(id)} />
        </span>
        <span className="min-w-0">
          <span className="block truncate font-semibold">{app.t(`tool.${id}` as MsgKey)}</span>
          <span className="muted block truncate text-xs">{app.t(`tool.${id}.d` as MsgKey)}</span>
        </span>
      </button>
      <button type="button" aria-label={app.t("home.favorites")} onClick={() => app.toggleFav(id)} className={cn("grid h-10 w-10 place-items-center rounded-xl", fav ? "text-amber-500" : "text-[var(--muted)]")}>
        <Icon name={fav ? "starFill" : "star"} />
      </button>
    </div>
  );
}
