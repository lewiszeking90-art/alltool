import { useState } from "react";
import { useApp } from "../store";
import { downloadVideo } from "../lib/net";
import { normalizeUrl } from "../lib/util";
import { Icon } from "../components/ui";

const BLOCKED = /youtube\.com|youtu\.be|tiktok\.com|instagram\.com|facebook\.com|fb\.watch|fb\.com|twitter\.com|x\.com/i;

export function BrowserPage() {
  const app = useApp();
  const [input, setInput] = useState("");
  const [url, setUrl] = useState("");
  const [stack, setStack] = useState<string[]>([]);
  const [index, setIndex] = useState(-1);
  const blocked = url ? BLOCKED.test(url) : false;
  const detected = Boolean(url);

  const visit = (raw: string) => {
    const next = normalizeUrl(raw);
    if (!next) return;
    const history = stack.slice(0, index + 1);
    history.push(next);
    setStack(history);
    setIndex(history.length - 1);
    setUrl(next);
    setInput(next);
    app.addLink(next);
  };

  const download = () => {
    if (!url) return;
    app.start({
      tool: "video-download",
      title: url.replace(/^https?:\/\//, "").slice(0, 42),
      run: (ctx) => downloadVideo(url, ctx),
    });
    app.go({ name: "queue" });
  };

  return (
    <div className="rise mx-auto flex max-w-5xl flex-col gap-3">
      <div className="solid hairline flex items-center gap-2 rounded-[22px] p-2 shadow-[var(--shadow)]">
        <button type="button" aria-label={app.t("action.back")} disabled={index <= 0} onClick={() => { const i = index - 1; setIndex(i); setUrl(stack[i]); setInput(stack[i]); }} className="grid h-10 w-10 place-items-center rounded-xl disabled:opacity-30">
          <Icon name="back" className="rtl:scale-x-[-1]" />
        </button>
        <form
          className="flex min-w-0 flex-1 items-center gap-2"
          onSubmit={(e) => {
            e.preventDefault();
            visit(input);
          }}
        >
          <Icon name="globe" className="hidden text-[var(--muted)] sm:block" />
          <input value={input} onChange={(e) => setInput(e.target.value)} placeholder={app.t("browser.placeholder")} className="w-full bg-transparent text-sm outline-none" dir="ltr" />
          <button type="submit" className="brand-btn h-10 shrink-0 rounded-xl px-3 text-sm font-semibold">{app.t("browser.go")}</button>
        </form>
      </div>

      {detected && (
        <div className="flex items-center justify-between gap-3 rounded-[22px] bg-[var(--ink)] px-4 py-3 text-[var(--bg)]">
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.14em] opacity-70">{app.t("browser.detected")}</p>
            <p className="text-sm font-semibold">{app.t("browser.download")}</p>
          </div>
          <button type="button" onClick={download} className="brand-btn h-11 rounded-2xl px-4 text-sm font-semibold">
            {app.t("browser.download")}
          </button>
        </div>
      )}

      <div className="solid hairline min-h-[62vh] overflow-hidden rounded-[28px] shadow-[var(--shadow)]">
        {!url && (
          <div className="flex h-[62vh] flex-col items-center justify-center px-6 text-center">
            <Icon name="compass" className="mb-3 h-8 w-8 text-[#5344f0]" />
            <p className="max-w-sm text-sm leading-relaxed">{app.t("browser.empty")}</p>
            {app.links.length > 0 && (
              <div className="mt-6 w-full max-w-md text-start">
                <p className="mb-2 text-xs font-semibold uppercase tracking-[0.14em] text-[var(--muted)]">{app.t("browser.recent")}</p>
                <div className="space-y-2">
                  {app.links.map((link) => (
                    <button key={link} type="button" onClick={() => visit(link)} className="block w-full truncate rounded-2xl bg-black/5 px-3 py-2 text-start text-sm" dir="ltr">
                      {link}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
        {url && blocked && (
          <div className="flex h-[62vh] flex-col items-center justify-center px-6 text-center">
            <p className="max-w-sm text-sm leading-relaxed">{app.t("err.browser")}</p>
            <p className="muted mt-3 max-w-sm truncate text-xs" dir="ltr">{url}</p>
          </div>
        )}
        {url && !blocked && (
          <iframe title="AllTool" src={url} className="h-[70vh] w-full bg-white" allow="autoplay; encrypted-media; fullscreen; picture-in-picture" />
        )}
      </div>
    </div>
  );
}
