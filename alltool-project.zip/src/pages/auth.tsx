import { useState } from "react";
import { useApp } from "../store";
import { useAuth } from "../auth";
import { Logo } from "../components/ui";

const FR = {
  create: "Créer un compte",
  login: "Se connecter",
  name: "Ton prénom",
  email: "Adresse e-mail",
  password: "Mot de passe (6 caractères minimum)",
  forgot: "Mot de passe oublié ?",
  sent: "E-mail de réinitialisation envoyé. Vérifie ta boîte de réception.",
  wait: "Patiente…",
  needName: "Écris ton prénom.",
  intro: "Crée ton compte pour retrouver ton abonnement Premium sur tous tes appareils.",
  toolReason: "Crée un compte gratuit pour utiliser cet outil. Ça prend 30 secondes.",
  e_exists: "Cet e-mail a déjà un compte. Connecte-toi.",
  e_bad: "E-mail ou mot de passe incorrect.",
  e_weak: "Mot de passe trop court (6 caractères minimum).",
  e_mail: "Adresse e-mail invalide.",
  e_net: "Pas de connexion internet. Réessaie avec le réseau.",
  e_other: "Une erreur est survenue. Réessaie.",
};
const EN: typeof FR = {
  create: "Create account",
  login: "Sign in",
  name: "Your first name",
  email: "Email address",
  password: "Password (6 characters minimum)",
  forgot: "Forgot password?",
  sent: "Reset email sent. Check your inbox.",
  wait: "Please wait…",
  needName: "Enter your first name.",
  intro: "Create your account to keep your Premium subscription on all your devices.",
  toolReason: "Create a free account to use this tool. It takes 30 seconds.",
  e_exists: "This email already has an account. Sign in.",
  e_bad: "Wrong email or password.",
  e_weak: "Password too short (6 characters minimum).",
  e_mail: "Invalid email address.",
  e_net: "No internet connection. Try again online.",
  e_other: "Something went wrong. Try again.",
};

export function authText(lang: string) {
  return lang === "fr" || lang === "ln" ? FR : EN;
}

function explain(e: unknown, x: typeof FR) {
  const code = (e as { code?: string })?.code || "";
  if (code.includes("email-already-in-use")) return x.e_exists;
  if (code.includes("invalid-credential") || code.includes("wrong-password") || code.includes("user-not-found")) return x.e_bad;
  if (code.includes("weak-password")) return x.e_weak;
  if (code.includes("invalid-email")) return x.e_mail;
  if (code.includes("network")) return x.e_net;
  return x.e_other;
}

export function AuthScreen({ onClose, reason }: { onClose?: () => void; reason?: string }) {
  const app = useApp();
  const auth = useAuth();
  const x = authText(app.lang);
  const [mode, setMode] = useState<"create" | "login">("create");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState("");

  const submit = async () => {
    setMsg("");
    if (mode === "create" && !name.trim()) {
      setMsg(x.needName);
      return;
    }
    setBusy(true);
    try {
      if (mode === "create") await auth.signUp(name, email, password);
      else await auth.signIn(email, password);
    } catch (e) {
      setMsg(explain(e, x));
    } finally {
      setBusy(false);
    }
  };

  const forgot = async () => {
    setMsg("");
    try {
      await auth.reset(email);
      setMsg(x.sent);
    } catch (e) {
      setMsg(explain(e, x));
    }
  };

  return (
    <div className="relative mx-auto flex min-h-dvh max-w-md flex-col justify-center px-5 py-8">
      {onClose && (
        <button type="button" onClick={onClose} aria-label="Fermer" className="chip absolute right-5 top-5 h-10 w-10 !p-0 text-lg">✕</button>
      )}
      <div className="mb-6 flex flex-col items-center text-center">
        <Logo size={72} />
        <h1 className="display mt-4 text-4xl font-extrabold">AllTool</h1>
        <p className="muted mt-2 text-sm leading-relaxed">{reason ? x[reason as "toolReason"] : x.intro}</p>
      </div>
      <div className="solid hairline rounded-[28px] p-5">
        <div className="mb-4 flex gap-2">
          <button type="button" className={`chip flex-1 ${mode === "create" ? "chip-on" : ""}`} onClick={() => setMode("create")}>{x.create}</button>
          <button type="button" className={`chip flex-1 ${mode === "login" ? "chip-on" : ""}`} onClick={() => setMode("login")}>{x.login}</button>
        </div>
        <div className="space-y-3">
          {mode === "create" && <input className="field" placeholder={x.name} value={name} onChange={(e) => setName(e.target.value)} autoComplete="given-name" />}
          <input className="field" type="email" placeholder={x.email} value={email} onChange={(e) => setEmail(e.target.value)} autoComplete="email" dir="ltr" />
          <input className="field" type="password" placeholder={x.password} value={password} onChange={(e) => setPassword(e.target.value)} autoComplete={mode === "create" ? "new-password" : "current-password"} dir="ltr" />
        </div>
        {msg && <p className="mt-3 text-sm font-semibold text-rose-500">{msg}</p>}
        <button type="button" disabled={busy || !email || !password} onClick={submit} className="brand-btn mt-4 h-12 w-full rounded-2xl font-semibold">
          {busy ? x.wait : mode === "create" ? x.create : x.login}
        </button>
        {mode === "login" && (
          <button type="button" disabled={!email} onClick={forgot} className="mt-3 w-full text-center text-sm font-semibold text-[var(--muted)] disabled:opacity-40">
            {x.forgot}
          </button>
        )}
      </div>
    </div>
  );
}
