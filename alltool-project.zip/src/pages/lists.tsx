import type { MsgKey } from "../i18n";
import { useApp } from "../store";
import { formatBytes, formatWhen } from "../lib/util";
import { remember } from "../engine";
import { EmptyState, Icon, toolIcon, colorOf } from "../components/ui";
import { TOOL_META } from "../types";
import type { QueueItem } from "../types";

export function FavoritesPage() {
  const app = useApp();
  return (
    <div className="rise mx-auto max-w-3xl">
      <h1 className="display mb-4 text-4xl font-extrabold">{app.t("nav.favorites")}</h1>
      {app.favorites.length === 0 ? (
        <EmptyState title={app.t("nav.favorites")} body={app.t("home.favEmpty")} />
      ) : (
        <div className="space-y-2">
          {app.favorites.map((id) => (
            <button key={id} type="button" onClick={() => app.openTool(id)} className="solid hairline flex w-full items-center gap-3 rounded-[22px] p-3 text-start">
              <span className="grid h-11 w-11 place-items-center rounded-2xl text-white" style={{ background: colorOf(TOOL_META[id].cat) }}>
                <Icon name={toolIcon(id)} />
              </span>
              <span className="font-semibold">{app.t(`tool.${id}` as MsgKey)}</span>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

export function HistoryPage() {
  const app = useApp();
  return (
    <div className="rise mx-auto max-w-3xl">
      <div className="mb-4 flex items-end justify-between gap-3">
        <h1 className="display text-4xl font-extrabold">{app.t("history.title")}</h1>
        {app.history.length > 0 && (
          <button type="button" className="text-sm font-semibold text-rose-600" onClick={() => { if (window.confirm(app.t("history.confirm"))) app.clearHistory(); }}>
            {app.t("history.clear")}
          </button>
        )}
      </div>
      {app.history.length === 0 ? (
        <EmptyState title={app.t("history.title")} body={app.t("history.empty")} />
      ) : (
        <div className="space-y-2">
          {app.history.map((item) => (
            <button key={item.id} type="button" onClick={() => void app.openStored(item.resultId, { name: item.fileName, kind: item.preview, text: item.text, tool: item.tool })} className="solid hairline flex w-full items-center gap-3 rounded-[22px] p-3 text-start">
              <span className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl text-white" style={{ background: colorOf(TOOL_META[item.tool].cat) }}>
                <Icon name={toolIcon(item.tool)} />
              </span>
              <span className="min-w-0 flex-1">
                <span className="block truncate font-semibold">{app.t(`tool.${item.tool}` as MsgKey)}</span>
                <span className="muted block truncate text-xs" dir="ltr">{item.fileName}</span>
              </span>
              <span className="muted shrink-0 text-xs">{formatWhen(item.at, app.lang)}</span>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

export function QueuePage() {
  const app = useApp();
  const groups: { key: "queue.running" | "queue.waiting" | "queue.finished"; items: QueueItem[] }[] = [
    { key: "queue.running", items: app.queue.filter((q) => q.status === "running") },
    { key: "queue.waiting", items: app.queue.filter((q) => q.status === "queued") },
    { key: "queue.finished", items: app.queue.filter((q) => q.status === "done" || q.status === "error" || q.status === "cancelled") },
  ];
  const any = app.queue.length > 0;
  return (
    <div className="rise mx-auto max-w-3xl">
      <div className="mb-4 flex items-end justify-between">
        <h1 className="display text-4xl font-extrabold">{app.t("queue.title")}</h1>
        {groups[2].items.length > 0 && (
          <button type="button" className="text-sm font-semibold text-[var(--muted)]" onClick={app.clearDoneQueue}>{app.t("queue.clearDone")}</button>
        )}
      </div>
      {!any && <EmptyState title={app.t("queue.title")} body={app.t("queue.empty")} />}
      {groups.map((group) =>
        group.items.length ? (
          <section key={group.key} className="mb-5">
            <h2 className="mb-2 px-1 text-xs font-semibold uppercase tracking-[0.14em] text-[var(--muted)]">{app.t(group.key)}</h2>
            <div className="space-y-2">
              {group.items.map((item) => {
                const mem = item.resultId ? remember(item.resultId) : undefined;
                return (
                  <article key={item.id} className="solid hairline rounded-[22px] p-4">
                    <div className="flex items-start justify-between gap-3">
                      <div className="min-w-0">
                        <p className="text-xs font-semibold uppercase tracking-[0.12em] text-[var(--muted)]">{app.t(`tool.${item.tool}` as MsgKey)}</p>
                        <p className="truncate font-semibold">{item.title}</p>
                      </div>
                      <p className="text-sm font-semibold tabular-nums">{item.status === "running" || item.status === "queued" ? `${Math.round(item.progress)}%` : app.t(`status.${item.status}` as MsgKey)}</p>
                    </div>
                    {(item.status === "running" || item.status === "queued") && (
                      <>
                        <div className="mt-3 h-2 overflow-hidden rounded-full bg-[var(--line)]">
                          <div className="h-full rounded-full bg-gradient-to-r from-indigo-500 to-violet-500" style={{ width: `${item.progress}%` }} />
                        </div>
                        {item.statusKey && <p className="mt-2 text-xs leading-relaxed">{app.t(item.statusKey as MsgKey)}</p>}
                        <button type="button" className="ghost-btn mt-3 h-10 rounded-xl px-4 text-sm font-semibold" onClick={() => app.cancel(item.id)}>{app.t("action.cancel")}</button>
                      </>
                    )}
                    {item.status === "error" && item.errorKey && <p className="mt-2 text-sm text-rose-600">{app.t(item.errorKey as MsgKey)}</p>}
                    {item.status === "done" && (
                      <div className="mt-3 flex gap-2">
                        <button type="button" className="brand-btn h-10 rounded-xl px-4 text-sm font-semibold" onClick={() => void app.openStored(item.resultId, { name: item.title, kind: mem?.stored.preview || "none", text: mem?.stored.text, tool: item.tool })}>
                          {app.t("action.open")}
                        </button>
                        {mem?.stored.afterBytes != null && <span className="muted self-center text-xs">{formatBytes(mem.stored.afterBytes, app.lang)}</span>}
                      </div>
                    )}
                  </article>
                );
              })}
            </div>
          </section>
        ) : null,
      )}
    </div>
  );
}
