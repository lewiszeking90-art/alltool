import { Capacitor, CapacitorHttp } from "@capacitor/core";
import type { RunCtx, TaskResult } from "../types";
import { AppError, abortError, isAbort, makeName, sleep } from "./util";
import { pickVideoMime } from "./media";

const SOCIAL =
  /(?:tiktok\.com|vm\.tiktok\.com|vt\.tiktok\.com|youtube\.com|youtu\.be|instagram\.com|facebook\.com|fb\.watch|fb\.com|vimeo\.com|twitter\.com|x\.com)/i;
const DIRECT = /\.(mp4|webm|mkv|mov|m4v|m3u8|mp3|m4a)(\?|#|$)/i;

async function appFetch(url: string, init: RequestInit = {}): Promise<Response> {
  if (!Capacitor.isNativePlatform()) return fetch(url, init);
  if (init.signal?.aborted) throw abortError();
  const r = await CapacitorHttp.request({
    url,
    method: "GET",
    headers: (init.headers as Record<string, string>) || {},
    responseType: "blob",
    connectTimeout: 30000,
    readTimeout: 120000,
  });
  if (init.signal?.aborted) throw abortError();
  const bin = atob(typeof r.data === "string" ? r.data : "");
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  const nullBody = r.status === 204 || r.status === 205 || r.status === 304;
  const resp = new Response(nullBody ? null : bytes, { status: r.status < 200 ? 200 : r.status, headers: r.headers });
  Object.defineProperty(resp, "url", { value: r.url || url });
  return resp;
}

function isDrm(text: string) {
  return /EXT-X-KEY|widevine|playready|skd:\/\//i.test(text);
}

function absUrl(raw: string, base: string) {
  try {
    return new URL(raw, base).toString();
  } catch {
    return raw;
  }
}

function decodeEsc(s: string) {
  return s
    .replace(/\\u002F/gi, "/")
    .replace(/\\u0026/gi, "&")
    .replace(/\\u0025/gi, "%")
    .replace(/\\\//g, "/")
    .replace(/&amp;/g, "&");
}

const PAGE_HEADERS: Record<string, string> = {
  "User-Agent": "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36",
  "Accept-Language": "en-US,en;q=0.9",
};

function extractMedia(html: string, base: string) {
  if (isDrm(html)) return { videos: [] as string[], audios: [] as string[], drm: true };
  const videos = new Set<string>();
  const audios = new Set<string>();
  const keyRe = /"(?:playAddr|downloadAddr|playable_url_quality_hd|playable_url|hd_src|sd_src|video_url|contentUrl)"\s*:\s*"(https?:[^"]+)"/g;
  let km: RegExpExecArray | null;
  while ((km = keyRe.exec(html))) videos.add(decodeEsc(km[1]));
  const re = /https?:\/\/[^"'\\\s<>]+?\.(?:mp4|webm|m4v|mov|m4a|mp3)(?:\?[^"'\\\s<>]*)?/gi;
  let m: RegExpExecArray | null;
  while ((m = re.exec(html))) {
    const url = m[0].replace(/&amp;/g, "&");
    if (/\.(m4a|mp3)(\?|$)/i.test(url)) audios.add(url);
    else videos.add(url);
  }
  const og = html.match(/property=["']og:video(?::secure_url|:url)?["'][^>]*content=["']([^"']+)["']/i);
  if (og?.[1]) videos.add(absUrl(og[1], base));
  return { videos: [...videos], audios: [...audios], drm: false };
}

async function waitOnline(signal: AbortSignal) {
  if (!navigator.onLine) {
    await new Promise<void>((resolve, reject) => {
      const on = () => {
        cleanup();
        resolve();
      };
      const ab = () => {
        cleanup();
        reject(abortError());
      };
      const cleanup = () => {
        window.removeEventListener("online", on);
        signal.removeEventListener("abort", ab);
      };
      window.addEventListener("online", on);
      signal.addEventListener("abort", ab);
    });
    return;
  }
  await sleep(1400, signal);
}

export async function downloadWithResume(url: string, ctx: RunCtx) {
  const chunks: Uint8Array[] = [];
  let received = 0;
  let total = 0;
  let retries = 0;
  let mime = "";
  while (retries < 30) {
    if (ctx.signal.aborted) throw abortError();
    try {
      const headers: Record<string, string> = {};
      if (received > 0) headers.Range = `bytes=${received}-`;
      const res = await appFetch(url, { headers, signal: ctx.signal });
      if (res.status === 401 || res.status === 403) throw new AppError("err.protected", `HTTP ${res.status}`);
      if (!res.ok && res.status !== 206) throw new AppError("err.blocked", `HTTP ${res.status}`);
      if (received > 0 && res.status === 200) {
        chunks.length = 0;
        received = 0;
      }
      mime = res.headers.get("content-type") || mime;
      const range = res.headers.get("content-range");
      if (range && range.includes("/")) total = Number(range.split("/")[1]) || total;
      else if (!total) total = Number(res.headers.get("content-length") || 0);
      const reader = res.body?.getReader();
      if (!reader) throw new AppError("err.blocked", "no body");
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        if (value) {
          chunks.push(value);
          received += value.byteLength;
        }
        retries = 0;
        ctx.progress(total ? Math.min(99, (received / total) * 100) : Math.min(92, 20 + Math.log10(received + 1) * 12));
      }
      const blob = new Blob(chunks as BlobPart[], { type: mime.split(";")[0] || "application/octet-stream" });
      if (blob.size < 200) throw new AppError("err.blocked", "too small");
      ctx.progress(100);
      return blob;
    } catch (e) {
      if (isAbort(e) || ctx.signal.aborted) throw abortError();
      if (e instanceof AppError && e.key === "err.protected") throw e;
      if (e instanceof AppError && e.key === "err.blocked" && received === 0) throw e;
      if (received === 0 && navigator.onLine && retries >= 1) {
        throw new AppError("err.blocked", e instanceof Error ? e.message : "fetch");
      }
      retries += 1;
      ctx.progress(total ? (received / total) * 100 : 1, "progress.retry");
      await waitOnline(ctx.signal);
    }
  }
  throw new AppError("err.network", "retries");
}

function extFrom(blob: Blob, url: string) {
  const type = blob.type;
  if (type.includes("webm")) return "webm";
  if (type.includes("mp4")) return "mp4";
  if (type.includes("quicktime")) return "mov";
  if (type.includes("audio/mpeg")) return "mp3";
  const m = url.toLowerCase().match(/\.([a-z0-9]{2,4})(\?|#|$)/);
  return m ? m[1] : "mp4";
}

async function muxIfNeeded(videoUrl: string, audioUrl: string, ctx: RunCtx): Promise<TaskResult> {
  const videoBlob = await downloadWithResume(videoUrl, ctx);
  ctx.progress(45);
  const audioBlob = await downloadWithResume(audioUrl, ctx);
  ctx.progress(70);
  const vUrl = URL.createObjectURL(videoBlob);
  const aUrl = URL.createObjectURL(audioBlob);
  const video = document.createElement("video");
  const audio = document.createElement("audio");
  video.src = vUrl;
  audio.src = aUrl;
  video.playsInline = true;
  video.muted = true;
  await Promise.all([
    new Promise<void>((res, rej) => {
      video.onloadeddata = () => res();
      video.onerror = () => rej(new AppError("err.decode", "mux video"));
    }),
    new Promise<void>((res, rej) => {
      audio.onloadeddata = () => res();
      audio.onerror = () => rej(new AppError("err.decode", "mux audio"));
    }),
  ]);
  const canvas = document.createElement("canvas");
  canvas.width = video.videoWidth || 1280;
  canvas.height = video.videoHeight || 720;
  const c2d = canvas.getContext("2d");
  if (!c2d) throw new AppError("err.memory", "mux");
  const audioCtx = new AudioContext();
  await audioCtx.resume();
  const source = audioCtx.createMediaElementSource(audio);
  const dest = audioCtx.createMediaStreamDestination();
  source.connect(dest);
  const chosen = pickVideoMime("mp4") || pickVideoMime("webm");
  if (!chosen || typeof MediaRecorder === "undefined") throw new AppError("err.unsupported", "mux");
  const stream = new MediaStream([...canvas.captureStream(30).getVideoTracks(), ...dest.stream.getAudioTracks()]);
  const rec = new MediaRecorder(stream, { mimeType: chosen.mime, videoBitsPerSecond: 2_500_000, audioBitsPerSecond: 128000 });
  const chunks: Blob[] = [];
  rec.ondataavailable = (e) => {
    if (e.data.size) chunks.push(e.data);
  };
  const stopped = new Promise<void>((resolve) => {
    rec.onstop = () => resolve();
  });
  try {
    await video.play();
    await audio.play();
  } catch {
    throw new AppError("err.gesture", "mux play");
  }
  rec.start(200);
  await new Promise<void>((resolve, reject) => {
    const loop = () => {
      if (ctx.signal.aborted) {
        video.pause();
        audio.pause();
        reject(abortError());
        return;
      }
      c2d.drawImage(video, 0, 0, canvas.width, canvas.height);
      if (video.duration) ctx.progress(70 + (video.currentTime / video.duration) * 29);
      if (video.ended) {
        resolve();
        return;
      }
      requestAnimationFrame(loop);
    };
    video.onended = () => resolve();
    ctx.signal.addEventListener("abort", () => reject(abortError()), { once: true });
    loop();
  });
  if (rec.state !== "inactive") rec.stop();
  await stopped;
  URL.revokeObjectURL(vUrl);
  URL.revokeObjectURL(aUrl);
  await audioCtx.close().catch(() => undefined);
  const blob = new Blob(chunks, { type: chosen.mime });
  return {
    blob,
    fileName: makeName("video", chosen.ext),
    mime: chosen.mime,
    preview: "video",
    beforeBytes: videoBlob.size + audioBlob.size,
    afterBytes: blob.size,
  };
}

export async function downloadVideo(input: string, ctx: RunCtx): Promise<TaskResult> {
  const url = input.trim();
  if (!url) throw new AppError("err.empty");
  if (!navigator.onLine) throw new AppError("err.network");
  if (DIRECT.test(url) && !url.includes(".m3u8")) {
    const blob = await downloadWithResume(url, ctx);
    const ext = extFrom(blob, url);
    return {
      blob,
      fileName: makeName(decodeURIComponent(url.split("/").pop() || "video"), ext),
      mime: blob.type || "video/mp4",
      preview: ext === "mp3" || ext === "m4a" ? "audio" : "video",
      afterBytes: blob.size,
    };
  }
  if (/\.m3u8(\?|#|$)/i.test(url)) {
    try {
      const res = await appFetch(url, { signal: ctx.signal });
      const text = await res.text();
      if (isDrm(text)) throw new AppError("err.protected", "hls key");
    } catch (e) {
      if (e instanceof AppError) throw e;
      if (isAbort(e)) throw abortError();
    }
    throw new AppError(SOCIAL.test(url) ? "err.protected" : "err.blocked", "hls");
  }
  let finalUrl = url;
  try {
    const res = await appFetch(url, { signal: ctx.signal, redirect: "follow", headers: PAGE_HEADERS });
    finalUrl = res.url || url;
    const type = res.headers.get("content-type") || "";
    if (type.includes("video") || type.includes("audio") || DIRECT.test(finalUrl)) {
      const blob = await downloadWithResume(finalUrl, ctx);
      const ext = extFrom(blob, finalUrl);
      return {
        blob,
        fileName: makeName("video", ext),
        mime: blob.type,
        preview: "video",
        afterBytes: blob.size,
      };
    }
    if (type.includes("text") || type.includes("json") || type === "") {
      const html = await res.text();
      const found = extractMedia(html, finalUrl);
      if (found.drm) throw new AppError("err.protected", "drm");
      if (found.videos[0] && found.audios[0]) return muxIfNeeded(found.videos[0], found.audios[0], ctx);
      if (found.videos[0]) {
        const blob = await downloadWithResume(found.videos[0], ctx);
        const ext = extFrom(blob, found.videos[0]);
        return {
          blob,
          fileName: makeName("video", ext),
          mime: blob.type,
          preview: "video",
          afterBytes: blob.size,
        };
      }
    }
  } catch (e) {
    if (e instanceof AppError) throw e;
    if (isAbort(e) || ctx.signal.aborted) throw abortError();
  }
  if (SOCIAL.test(finalUrl) || SOCIAL.test(url)) throw new AppError("err.protected", finalUrl);
  throw new AppError("err.blocked", finalUrl);
}

export function looksLikeVideo(url: string) {
  return DIRECT.test(url) || SOCIAL.test(url) || /watch\?|\/reel\/|\/shorts\/|\/videos\//i.test(url);
}

const PHRASES: { from: string; to: string; src: string; out: string }[] = [
  { from: "en", to: "fr", src: "hello bro", out: "salut" },
  { from: "en", to: "fr", src: "hey bro", out: "salut" },
  { from: "en", to: "fr", src: "hi bro", out: "salut" },
  { from: "en", to: "fr", src: "yo bro", out: "salut" },
  { from: "en", to: "fr", src: "what's up", out: "quoi de neuf" },
  { from: "en", to: "fr", src: "whats up", out: "quoi de neuf" },
  { from: "en", to: "fr", src: "see you", out: "à plus" },
  { from: "en", to: "fr", src: "no worries", out: "t'inquiète" },
  { from: "en", to: "fr", src: "thanks a lot", out: "merci beaucoup" },
  { from: "en", to: "es", src: "hello bro", out: "qué tal" },
  { from: "en", to: "de", src: "hello bro", out: "hallo" },
  { from: "en", to: "pt", src: "hello bro", out: "e aí" },
  { from: "en", to: "it", src: "hello bro", out: "ciao" },
  { from: "en", to: "ar", src: "hello bro", out: "مرحبا" },
  { from: "en", to: "zh", src: "hello bro", out: "嗨" },
  { from: "en", to: "zh-CN", src: "hello bro", out: "嗨" },
  { from: "en", to: "sw", src: "hello bro", out: "habari" },
  { from: "en", to: "ln", src: "hello bro", out: "mbote" },
  { from: "fr", to: "en", src: "salut", out: "hey" },
  { from: "fr", to: "en", src: "quoi de neuf", out: "what's up" },
  { from: "fr", to: "en", src: "t'inquiète", out: "no worries" },
];

function norm(s: string) {
  return s.trim().toLowerCase().replace(/[!?.]+$/g, "").replace(/\s+/g, " ");
}

function googleCode(code: string) {
  if (code === "zh") return "zh-CN";
  if (code === "auto") return "auto";
  return code;
}

function polish(src: string, out: string, from: string, to: string) {
  const casual = /\b(bro|dude|mate)\b/i.test(src) && src.trim().split(/\s+/).length <= 5;
  if (casual && (to === "fr" || from === "auto")) {
    if (/bonjour\s+(mon\s+)?(frère|frere|bro)/i.test(out)) return "salut";
  }
  return out.replace(/\s{2,}/g, " ").trim();
}

async function translateChunk(text: string, from: string, to: string, signal: AbortSignal) {
  const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=${encodeURIComponent(googleCode(from))}&tl=${encodeURIComponent(googleCode(to))}&dt=t&q=${encodeURIComponent(text)}`;
  const res = await appFetch(url, { signal });
  if (!res.ok) throw new AppError("err.network", `HTTP ${res.status}`);
  const data = (await res.json()) as unknown;
  const rows = Array.isArray(data) && Array.isArray((data as unknown[])[0]) ? ((data as unknown[])[0] as unknown[]) : [];
  const out = rows.map((row) => (Array.isArray(row) ? String(row[0] ?? "") : "")).join("");
  if (!out.trim()) throw new AppError("err.network", "empty translation");
  return out;
}

export async function translateText(text: string, from: string, to: string, ctx: RunCtx) {
  const clean = text.trim();
  if (!clean) throw new AppError("err.noText");
  const target = googleCode(to);
  const source = from || "auto";
  if (source !== "auto" && googleCode(source) === target) return clean;
  const hit = PHRASES.find((p) => (p.from === source || source === "auto") && (p.to === to || p.to === target) && norm(p.src) === norm(clean));
  if (hit) return hit.out;
  if (!navigator.onLine) throw new AppError("err.network");
  const chunks: string[] = [];
  let buf = "";
  for (const part of clean.split(/(?<=[.!?。！？]\s+)/)) {
    if ((buf + part).length > 1400) {
      if (buf) chunks.push(buf);
      buf = part;
    } else buf += part;
  }
  if (buf) chunks.push(buf);
  if (!chunks.length) chunks.push(clean);
  let out = "";
  for (let i = 0; i < chunks.length; i++) {
    if (ctx.signal.aborted) throw abortError();
    const ctrl = new AbortController();
    const timer = window.setTimeout(() => ctrl.abort(), 25000);
    const onAbort = () => ctrl.abort();
    ctx.signal.addEventListener("abort", onAbort);
    try {
      out += await translateChunk(chunks[i], source, target, ctrl.signal);
    } catch (e) {
      if (ctx.signal.aborted) throw abortError();
      if (e instanceof AppError) throw e;
      throw new AppError("err.network", e instanceof Error ? e.message : "translate");
    } finally {
      window.clearTimeout(timer);
      ctx.signal.removeEventListener("abort", onAbort);
    }
    ctx.progress(((i + 1) / chunks.length) * 100);
  }
  return polish(clean, out, source, target);
}

const TESS_LANG: Record<string, string> = {
  fr: "fra",
  en: "eng",
  es: "spa",
  de: "deu",
  pt: "por",
  it: "ita",
  ar: "ara",
  zh: "chi_sim",
  sw: "swa",
  ln: "fra",
};

export function tessCode(lang: string) {
  return TESS_LANG[lang] || "eng";
}

async function loadScript(src: string) {
  const w = window as unknown as { Tesseract?: unknown };
  if (w.Tesseract) return;
  await new Promise<void>((resolve, reject) => {
    const s = document.createElement("script");
    s.src = src;
    s.async = true;
    s.onload = () => resolve();
    s.onerror = () => reject(new AppError("err.network", "ocr"));
    document.head.appendChild(s);
  });
}

export async function recognizeCanvas(canvas: HTMLCanvasElement, lang: string, ctx: RunCtx, handwriting: boolean) {
  await loadScript("/tesseract/tesseract.min.js");
  const Tesseract = (window as unknown as { Tesseract?: { createWorker: (lang: string, oem: number, opts: { logger: (m: { status: string; progress: number }) => void; workerPath: string; corePath: string; langPath: string }) => Promise<{ recognize: (image: HTMLCanvasElement) => Promise<{ data: { text: string; confidence: number } }>; terminate: () => Promise<void> }> } }).Tesseract;
  if (!Tesseract) throw new AppError("err.network", "ocr missing");
  const worker = await Tesseract.createWorker(tessCode(lang), 1, {
    workerPath: "/tesseract/worker.min.js",
    corePath: "/tesseract/",
    langPath: "/tessdata",
    logger: (m) => {
      if (m.status === "recognizing text") ctx.progress(Math.min(96, 15 + m.progress * 80));
    },
  });
  try {
    const prepared = handwriting ? prepHand(canvas) : canvas;
    const { data } = await worker.recognize(prepared);
    const text = (data.text || "").replace(/[ \t]+\n/g, "\n").trim();
    const confidence = data.confidence || 0;
    if (handwriting && (confidence < 48 || text.length < 2)) {
      throw new AppError("err.hand", `confidence ${confidence} text ${text.slice(0, 180)}`);
    }
    if (!text) throw new AppError("err.ocr", `confidence ${confidence}`);
    return { text, confidence };
  } finally {
    await worker.terminate();
  }
}

function prepHand(source: HTMLCanvasElement) {
  const canvas = document.createElement("canvas");
  canvas.width = source.width;
  canvas.height = source.height;
  const c = canvas.getContext("2d", { willReadFrequently: true });
  if (!c) return source;
  c.filter = "grayscale(1) contrast(1.35)";
  c.drawImage(source, 0, 0);
  c.filter = "none";
  const img = c.getImageData(0, 0, canvas.width, canvas.height);
  let sum = 0;
  for (let i = 0; i < img.data.length; i += 4) sum += img.data[i];
  const mean = sum / (img.data.length / 4);
  const th = mean * 0.92;
  for (let i = 0; i < img.data.length; i += 4) {
    const v = img.data[i] < th ? 18 : 248;
    img.data[i] = img.data[i + 1] = img.data[i + 2] = v;
  }
  c.putImageData(img, 0, 0);
  return canvas;
}

type PdfJs = {
  GlobalWorkerOptions: { workerSrc: string };
  getDocument: (opts: { data: Uint8Array }) => {
    promise: Promise<{
      numPages: number;
      getPage: (n: number) => Promise<{
        getViewport: (o: { scale: number }) => { width: number; height: number };
        render: (o: { canvasContext: CanvasRenderingContext2D; viewport: { width: number; height: number } }) => { promise: Promise<void> };
      }>;
    }>;
  };
};

export async function renderPdfPages(file: File, ctx: RunCtx, maxPages = 12) {
  const load = new Function("u", "return import(u)") as (u: string) => Promise<PdfJs>;
  const pdfjs = await load("/pdfjs/pdf.min.mjs");
  pdfjs.GlobalWorkerOptions.workerSrc = "/pdfjs/pdf.worker.min.mjs";
  const data = new Uint8Array(await file.arrayBuffer());
  const doc = await pdfjs.getDocument({ data }).promise;
  const count = Math.min(doc.numPages, maxPages);
  const pages: HTMLCanvasElement[] = [];
  for (let i = 1; i <= count; i++) {
    if (ctx.signal.aborted) throw abortError();
    const page = await doc.getPage(i);
    const viewport = page.getViewport({ scale: 1.8 });
    const canvas = document.createElement("canvas");
    canvas.width = viewport.width;
    canvas.height = viewport.height;
    const c = canvas.getContext("2d");
    if (!c) throw new AppError("err.memory", "pdf page");
    await page.render({ canvasContext: c, viewport }).promise;
    pages.push(canvas);
    ctx.progress((i / count) * 25);
  }
  return { pages, truncated: doc.numPages > maxPages };
}
