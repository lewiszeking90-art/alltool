import type { RunCtx } from "../types";
import { AppError, abortError, isAbort } from "./util";

export type Cue = { start: number; end: number; text: string };

type Pipe = (audio: Float32Array, opts: Record<string, unknown>) => Promise<{ text?: string; chunks?: { timestamp: [number | null, number | null]; text: string }[] }>;

const WHISPER_LANG: Record<string, string> = {
  fr: "french",
  en: "english",
  es: "spanish",
  de: "german",
  pt: "portuguese",
  it: "italian",
  ar: "arabic",
  zh: "chinese",
  sw: "swahili",
  ln: "lingala",
};

let pipePromise: Promise<Pipe> | null = null;

function getPipe() {
  if (!pipePromise) {
    pipePromise = (async () => {
      const load = new Function("u", "return import(u)") as (u: string) => Promise<any>;
      const tf = await load("/whisper/transformers.js");
      tf.env.allowRemoteModels = false;
      tf.env.allowLocalModels = true;
      tf.env.localModelPath = "/models/";
      tf.env.useBrowserCache = false;
      const wasm = tf.env.backends.onnx.wasm;
      wasm.wasmPaths = "/ort/";
      wasm.numThreads = 1;
      wasm.proxy = false;
      return (await tf.pipeline("automatic-speech-recognition", "whisper-base", { device: "wasm", dtype: "q8" })) as Pipe;
    })().catch((e) => {
      pipePromise = null;
      throw new AppError("err.generic", `whisper load: ${e instanceof Error ? e.message : String(e)}`);
    });
  }
  return pipePromise;
}

async function decode16k(blob: Blob): Promise<Float32Array> {
  const Ctor = window.AudioContext || (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
  if (!Ctor) throw new AppError("err.unsupported", "audio context");
  const raw = await blob.arrayBuffer();
  const ac = new Ctor();
  let audio: AudioBuffer;
  try {
    audio = await ac.decodeAudioData(raw.slice(0));
  } catch {
    throw new AppError("err.decode", "decodeAudioData");
  } finally {
    void ac.close().catch(() => undefined);
  }
  const frames = Math.max(1, Math.ceil(audio.duration * 16000));
  const off = new OfflineAudioContext(1, frames, 16000);
  const src = off.createBufferSource();
  src.buffer = audio;
  src.connect(off.destination);
  src.start();
  const rendered = await off.startRendering();
  return rendered.getChannelData(0);
}

export async function whisperTranscribe(
  blob: Blob,
  lang: string,
  ctx: RunCtx,
  onPartial: (text: string) => void,
  fr: boolean,
): Promise<{ text: string; cues: Cue[] }> {
  onPartial(fr ? "Préparation du moteur de transcription…" : "Preparing the transcription engine…");
  ctx.progress(3);
  const pipe = await getPipe();
  if (ctx.signal.aborted) throw abortError();
  ctx.progress(10);
  const samples = await decode16k(blob);
  const win = 16000 * 30;
  const total = Math.max(1, Math.ceil(samples.length / win));
  const language = lang && lang !== "auto" ? WHISPER_LANG[lang] : undefined;
  const cues: Cue[] = [];
  let text = "";
  for (let i = 0; i < total; i++) {
    if (ctx.signal.aborted) throw abortError();
    const slice = samples.slice(i * win, Math.min(samples.length, (i + 1) * win));
    if (slice.length < 1600) continue;
    const offset = i * 30;
    try {
      const out = await pipe(slice, { task: "transcribe", language, return_timestamps: true, chunk_length_s: 30 });
      const parts = out.chunks && out.chunks.length ? out.chunks : [{ timestamp: [0, slice.length / 16000] as [number, number], text: out.text || "" }];
      for (const part of parts) {
        const t = (part.text || "").trim();
        if (!t) continue;
        const s = (part.timestamp?.[0] ?? 0) + offset;
        const e = (part.timestamp?.[1] ?? part.timestamp?.[0] ?? 0) + offset;
        cues.push({ start: s, end: Math.max(e, s + 0.5), text: t });
        text = `${text} ${t}`.trim();
      }
    } catch (e) {
      if (isAbort(e) || ctx.signal.aborted) throw abortError();
      throw new AppError("err.generic", `whisper run: ${e instanceof Error ? e.message : String(e)}`);
    }
    onPartial(text);
    ctx.progress(10 + ((i + 1) / total) * 88);
  }
  return { text, cues };
}

export async function recordMic(ctx: RunCtx & { finish: AbortSignal }, onPartial: (text: string) => void, fr: boolean): Promise<Blob> {
  let stream: MediaStream;
  try {
    stream = await navigator.mediaDevices.getUserMedia({ audio: true });
  } catch {
    throw new AppError("err.mic");
  }
  const mime = ["audio/webm;codecs=opus", "audio/mp4", "audio/webm"].find((m) => typeof MediaRecorder !== "undefined" && MediaRecorder.isTypeSupported(m));
  const rec = new MediaRecorder(stream, mime ? { mimeType: mime } : undefined);
  const chunks: Blob[] = [];
  rec.ondataavailable = (e) => {
    if (e.data.size) chunks.push(e.data);
  };
  const started = performance.now();
  const timer = window.setInterval(() => {
    const s = Math.round((performance.now() - started) / 1000);
    onPartial(`${fr ? "Enregistrement…" : "Recording…"} ${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`);
  }, 500);
  const stopped = new Promise<void>((resolve) => {
    rec.onstop = () => resolve();
  });
  rec.start(500);
  await new Promise<void>((resolve, reject) => {
    ctx.finish.addEventListener("abort", () => resolve(), { once: true });
    ctx.signal.addEventListener("abort", () => reject(abortError()), { once: true });
  }).finally(() => {
    window.clearInterval(timer);
    if (rec.state !== "inactive") rec.stop();
    stream.getTracks().forEach((t) => t.stop());
  });
  await stopped;
  return new Blob(chunks, { type: rec.mimeType || "audio/webm" });
}
