import { Capacitor } from "@capacitor/core";
import { TextToSpeech } from "@capacitor-community/text-to-speech";
import type { RunCtx } from "../types";
import { AppError, abortError, isAbort } from "./util";

const WORDS: Record<string, string[]> = {
  fr: ["le", "la", "les", "de", "des", "un", "une", "et", "est", "je", "tu", "nous", "vous", "pas", "que", "qui", "dans", "pour", "avec", "bonjour", "salut", "merci", "oui", "non", "c'est", "au", "aux", "du", "sur", "ce", "cette"],
  en: ["the", "and", "you", "is", "are", "to", "of", "in", "that", "it", "for", "with", "this", "hello", "hey", "thanks", "please", "not", "have", "from", "your", "what", "how"],
  es: ["el", "la", "los", "las", "de", "que", "y", "en", "un", "una", "por", "con", "hola", "gracias", "está", "como", "para", "es", "no", "sí", "muy"],
  de: ["der", "die", "das", "und", "ist", "nicht", "ich", "ein", "eine", "mit", "auf", "für", "hallo", "danke", "wie", "auch", "zu", "den", "dem"],
  pt: ["o", "a", "os", "as", "de", "que", "e", "não", "um", "uma", "para", "com", "olá", "obrigado", "você", "está", "muito", "do", "da"],
  it: ["il", "lo", "la", "che", "di", "e", "non", "un", "una", "per", "con", "ciao", "grazie", "come", "sono", "questo", "della", "nel"],
  sw: ["na", "ya", "wa", "kwa", "ni", "habari", "asante", "sana", "wewe", "mimi", "hii", "katika", "lakini", "kwa", "yako", "sasa"],
  ln: ["na", "ya", "mpe", "te", "oyo", "mbote", "nazali", "ozali", "po", "na", "kasi", "yangó", "liboso", "nsima"],
};

export function detectLang(sentence: string, fallback = "fr") {
  if (/[\u0600-\u06FF]/.test(sentence)) return "ar";
  if (/[\u4E00-\u9FFF]/.test(sentence)) return "zh-CN";
  const words = sentence.toLowerCase().match(/[a-zàâäéèêëïîôùûüçœ']+/g) || [];
  if (!words.length) return fallback;
  let best = fallback;
  let score = 0;
  for (const [lang, list] of Object.entries(WORDS)) {
    const set = new Set(list);
    let n = 0;
    for (const w of words) if (set.has(w)) n += 1;
    if (n > score) {
      score = n;
      best = lang;
    }
  }
  return best === "zh" ? "zh-CN" : best;
}

export function splitSentences(text: string) {
  const parts = text
    .replace(/\r\n/g, "\n")
    .split(/(?<=[.!?。！？])\s+|\n+/);
  const out: string[] = [];
  for (const part of parts) {
    const bit = part.trim();
    if (!bit) continue;
    const chunks: string[] = [];
    let buf = "";
    let script = scriptOf(bit[0] || "");
    for (const ch of bit) {
      const s = scriptOf(ch);
      if (s && script && s !== script && buf.trim()) {
        chunks.push(buf.trim());
        buf = ch;
        script = s;
      } else {
        buf += ch;
        if (s) script = s;
      }
    }
    if (buf.trim()) chunks.push(buf.trim());
    out.push(...(chunks.length ? chunks : [bit]));
  }
  return out.length ? out : [text.trim()].filter(Boolean);
}

function scriptOf(ch: string) {
  if (/[\u0600-\u06FF]/.test(ch)) return "ar";
  if (/[\u4E00-\u9FFF]/.test(ch)) return "zh";
  if (/[A-Za-zÀ-ÿ]/.test(ch)) return "lat";
  return "";
}

type Voice = SpeechSynthesisVoice;

function loadVoices() {
  return new Promise<Voice[]>((resolve) => {
    const synth = window.speechSynthesis;
    if (!synth) {
      resolve([]);
      return;
    }
    const current = synth.getVoices();
    if (current.length) {
      resolve(current);
      return;
    }
    const timer = window.setTimeout(() => resolve(synth.getVoices()), 700);
    synth.onvoiceschanged = () => {
      window.clearTimeout(timer);
      resolve(synth.getVoices());
    };
  });
}

function pickVoice(voices: Voice[], lang: string) {
  const code = lang.toLowerCase();
  const exact = voices.find((v) => v.lang.toLowerCase().replace("_", "-") === code);
  if (exact) return exact;
  const prefix = code.split("-")[0];
  return (
    voices.find((v) => v.lang.toLowerCase().startsWith(prefix)) ||
    voices.find((v) => v.lang.toLowerCase().startsWith("en")) ||
    voices[0]
  );
}

export async function speakText(text: string, rate: number, pitch: number, ctx: RunCtx, fallbackLang = "fr") {
  if (!text.trim()) throw new AppError("err.noText");
  if (Capacitor.isNativePlatform()) {
    const BCP47: Record<string, string> = { fr: "fr-FR", en: "en-US", es: "es-ES", de: "de-DE", pt: "pt-PT", it: "it-IT", ar: "ar-SA", zh: "zh-CN", sw: "sw-KE", ln: "fr-FR" };
    const parts = splitSentences(text);
    const onAbort = () => {
      void TextToSpeech.stop().catch(() => undefined);
    };
    ctx.signal.addEventListener("abort", onAbort, { once: true });
    try {
      for (let i = 0; i < parts.length; i++) {
        if (ctx.signal.aborted) throw abortError();
        const lang = detectLang(parts[i], fallbackLang);
        await TextToSpeech.speak({ text: parts[i], lang: BCP47[lang] || "fr-FR", rate, pitch, volume: 1.0, category: "ambient" });
        ctx.progress(((i + 1) / parts.length) * 100);
      }
    } catch (e) {
      if (ctx.signal.aborted) throw abortError();
      throw new AppError("err.speech", e instanceof Error ? e.message : String(e));
    } finally {
      ctx.signal.removeEventListener("abort", onAbort);
    }
    return;
  }
  if (!window.speechSynthesis) throw new AppError("err.speech");
  const voices = await loadVoices();
  if (!voices.length && !window.speechSynthesis) throw new AppError("err.speech");
  const sentences = splitSentences(text);
  window.speechSynthesis.cancel();
  const keep = window.setInterval(() => {
    if (window.speechSynthesis.speaking && !window.speechSynthesis.paused) {
      window.speechSynthesis.pause();
      window.speechSynthesis.resume();
    }
  }, 10000);
  try {
    for (let i = 0; i < sentences.length; i++) {
      if (ctx.signal.aborted) throw abortError();
      const lang = detectLang(sentences[i], fallbackLang);
      const voice = pickVoice(voices, lang);
      await new Promise<void>((resolve, reject) => {
        const u = new SpeechSynthesisUtterance(sentences[i]);
        if (voice) {
          u.voice = voice;
          u.lang = voice.lang;
        } else u.lang = lang;
        u.rate = rate;
        u.pitch = pitch;
        u.onend = () => resolve();
        u.onerror = (ev) => {
          if (ev.error === "canceled" || ev.error === "interrupted") resolve();
          else reject(new AppError("err.speech", ev.error));
        };
        ctx.signal.addEventListener(
          "abort",
          () => {
            window.speechSynthesis.cancel();
            reject(abortError());
          },
          { once: true },
        );
        window.speechSynthesis.speak(u);
      });
      ctx.progress(((i + 1) / sentences.length) * 100);
    }
  } finally {
    window.clearInterval(keep);
  }
}

type Rec = {
  lang: string;
  continuous: boolean;
  interimResults: boolean;
  start: () => void;
  stop: () => void;
  abort: () => void;
  onresult: ((ev: { resultIndex: number; results: ArrayLike<{ isFinal: boolean; 0: { transcript: string } }> }) => void) | null;
  onerror: ((ev: { error: string }) => void) | null;
  onend: (() => void) | null;
};

export function speechRecognizer() {
  const w = window as unknown as { SpeechRecognition?: new () => Rec; webkitSpeechRecognition?: new () => Rec };
  return w.SpeechRecognition || w.webkitSpeechRecognition || null;
}

export async function transcribeMic(lang: string, ctx: RunCtx, onPartial: (text: string) => void, finish: AbortSignal) {
  const Ctor = speechRecognizer();
  if (!Ctor) throw new AppError("err.mic", "no speech recognition");
  let stream: MediaStream | null = null;
  try {
    stream = await navigator.mediaDevices.getUserMedia({ audio: true });
  } catch {
    throw new AppError("err.mic");
  }
  const rec = new Ctor();
  rec.continuous = true;
  rec.interimResults = true;
  rec.lang = lang === "auto" ? navigator.language || "fr-FR" : lang === "zh" ? "zh-CN" : lang;
  const cues: { start: number; end: number; text: string }[] = [];
  const started = performance.now();
  let finalText = "";
  let stopped = false;
  const done = new Promise<void>((resolve, reject) => {
    rec.onresult = (ev) => {
      let interim = "";
      for (let i = ev.resultIndex; i < ev.results.length; i++) {
        const piece = ev.results[i][0]?.transcript || "";
        if (ev.results[i].isFinal) {
          const now = (performance.now() - started) / 1000;
          const prev = cues.length ? cues[cues.length - 1].end : Math.max(0, now - 1.5);
          cues.push({ start: prev, end: now + 0.3, text: piece.trim() });
          finalText = `${finalText} ${piece}`.trim();
        } else interim += piece;
      }
      onPartial(`${finalText}${interim ? ` ${interim}` : ""}`.trim());
      ctx.progress(Math.min(95, cues.length * 8 + 10));
    };
    rec.onerror = (ev) => {
      if (ev.error === "aborted" || ev.error === "no-speech") return;
      if (ev.error === "not-allowed") reject(new AppError("err.mic", ev.error));
      else if (!stopped) reject(new AppError("err.generic", ev.error));
    };
    rec.onend = () => {
      if (ctx.signal.aborted || stopped || finish.aborted) resolve();
      else {
        try {
          rec.start();
        } catch {
          resolve();
        }
      }
    };
    ctx.signal.addEventListener(
      "abort",
      () => {
        stopped = true;
        try {
          rec.abort();
        } catch {
          /* ignore */
        }
        reject(abortError());
      },
      { once: true },
    );
    finish.addEventListener(
      "abort",
      () => {
        stopped = true;
        try {
          rec.stop();
        } catch {
          /* ignore */
        }
        resolve();
      },
      { once: true },
    );
  });
  try {
    rec.start();
  } catch (e) {
    stream.getTracks().forEach((t) => t.stop());
    if (isAbort(e)) throw abortError();
    throw new AppError("err.mic", e instanceof Error ? e.message : "start");
  }
  try {
    await done;
  } finally {
    stream.getTracks().forEach((t) => t.stop());
    stopped = true;
    try {
      rec.stop();
    } catch {
      /* ignore */
    }
  }
  return { text: finalText.trim(), cues };
}
