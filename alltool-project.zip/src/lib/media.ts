import { PDFDocument } from "pdf-lib";
import { Mp3Encoder } from "@breezystack/lamejs";
import type { RunCtx, TaskResult } from "../types";
import { AppError, abortError, even, isAbort, makeName, yieldThread } from "./util";

export type PageFormat = "a4" | "letter" | "a5";
export type Orientation = "portrait" | "landscape";
export type MarginName = "none" | "small" | "normal" | "large";

const PAGE_PT: Record<PageFormat, [number, number]> = {
  a4: [595.28, 841.89],
  letter: [612, 792],
  a5: [419.53, 595.28],
};

const MARGIN_PT: Record<MarginName, number> = {
  none: 0,
  small: 18,
  normal: 36,
  large: 54,
};

export function once(el: EventTarget, event: string, timeout = 20000) {
  return new Promise<void>((resolve, reject) => {
    const timer = window.setTimeout(() => {
      cleanup();
      reject(new AppError("err.decode", `timeout ${event}`));
    }, timeout);
    const ok = () => {
      cleanup();
      resolve();
    };
    const bad = () => {
      cleanup();
      reject(new AppError("err.decode", "media error"));
    };
    const cleanup = () => {
      window.clearTimeout(timer);
      el.removeEventListener(event, ok);
      el.removeEventListener("error", bad);
    };
    el.addEventListener(event, ok, { once: true });
    el.addEventListener("error", bad, { once: true });
  });
}

export function loadImage(src: string) {
  return new Promise<HTMLImageElement>((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => reject(new AppError("err.decode", "image"));
    img.src = src;
  });
}

export async function fileToImage(file: File) {
  const url = URL.createObjectURL(file);
  try {
    return await loadImage(url);
  } finally {
    URL.revokeObjectURL(url);
  }
}

export async function probeAudio(file: File) {
  const url = URL.createObjectURL(file);
  const audio = document.createElement("audio");
  audio.preload = "metadata";
  audio.src = url;
  try {
    await once(audio, "loadedmetadata", 8000);
    return Number.isFinite(audio.duration) ? audio.duration : undefined;
  } catch {
    return undefined;
  } finally {
    audio.src = "";
    URL.revokeObjectURL(url);
  }
}

export async function probeVideo(file: File) {
  const url = URL.createObjectURL(file);
  const video = document.createElement("video");
  video.preload = "auto";
  video.muted = true;
  video.playsInline = true;
  video.src = url;
  try {
    await once(video, "loadeddata", 12000);
    const duration = Number.isFinite(video.duration) ? video.duration : undefined;
    const width = video.videoWidth || undefined;
    const height = video.videoHeight || undefined;
    try {
      if (duration && duration > 0.2) {
        video.currentTime = Math.min(0.4, duration / 3);
        await once(video, "seeked", 4000);
      }
    } catch {
      /* thumbnail optional */
    }
    const canvas = document.createElement("canvas");
    canvas.width = 480;
    canvas.height = 270;
    const ctx = canvas.getContext("2d");
    let thumb: string | undefined;
    if (ctx && video.videoWidth) {
      ctx.fillStyle = "#111";
      ctx.fillRect(0, 0, 480, 270);
      const s = Math.min(480 / video.videoWidth, 270 / video.videoHeight);
      const dw = video.videoWidth * s;
      const dh = video.videoHeight * s;
      ctx.drawImage(video, (480 - dw) / 2, (270 - dh) / 2, dw, dh);
      thumb = canvas.toDataURL("image/jpeg", 0.72);
    }
    return { duration, width, height, thumb };
  } finally {
    video.src = "";
    URL.revokeObjectURL(url);
  }
}

function check(ctx: RunCtx) {
  if (ctx.signal.aborted) throw abortError();
}

async function canvasBlob(canvas: HTMLCanvasElement, type: string, quality?: number) {
  const blob = await new Promise<Blob | null>((resolve) => canvas.toBlob(resolve, type, quality));
  if (!blob) throw new AppError("err.memory", "toBlob");
  return blob;
}

export type EnhanceOpts = {
  sharp: number;
  noise: number;
  contrast: number;
  brightness: number;
  saturation: number;
  scale: number;
  format: "jpeg" | "png";
};

export async function renderEnhanced(img: CanvasImageSource, sw: number, sh: number, opts: EnhanceOpts, maxEdge: number) {
  const scale = Math.max(1, opts.scale);
  let w = Math.round(sw * scale);
  let h = Math.round(sh * scale);
  const edge = Math.max(w, h);
  if (edge > maxEdge) {
    const f = maxEdge / edge;
    w = Math.max(1, Math.round(w * f));
    h = Math.max(1, Math.round(h * f));
  }
  const canvas = document.createElement("canvas");
  canvas.width = w;
  canvas.height = h;
  const c = canvas.getContext("2d", { willReadFrequently: true });
  if (!c) throw new AppError("err.memory", "canvas");
  c.imageSmoothingEnabled = true;
  c.imageSmoothingQuality = "high";
  const b = 1 + opts.brightness / 100;
  const ct = 1 + opts.contrast / 100;
  const sat = 1 + opts.saturation / 100;
  c.filter = `brightness(${b}) contrast(${ct}) saturate(${sat})`;
  c.drawImage(img, 0, 0, w, h);
  c.filter = "none";
  if (opts.noise > 2) {
    const tmp = document.createElement("canvas");
    tmp.width = w;
    tmp.height = h;
    const t = tmp.getContext("2d");
    if (t) {
      t.filter = `blur(${(opts.noise / 100) * 2.4}px)`;
      t.drawImage(canvas, 0, 0);
      c.globalAlpha = Math.min(0.8, opts.noise / 120);
      c.drawImage(tmp, 0, 0);
      c.globalAlpha = 1;
    }
  }
  if (opts.sharp > 2) await sharpen(c, w, h, opts.sharp / 100);
  return canvas;
}

async function sharpen(ctx: CanvasRenderingContext2D, w: number, h: number, amount: number) {
  const img = ctx.getImageData(0, 0, w, h);
  const src = img.data;
  const copy = new Uint8ClampedArray(src);
  const a = amount;
  const center = 1 + 4 * a;
  for (let y = 1; y < h - 1; y++) {
    const row = y * w;
    for (let x = 1; x < w - 1; x++) {
      const i = (row + x) * 4;
      for (let ch = 0; ch < 3; ch++) {
        const v =
          center * copy[i + ch] -
          a * copy[i - 4 + ch] -
          a * copy[i + 4 + ch] -
          a * copy[i - w * 4 + ch] -
          a * copy[i + w * 4 + ch];
        src[i + ch] = v < 0 ? 0 : v > 255 ? 255 : v;
      }
    }
    if (y % 80 === 0) await yieldThread();
  }
  ctx.putImageData(img, 0, 0);
}

export async function enhanceImage(file: File, opts: EnhanceOpts, name: string, ctx: RunCtx): Promise<TaskResult> {
  check(ctx);
  const img = await fileToImage(file);
  ctx.progress(15);
  const canvas = await renderEnhanced(img, img.naturalWidth, img.naturalHeight, opts, 4096);
  check(ctx);
  ctx.progress(88);
  const mime = opts.format === "png" ? "image/png" : "image/jpeg";
  const blob = await canvasBlob(canvas, mime, opts.format === "png" ? undefined : 0.92);
  ctx.progress(100);
  return {
    blob,
    fileName: makeName(name || "image", opts.format === "png" ? "png" : "jpg"),
    mime,
    preview: "image",
    beforeBytes: file.size,
    afterBytes: blob.size,
  };
}

export async function combineImages(
  items: { file: File; rotation: number }[],
  opts: { dir: "vertical" | "horizontal"; gap: number; bg: string; name: string },
  ctx: RunCtx,
  maxEdge = 4096,
): Promise<TaskResult> {
  if (items.length < 2) throw new AppError("err.empty");
  check(ctx);
  const bitmaps: HTMLCanvasElement[] = [];
  for (const item of items) {
    check(ctx);
    const img = await fileToImage(item.file);
    bitmaps.push(rotateToCanvas(img, item.rotation));
    ctx.progress((bitmaps.length / items.length) * 30);
  }
  const gap = opts.gap;
  const widths = bitmaps.map((b) => b.width);
  const heights = bitmaps.map((b) => b.height);
  let W = opts.dir === "horizontal" ? widths.reduce((a, b) => a + b, 0) + gap * (bitmaps.length - 1) : Math.max(...widths);
  let H = opts.dir === "vertical" ? heights.reduce((a, b) => a + b, 0) + gap * (bitmaps.length - 1) : Math.max(...heights);
  const edge = Math.max(W, H);
  const fit = edge > maxEdge ? maxEdge / edge : 1;
  const canvas = document.createElement("canvas");
  canvas.width = Math.max(1, Math.round(W * fit));
  canvas.height = Math.max(1, Math.round(H * fit));
  const c = canvas.getContext("2d");
  if (!c) throw new AppError("err.memory", "canvas");
  c.fillStyle = opts.bg;
  c.fillRect(0, 0, canvas.width, canvas.height);
  c.scale(fit, fit);
  let cursor = 0;
  bitmaps.forEach((bmp, i) => {
    if (opts.dir === "horizontal") {
      c.drawImage(bmp, cursor, (H - bmp.height) / 2);
      cursor += bmp.width + gap;
    } else {
      c.drawImage(bmp, (W - bmp.width) / 2, cursor);
      cursor += bmp.height + gap;
    }
    ctx.progress(30 + ((i + 1) / bitmaps.length) * 50);
  });
  const blob = await canvasBlob(canvas, "image/jpeg", 0.92);
  ctx.progress(100);
  const before = items.reduce((s, it) => s + it.file.size, 0);
  return {
    blob,
    fileName: makeName(opts.name || "collage", "jpg"),
    mime: "image/jpeg",
    preview: "image",
    beforeBytes: before,
    afterBytes: blob.size,
  };
}

function rotateToCanvas(img: HTMLImageElement, rotation: number) {
  const rot = ((rotation % 360) + 360) % 360;
  const swap = rot === 90 || rot === 270;
  const canvas = document.createElement("canvas");
  canvas.width = swap ? img.naturalHeight : img.naturalWidth;
  canvas.height = swap ? img.naturalWidth : img.naturalHeight;
  const c = canvas.getContext("2d");
  if (!c) return canvas;
  c.translate(canvas.width / 2, canvas.height / 2);
  c.rotate((rot * Math.PI) / 180);
  c.drawImage(img, -img.naturalWidth / 2, -img.naturalHeight / 2);
  return canvas;
}

function pageSize(format: PageFormat, orientation: Orientation) {
  let [w, h] = PAGE_PT[format];
  if (orientation === "landscape") [w, h] = [h, w];
  return { w, h };
}

async function jpegPagesToPdf(pages: HTMLCanvasElement[], ptW: number, ptH: number, ctx: RunCtx) {
  const pdf = await PDFDocument.create();
  for (let i = 0; i < pages.length; i++) {
    check(ctx);
    const blob = await canvasBlob(pages[i], "image/jpeg", 0.86);
    const img = await pdf.embedJpg(await blob.arrayBuffer());
    const page = pdf.addPage([ptW, ptH]);
    page.drawImage(img, { x: 0, y: 0, width: ptW, height: ptH });
    ctx.progress(70 + ((i + 1) / pages.length) * 25);
  }
  const bytes = await pdf.save();
  return new Blob([Uint8Array.from(bytes)], { type: "application/pdf" });
}

export async function imagesToPdf(
  items: { file: File; rotation: number }[],
  opts: { format: PageFormat; orientation: Orientation; margin: MarginName; quality: "low" | "med" | "high"; name: string },
  ctx: RunCtx,
): Promise<TaskResult> {
  if (!items.length) throw new AppError("err.empty");
  const { w: ptW, h: ptH } = pageSize(opts.format, opts.orientation);
  const px = opts.quality === "high" ? 2.1 : opts.quality === "med" ? 1.6 : 1.15;
  const margin = MARGIN_PT[opts.margin] * px;
  const pages: HTMLCanvasElement[] = [];
  for (let i = 0; i < items.length; i++) {
    check(ctx);
    const img = await fileToImage(items[i].file);
    const rotated = rotateToCanvas(img, items[i].rotation);
    const canvas = document.createElement("canvas");
    canvas.width = Math.round(ptW * px);
    canvas.height = Math.round(ptH * px);
    const c = canvas.getContext("2d");
    if (!c) throw new AppError("err.memory", "canvas");
    c.fillStyle = "#ffffff";
    c.fillRect(0, 0, canvas.width, canvas.height);
    const boxW = canvas.width - margin * 2;
    const boxH = canvas.height - margin * 2;
    const s = Math.min(boxW / rotated.width, boxH / rotated.height);
    const dw = rotated.width * s;
    const dh = rotated.height * s;
    c.drawImage(rotated, margin + (boxW - dw) / 2, margin + (boxH - dh) / 2, dw, dh);
    pages.push(canvas);
    ctx.progress(((i + 1) / items.length) * 65);
  }
  const blob = await jpegPagesToPdf(pages, ptW, ptH, ctx);
  ctx.progress(100);
  return {
    blob,
    fileName: makeName(opts.name || "images", "pdf"),
    mime: "application/pdf",
    preview: "pdf",
    text: "",
    beforeBytes: items.reduce((s, it) => s + it.file.size, 0),
    afterBytes: blob.size,
  };
}

function fontFor(text: string, sizePx: number) {
  if (/[\u0600-\u06FF]/.test(text)) return `${sizePx}px "Geeza Pro", "Noto Naskh Arabic", "Arial", sans-serif`;
  if (/[\u4E00-\u9FFF]/.test(text)) return `${sizePx}px "PingFang SC", "Hiragino Sans GB", "Microsoft YaHei", "Noto Sans SC", sans-serif`;
  return `${sizePx}px Outfit, "Segoe UI", sans-serif`;
}

function wrapParagraph(ctx: CanvasRenderingContext2D, text: string, maxW: number) {
  const lines: string[] = [];
  const paragraphs = text.replace(/\r\n/g, "\n").split("\n");
  for (const para of paragraphs) {
    if (!para) {
      lines.push("");
      continue;
    }
    const tokens = /[\u4E00-\u9FFF]/.test(para) && !para.includes(" ") ? para.split("") : para.split(/(\s+)/);
    let line = "";
    for (const token of tokens) {
      const test = line + token;
      if (ctx.measureText(test).width > maxW && line) {
        lines.push(line.replace(/\s+$/, ""));
        line = token.trimStart();
        if (ctx.measureText(line).width > maxW) {
          let buf = "";
          for (const ch of line) {
            if (ctx.measureText(buf + ch).width > maxW && buf) {
              lines.push(buf);
              buf = ch;
            } else buf += ch;
          }
          line = buf;
        }
      } else line = test;
    }
    lines.push(line.replace(/\s+$/, ""));
  }
  return lines;
}

export async function textToPdf(
  text: string,
  opts: { format: PageFormat; orientation: Orientation; margin: MarginName; fontPt: number; title: string; name: string },
  ctx: RunCtx,
): Promise<TaskResult> {
  if (!text.trim()) throw new AppError("err.noText");
  const { w: ptW, h: ptH } = pageSize(opts.format, opts.orientation);
  const px = 2;
  const margin = MARGIN_PT[opts.margin === "none" ? "small" : opts.margin] * px;
  const pageW = Math.round(ptW * px);
  const pageH = Math.round(ptH * px);
  const fontPx = Math.round(opts.fontPt * px);
  const lineH = Math.round(fontPx * 1.45);
  const rtl = /[\u0600-\u06FF]/.test(text) && !/[A-Za-z]{4,}/.test(text);
  const measure = document.createElement("canvas").getContext("2d");
  if (!measure) throw new AppError("err.memory", "measure");
  measure.font = fontFor(text, fontPx);
  const lines = wrapParagraph(measure, text, pageW - margin * 2);
  const titlePx = Math.round(fontPx * 1.35);
  const pages: HTMLCanvasElement[] = [];
  let index = 0;
  let pageNo = 0;
  while (index < lines.length) {
    check(ctx);
    pageNo += 1;
    const canvas = document.createElement("canvas");
    canvas.width = pageW;
    canvas.height = pageH;
    const c = canvas.getContext("2d");
    if (!c) throw new AppError("err.memory", "page");
    c.fillStyle = "#fffdf9";
    c.fillRect(0, 0, pageW, pageH);
    c.fillStyle = "#1b1530";
    c.direction = rtl ? "rtl" : "ltr";
    c.textAlign = rtl ? "right" : "left";
    let y = margin + fontPx;
    if (pageNo === 1 && opts.title.trim()) {
      c.font = `800 ${titlePx}px Syne, Outfit, sans-serif`;
      c.fillText(opts.title.trim(), rtl ? pageW - margin : margin, y, pageW - margin * 2);
      y += titlePx + lineH * 0.6;
    }
    c.font = fontFor(text, fontPx);
    const maxY = pageH - margin - lineH;
    while (index < lines.length && y <= maxY) {
      const line = lines[index];
      if (line) c.fillText(line, rtl ? pageW - margin : margin, y, pageW - margin * 2);
      y += lineH;
      index += 1;
    }
    c.font = `${Math.round(11 * px)}px Outfit, sans-serif`;
    c.fillStyle = "#8a829c";
    c.textAlign = "center";
    c.direction = "ltr";
    c.fillText(String(pageNo), pageW / 2, pageH - margin * 0.45);
    pages.push(canvas);
    ctx.progress(Math.min(68, (index / lines.length) * 68));
    if (pageNo > 80) break;
  }
  const blob = await jpegPagesToPdf(pages, ptW, ptH, ctx);
  ctx.progress(100);
  return {
    blob,
    fileName: makeName(opts.name || opts.title || "texte", "pdf"),
    mime: "application/pdf",
    preview: "text",
    text,
    beforeBytes: new Blob([text]).size,
    afterBytes: blob.size,
  };
}

export async function searchablePdf(text: string, image: HTMLCanvasElement | null, name: string, ctx: RunCtx) {
  const textPdf = await textToPdf(text, { format: "a4", orientation: "portrait", margin: "normal", fontPt: 12, title: "", name }, ctx);
  if (!image) return textPdf.blob!;
  const pdf = await PDFDocument.load(await textPdf.blob!.arrayBuffer());
  const jpg = await canvasBlob(image, "image/jpeg", 0.82);
  const embedded = await pdf.embedJpg(await jpg.arrayBuffer());
  const page = pdf.insertPage(0, [595.28, 841.89]);
  const s = Math.min(595.28 / embedded.width, 841.89 / embedded.height);
  const dw = embedded.width * s;
  const dh = embedded.height * s;
  page.drawImage(embedded, { x: (595.28 - dw) / 2, y: (841.89 - dh) / 2, width: dw, height: dh });
  const bytes = await pdf.save();
  return new Blob([Uint8Array.from(bytes)], { type: "application/pdf" });
}

function floatTo16(input: Float32Array) {
  const out = new Int16Array(input.length);
  for (let i = 0; i < input.length; i++) {
    const s = Math.max(-1, Math.min(1, input[i]));
    out[i] = s < 0 ? s * 0x8000 : s * 0x7fff;
  }
  return out;
}

export function encodeWav(buffer: AudioBuffer) {
  const channels = Math.min(2, buffer.numberOfChannels);
  const rate = buffer.sampleRate;
  const frames = buffer.length;
  const block = channels * 2;
  const dataSize = frames * block;
  const ab = new ArrayBuffer(44 + dataSize);
  const view = new DataView(ab);
  const write = (offset: number, str: string) => {
    for (let i = 0; i < str.length; i++) view.setUint8(offset + i, str.charCodeAt(i));
  };
  write(0, "RIFF");
  view.setUint32(4, 36 + dataSize, true);
  write(8, "WAVE");
  write(12, "fmt ");
  view.setUint32(16, 16, true);
  view.setUint16(20, 1, true);
  view.setUint16(22, channels, true);
  view.setUint32(24, rate, true);
  view.setUint32(28, rate * block, true);
  view.setUint16(32, block, true);
  view.setUint16(34, 16, true);
  write(36, "data");
  view.setUint32(40, dataSize, true);
  const chans: Float32Array[] = [];
  for (let c = 0; c < channels; c++) chans.push(buffer.getChannelData(Math.min(c, buffer.numberOfChannels - 1)));
  let offset = 44;
  for (let i = 0; i < frames; i++) {
    for (let c = 0; c < channels; c++) {
      const s = Math.max(-1, Math.min(1, chans[c][i] || 0));
      view.setInt16(offset, s < 0 ? s * 0x8000 : s * 0x7fff, true);
      offset += 2;
    }
  }
  return new Blob([ab], { type: "audio/wav" });
}

export async function toStereo441(buffer: AudioBuffer) {
  if (buffer.sampleRate === 44100 && buffer.numberOfChannels === 2) return buffer;
  const length = Math.max(1, Math.ceil(buffer.duration * 44100));
  const off = new OfflineAudioContext(2, length, 44100);
  const src = off.createBufferSource();
  src.buffer = buffer;
  src.connect(off.destination);
  src.start(0);
  return off.startRendering();
}

export async function decodeFile(file: File, ctx?: RunCtx) {
  const audioCtx = new AudioContext();
  try {
    await audioCtx.resume();
    const raw = await file.arrayBuffer();
    ctx?.progress(20);
    const copy = raw.slice(0);
    try {
      return await audioCtx.decodeAudioData(copy);
    } catch {
      return await recordPlayback(file, ctx);
    }
  } finally {
    await audioCtx.close().catch(() => undefined);
  }
}

async function recordPlayback(file: File, ctx?: RunCtx) {
  const url = URL.createObjectURL(file);
  const media = document.createElement(file.type.startsWith("video") ? "video" : "audio");
  media.src = url;
  media.preload = "auto";
  if (media instanceof HTMLVideoElement) media.playsInline = true;
  await once(media, "loadedmetadata", 15000);
  const audioCtx = new AudioContext();
  await audioCtx.resume();
  const source = audioCtx.createMediaElementSource(media);
  const dest = audioCtx.createMediaStreamDestination();
  source.connect(dest);
  const mime = MediaRecorder.isTypeSupported("audio/webm;codecs=opus") ? "audio/webm;codecs=opus" : "audio/webm";
  if (typeof MediaRecorder === "undefined" || !MediaRecorder.isTypeSupported(mime)) {
    throw new AppError("err.decode", "no recorder");
  }
  const rec = new MediaRecorder(dest.stream, { mimeType: mime });
  const chunks: Blob[] = [];
  rec.ondataavailable = (e) => {
    if (e.data.size) chunks.push(e.data);
  };
  const stopped = new Promise<void>((resolve) => {
    rec.onstop = () => resolve();
  });
  try {
    await media.play();
  } catch {
    throw new AppError("err.gesture", "play");
  }
  rec.start(200);
  await new Promise<void>((resolve, reject) => {
    const timer = window.setInterval(() => {
      if (ctx?.signal.aborted) {
        media.pause();
        reject(abortError());
      } else if (media.duration) {
        ctx?.progress(Math.min(90, (media.currentTime / media.duration) * 90));
      }
    }, 250);
    media.onended = () => {
      window.clearInterval(timer);
      resolve();
    };
    ctx?.signal.addEventListener(
      "abort",
      () => {
        window.clearInterval(timer);
        media.pause();
        reject(abortError());
      },
      { once: true },
    );
  });
  if (rec.state !== "inactive") rec.stop();
  await stopped;
  URL.revokeObjectURL(url);
  const blob = new Blob(chunks, { type: mime });
  const again = new AudioContext();
  try {
    return await again.decodeAudioData(await blob.arrayBuffer());
  } finally {
    await again.close().catch(() => undefined);
    await audioCtx.close().catch(() => undefined);
  }
}

export function encodeMp3(buffer: AudioBuffer, kbps: number) {
  const channels = 2;
  const encoder = new Mp3Encoder(channels, buffer.sampleRate, kbps);
  const left = floatTo16(buffer.getChannelData(0));
  const right = floatTo16(buffer.getChannelData(Math.min(1, buffer.numberOfChannels - 1)));
  const parts: Uint8Array[] = [];
  const block = 1152;
  for (let i = 0; i < left.length; i += block) {
    const l = left.subarray(i, i + block);
    const r = right.subarray(i, i + block);
    const buf = encoder.encodeBuffer(l, r);
    if (buf.length) parts.push(buf);
  }
  const end = encoder.flush();
  if (end.length) parts.push(end);
  return new Blob(parts as BlobPart[], { type: "audio/mpeg" });
}

export async function concatAudio(buffers: AudioBuffer[]) {
  const stereo = await Promise.all(buffers.map((b) => toStereo441(b)));
  const length = stereo.reduce((s, b) => s + b.length, 0);
  const ctx = new AudioContext();
  const out = ctx.createBuffer(2, Math.max(1, length), 44100);
  let offset = 0;
  for (const b of stereo) {
    out.getChannelData(0).set(b.getChannelData(0), offset);
    out.getChannelData(1).set(b.getChannelData(1), offset);
    offset += b.length;
  }
  await ctx.close().catch(() => undefined);
  return out;
}

export async function audioFromFiles(files: File[], format: "mp3" | "wav" | "m4a", kbps: number, name: string, ctx: RunCtx): Promise<TaskResult> {
  if (!files.length) throw new AppError("err.empty");
  const decoded: AudioBuffer[] = [];
  for (let i = 0; i < files.length; i++) {
    check(ctx);
    decoded.push(await decodeFile(files[i], ctx));
    ctx.progress(((i + 1) / files.length) * 55);
  }
  const merged = decoded.length === 1 ? await toStereo441(decoded[0]) : await concatAudio(decoded);
  check(ctx);
  ctx.progress(75);
  let blob: Blob;
  let ext = format;
  let mime = format === "mp3" ? "audio/mpeg" : format === "wav" ? "audio/wav" : "audio/mp4";
  if (format === "mp3") blob = encodeMp3(merged, kbps);
  else if (format === "wav") blob = encodeWav(merged);
  else {
    const recorded = await bufferToM4a(merged, ctx);
    if (!recorded) {
      blob = encodeMp3(merged, kbps);
      ext = "mp3";
      mime = "audio/mpeg";
    } else blob = recorded;
  }
  ctx.progress(100);
  return {
    blob,
    fileName: makeName(name || "audio", ext),
    mime,
    preview: "audio",
    beforeBytes: files.reduce((s, f) => s + f.size, 0),
    afterBytes: blob.size,
  };
}

async function bufferToM4a(buffer: AudioBuffer, ctx: RunCtx) {
  const mime = ["audio/mp4", "audio/mp4;codecs=mp4a.40.2"].find((m) => typeof MediaRecorder !== "undefined" && MediaRecorder.isTypeSupported(m));
  if (!mime) return null;
  const audioCtx = new AudioContext();
  await audioCtx.resume();
  const dest = audioCtx.createMediaStreamDestination();
  const src = audioCtx.createBufferSource();
  src.buffer = buffer;
  src.connect(dest);
  const rec = new MediaRecorder(dest.stream, { mimeType: mime, audioBitsPerSecond: 128000 });
  const chunks: Blob[] = [];
  rec.ondataavailable = (e) => {
    if (e.data.size) chunks.push(e.data);
  };
  const stopped = new Promise<void>((resolve) => {
    rec.onstop = () => resolve();
  });
  rec.start(200);
  src.start(0);
  await new Promise<void>((resolve, reject) => {
    src.onended = () => resolve();
    ctx.signal.addEventListener("abort", () => reject(abortError()), { once: true });
  });
  if (rec.state !== "inactive") rec.stop();
  await stopped;
  await audioCtx.close().catch(() => undefined);
  return new Blob(chunks, { type: mime });
}

export function canRecord(mime: string) {
  return typeof MediaRecorder !== "undefined" && MediaRecorder.isTypeSupported(mime);
}

export function pickVideoMime(prefer: "mp4" | "webm") {
  const mp4 = ["video/mp4;codecs=avc1.42E01E,mp4a.40.2", "video/mp4"];
  const webm = ["video/webm;codecs=vp9,opus", "video/webm;codecs=vp8,opus", "video/webm"];
  const list = prefer === "mp4" ? mp4 : webm;
  for (const mime of list) if (canRecord(mime)) return { mime, ext: prefer };
  return null;
}

type DrawSource = HTMLVideoElement;

async function playThrough(
  file: File,
  draw: (video: HTMLVideoElement) => void,
  audioCtx: AudioContext,
  dest: MediaStreamAudioDestinationNode,
  ctx: RunCtx,
  onRatio: (ratio: number) => void,
) {
  const url = URL.createObjectURL(file);
  const video = document.createElement("video");
  video.src = url;
  video.playsInline = true;
  video.preload = "auto";
  video.muted = true;
  await once(video, "loadeddata", 20000);
  let bufferSource: AudioBufferSourceNode | null = null;
  let elementSource: MediaElementAudioSourceNode | null = null;
  try {
    video.muted = false;
    elementSource = audioCtx.createMediaElementSource(video);
    elementSource.connect(dest);
  } catch {
    elementSource = null;
    video.muted = true;
    if (file.size < 48_000_000) {
      try {
        const decoded = await audioCtx.decodeAudioData((await file.arrayBuffer()).slice(0));
        bufferSource = audioCtx.createBufferSource();
        bufferSource.buffer = decoded;
        bufferSource.connect(dest);
      } catch {
        bufferSource = null;
      }
    }
  }
  try {
    await audioCtx.resume();
    await video.play();
  } catch (e) {
    if (isAbort(e)) throw abortError();
    video.muted = true;
    try {
      await video.play();
    } catch (err) {
      URL.revokeObjectURL(url);
      if (isAbort(err)) throw abortError();
      throw new AppError("err.gesture", err instanceof Error ? err.message : "play");
    }
  }
  try {
    bufferSource?.start(0);
  } catch {
    /* already started */
  }
  await new Promise<void>((resolve, reject) => {
    let raf = 0;
    const stop = (err?: Error) => {
      cancelAnimationFrame(raf);
      video.pause();
      try {
        bufferSource?.stop();
      } catch {
        /* already stopped */
      }
      if (err) reject(err);
      else resolve();
    };
    const loop = () => {
      if (ctx.signal.aborted) {
        stop(abortError());
        return;
      }
      draw(video);
      const dur = video.duration || 0;
      if (dur) onRatio(Math.min(1, video.currentTime / dur));
      if (video.ended) {
        draw(video);
        stop();
        return;
      }
      raf = requestAnimationFrame(loop);
    };
    video.onended = () => stop();
    video.onerror = () => stop(new AppError("err.decode", "playback"));
    ctx.signal.addEventListener("abort", () => stop(abortError()), { once: true });
    loop();
  }).finally(() => {
    elementSource?.disconnect();
    bufferSource?.disconnect();
    video.src = "";
    URL.revokeObjectURL(url);
  });
}

function drawContain(ctx2d: CanvasRenderingContext2D, video: DrawSource, w: number, h: number) {
  ctx2d.fillStyle = "#000";
  ctx2d.fillRect(0, 0, w, h);
  const vw = video.videoWidth || w;
  const vh = video.videoHeight || h;
  const s = Math.min(w / vw, h / vh);
  const dw = vw * s;
  const dh = vh * s;
  ctx2d.drawImage(video, (w - dw) / 2, (h - dh) / 2, dw, dh);
}

async function recordCanvas(canvas: HTMLCanvasElement, audio: MediaStream, prefer: "mp4" | "webm", bitrate: number, run: (rec: MediaRecorder) => Promise<void>, ctx: RunCtx) {
  const chosen = pickVideoMime(prefer) || pickVideoMime(prefer === "mp4" ? "webm" : "mp4");
  if (!chosen) throw new AppError("err.unsupported", "MediaRecorder");
  const stream = new MediaStream([...canvas.captureStream(30).getVideoTracks(), ...audio.getAudioTracks()]);
  const rec = new MediaRecorder(stream, {
    mimeType: chosen.mime,
    videoBitsPerSecond: bitrate,
    audioBitsPerSecond: 128000,
  });
  const chunks: Blob[] = [];
  rec.ondataavailable = (e) => {
    if (e.data.size) chunks.push(e.data);
  };
  const stopped = new Promise<void>((resolve, reject) => {
    rec.onstop = () => resolve();
    rec.onerror = () => reject(new AppError("err.generic", "recorder"));
  });
  rec.start(250);
  try {
    await run(rec);
  } finally {
    if (rec.state !== "inactive") rec.stop();
  }
  await stopped;
  if (ctx.signal.aborted) throw abortError();
  const blob = new Blob(chunks, { type: chosen.mime });
  if (blob.size < 800) throw new AppError("err.generic", "empty video");
  return { blob, mime: chosen.mime, ext: chosen.ext };
}

export type CompressOpts = {
  preset: "space" | "low" | "standard" | "high" | "custom";
  format: "mp4" | "webm";
  maxW: number;
  bitrate: number;
  name: string;
};

const PRESET_MAP = {
  space: { maxW: 640, bitrate: 450000 },
  low: { maxW: 854, bitrate: 800000 },
  standard: { maxW: 1280, bitrate: 1600000 },
  high: { maxW: 1920, bitrate: 4000000 },
};

export async function compressVideo(file: File, opts: CompressOpts, ctx: RunCtx): Promise<TaskResult> {
  const meta = await probeVideo(file);
  const vw = meta.width || 1280;
  const vh = meta.height || 720;
  const preset = opts.preset === "custom" ? { maxW: opts.maxW, bitrate: opts.bitrate } : PRESET_MAP[opts.preset];
  const scale = Math.min(1, preset.maxW / vw);
  const w = even(vw * scale);
  const h = even(vh * scale);
  const canvas = document.createElement("canvas");
  canvas.width = w;
  canvas.height = h;
  const c2d = canvas.getContext("2d");
  if (!c2d) throw new AppError("err.memory", "canvas");
  const audioCtx = new AudioContext();
  await audioCtx.resume();
  const dest = audioCtx.createMediaStreamDestination();
  const origBps = meta.duration ? (file.size * 8) / meta.duration : 0;
  const videoBps = origBps ? Math.min(preset.bitrate, Math.max(200000, origBps * 0.85 - 128000)) : preset.bitrate;
  const recorded = await recordCanvas(canvas, dest.stream, opts.format, videoBps, async () => {
    await playThrough(file, (video) => drawContain(c2d, video, w, h), audioCtx, dest, ctx, (ratio) => ctx.progress(ratio * 100));
  }, ctx);
  await audioCtx.close().catch(() => undefined);
  ctx.progress(100);
  if (recorded.blob.size >= file.size * 0.97) {
    const ext = (file.name.split(".").pop() || "mp4").toLowerCase();
    return {
      blob: file,
      fileName: makeName(opts.name || file.name, ext),
      mime: file.type || "video/mp4",
      preview: "video",
      beforeBytes: file.size,
      afterBytes: file.size,
      noteKey: "note.nogain",
    };
  }
  return {
    blob: recorded.blob,
    fileName: makeName(opts.name || file.name, recorded.ext),
    mime: recorded.mime,
    preview: "video",
    beforeBytes: file.size,
    afterBytes: recorded.blob.size,
  };
}

export async function mergeVideos(files: File[], name: string, ctx: RunCtx): Promise<TaskResult> {
  if (files.length < 2) throw new AppError("err.empty");
  const metas: Awaited<ReturnType<typeof probeVideo>>[] = [];
  for (const f of files) metas.push(await probeVideo(f));
  const first = metas[0];
  let w = first.width || 1280;
  let h = first.height || 720;
  if (w > 1280) {
    h = (h * 1280) / w;
    w = 1280;
  }
  w = even(w);
  h = even(h);
  const canvas = document.createElement("canvas");
  canvas.width = w;
  canvas.height = h;
  const c2d = canvas.getContext("2d");
  if (!c2d) throw new AppError("err.memory", "canvas");
  c2d.fillStyle = "#000";
  c2d.fillRect(0, 0, w, h);
  const audioCtx = new AudioContext();
  await audioCtx.resume();
  const dest = audioCtx.createMediaStreamDestination();
  const total = metas.reduce((s, m) => s + (m.duration || 1), 0);
  let done = 0;
  const recorded = await recordCanvas(canvas, dest.stream, "mp4", 2000000, async () => {
    for (let i = 0; i < files.length; i++) {
      check(ctx);
      const dur = metas[i].duration || 1;
      await playThrough(
        files[i],
        (video) => drawContain(c2d, video, w, h),
        audioCtx,
        dest,
        ctx,
        (ratio) => ctx.progress(Math.min(99, ((done + ratio * dur) / total) * 100)),
      );
      done += dur;
    }
  }, ctx);
  await audioCtx.close().catch(() => undefined);
  ctx.progress(100);
  return {
    blob: recorded.blob,
    fileName: makeName(name || "fusion", recorded.ext),
    mime: recorded.mime,
    preview: "video",
    beforeBytes: files.reduce((s, f) => s + f.size, 0),
    afterBytes: recorded.blob.size,
  };
}

export function estimateVideo(duration: number, bitrate: number) {
  if (!duration || !Number.isFinite(duration)) return 0;
  return Math.round((duration * (bitrate + 128000)) / 8);
}
