import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";
import { firebaseConfig } from "../firebaseConfig";

export const authEnabled = Boolean(firebaseConfig.apiKey && firebaseConfig.projectId);
const fb = authEnabled ? initializeApp(firebaseConfig) : null;
export const auth = fb ? getAuth(fb) : null;
export const db = fb ? getFirestore(fb) : null;
