import type { Lang } from "../types";
import { Capacitor } from "@capacitor/core";
import { Directory, Filesystem } from "@capacitor/filesystem";
import { Share } from "@capacitor/share";
import { LocalNotifications } from "@capacitor/local-notifications";

export const isNative = () => Capacitor.isNativePlatform();

function blobToBase64(blob: Blob) {
  return new Promise<string>((resolve, reject) => {
    const r = new FileReader();
    r.onloadend = () => resolve(String(r.result).split(",")[1] || "");
    r.onerror = () => reject(r.error);
    r.readAsDataURL(blob);
  });
}

export type SaveStatus = "saved" | "shared" | "failed";
export const savedKeys = new Set<string>();

async function nativeSave(blob: Blob, name: string): Promise<SaveStatus> {
  const data = await blobToBase64(blob);
  try {
    await Filesystem.writeFile({ path: `AllTool/${name}`, data, directory: Directory.Documents, recursive: true });
    await Filesystem.stat({ path: `AllTool/${name}`, directory: Directory.Documents });
    return "saved";
  } catch {
    try {
      const tmp = await Filesystem.writeFile({ path: name, data, directory: Directory.Cache, recursive: true });
      await Share.share({ title: name, url: tmp.uri });
      return "shared";
    } catch {
      return "failed";
    }
  }
}

async function nativeShare(blob: Blob, name: string) {
  const data = await blobToBase64(blob);
  const tmp = await Filesystem.writeFile({ path: name, data, directory: Directory.Cache, recursive: true });
  await Share.share({ title: name, url: tmp.uri });
}

export async function requestNotifPermission(): Promise<NotificationPermission> {
  if (isNative()) {
    try {
      const r = await LocalNotifications.requestPermissions();
      return r.display === "granted" ? "granted" : "denied";
    } catch {
      return "denied";
    }
  }
  if (typeof Notification === "undefined") return "denied";
  return Notification.requestPermission();
}

export async function checkNotifPermission(): Promise<NotificationPermission | "unknown"> {
  if (isNative()) {
    try {
      const r = await LocalNotifications.checkPermissions();
      return r.display === "granted" ? "granted" : "default";
    } catch {
      return "unknown";
    }
  }
  return typeof Notification !== "undefined" ? Notification.permission : "unknown";
}


export class AppError extends Error {
  key: string;
  detail: string;
  constructor(key: string, detail?: string) {
    super(key);
    this.name = "AppError";
    this.key = key;
    this.detail = detail || key;
  }
}

export function abortError() {
  return new AppError("err.cancel", "aborted");
}

export function isAbort(e: unknown) {
  if (e instanceof AppError && e.key === "err.cancel") return true;
  if (e instanceof DOMException && e.name === "AbortError") return true;
  return e instanceof Error && e.name === "AbortError";
}

export function uid() {
  return Math.random().toString(36).slice(2, 10) + Date.now().toString(36).slice(-4);
}

export function localeOf(lang: Lang) {
  const map: Record<Lang, string> = {
    fr: "fr-FR",
    en: "en-GB",
    es: "es-ES",
    de: "de-DE",
    pt: "pt-PT",
    it: "it-IT",
    ar: "ar",
    zh: "zh-CN",
    sw: "sw-KE",
    ln: "fr-FR",
  };
  return map[lang];
}

export function formatBytes(n: number, lang: Lang) {
  const units = lang === "fr" || lang === "ln" ? ["o", "Ko", "Mo", "Go"] : ["B", "KB", "MB", "GB"];
  let i = 0;
  let v = Math.max(0, n);
  while (v >= 1024 && i < units.length - 1) {
    v /= 1024;
    i += 1;
  }
  const digits = v < 10 && i > 0 ? 1 : 0;
  const num = new Intl.NumberFormat(localeOf(lang), { maximumFractionDigits: digits }).format(v);
  return `${num} ${units[i]}`;
}

export function formatWhen(ts: number, lang: Lang) {
  try {
    return new Intl.DateTimeFormat(localeOf(lang), {
      day: "numeric",
      month: "short",
      hour: "2-digit",
      minute: "2-digit",
    }).format(ts);
  } catch {
    return new Date(ts).toLocaleString();
  }
}

export function formatDate(ts: number, lang: Lang) {
  try {
    return new Intl.DateTimeFormat(localeOf(lang), {
      weekday: "long",
      day: "numeric",
      month: "long",
    }).format(ts);
  } catch {
    return new Date(ts).toDateString();
  }
}

export function formatClock(seconds: number) {
  if (!Number.isFinite(seconds) || seconds < 0) return "";
  const s = Math.round(seconds);
  const m = Math.floor(s / 60);
  const r = s % 60;
  return `${m}:${String(r).padStart(2, "0")}`;
}

export function makeName(label: string, ext: string, custom?: string) {
  const raw = (custom || label).trim() || label;
  const clean = raw
    .replace(/\.[a-z0-9]{2,5}$/i, "")
    .replace(/[^\p{L}\p{N}._-]+/gu, "_")
    .replace(/_+/g, "_")
    .replace(/^_|_$/g, "")
    .slice(0, 48) || "fichier";
  const d = new Date();
  const p = (n: number) => String(n).padStart(2, "0");
  const stamp = `${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}_${p(d.getHours())}${p(d.getMinutes())}`;
  return `AllTool_${clean}_${stamp}.${ext.replace(/^\./, "")}`;
}

export function sleep(ms: number, signal?: AbortSignal) {
  return new Promise<void>((resolve, reject) => {
    const finish = () => {
      window.clearTimeout(t);
      signal?.removeEventListener("abort", onAbort);
      resolve();
    };
    const onAbort = () => {
      window.clearTimeout(t);
      reject(abortError());
    };
    const t = window.setTimeout(finish, ms);
    if (signal?.aborted) onAbort();
    else signal?.addEventListener("abort", onAbort, { once: true });
  });
}

export function yieldThread() {
  return new Promise((r) => setTimeout(r, 0));
}

export function even(n: number) {
  return Math.max(2, Math.round(n / 2) * 2);
}

export function saveBlob(blob: Blob, name: string): Promise<SaveStatus> {
  if (isNative()) return nativeSave(blob, name);
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  a.rel = "noopener";
  document.body.appendChild(a);
  a.click();
  a.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 4000);
  return Promise.resolve("saved");
}

export async function shareBlob(blob: Blob, name: string, title: string) {
  if (isNative()) {
    await nativeShare(blob, name);
    return "shared" as const;
  }
  const file = new File([blob], name, { type: blob.type || "application/octet-stream" });
  const nav = navigator as Navigator & { canShare?: (data: ShareData) => boolean };
  if (nav.share && nav.canShare?.({ files: [file] })) {
    await nav.share({ files: [file], title });
    return "shared" as const;
  }
  void saveBlob(blob, name);
  return "saved" as const;
}

export function notify(title: string, body: string, tag: string) {
  if (isNative()) {
    let id = 0;
    for (let i = 0; i < tag.length; i++) id = (id * 31 + tag.charCodeAt(i)) % 1000000;
    void LocalNotifications.schedule({ notifications: [{ id: id + 1, title, body }] }).catch(() => undefined);
    return;
  }
  if (typeof Notification === "undefined" || Notification.permission !== "granted") return;
  try {
    new Notification(title, { body, tag, silent: tag.includes("progress") });
  } catch {
    /* some browsers reject outside a gesture */
  }
}

export function normalizeUrl(input: string) {
  const u = input.trim();
  if (!u) return "";
  if (/^https?:\/\//i.test(u)) return u;
  return `https://${u}`;
}

export function extOf(name: string, fallback = "bin") {
  const m = name.toLowerCase().match(/\.([a-z0-9]{2,5})$/);
  return m ? m[1] : fallback;
}

export function guessMime(nameOrUrl: string) {
  const ext = extOf(nameOrUrl.split("?")[0], "");
  const map: Record<string, string> = {
    mp4: "video/mp4",
    webm: "video/webm",
    mov: "video/quicktime",
    mkv: "video/x-matroska",
    m4v: "video/mp4",
    mp3: "audio/mpeg",
    wav: "audio/wav",
    m4a: "audio/mp4",
    opus: "audio/ogg",
    ogg: "audio/ogg",
    jpg: "image/jpeg",
    jpeg: "image/jpeg",
    png: "image/png",
    webp: "image/webp",
    pdf: "application/pdf",
    txt: "text/plain",
    srt: "application/x-subrip",
  };
  return map[ext] || "application/octet-stream";
}

const DB = "alltool";
const STORE = "files";

function openDb() {
  return new Promise<IDBDatabase>((resolve, reject) => {
    const req = indexedDB.open(DB, 1);
    req.onupgradeneeded = () => {
      if (!req.result.objectStoreNames.contains(STORE)) req.result.createObjectStore(STORE);
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

export async function idbSet(id: string, value: unknown) {
  try {
    const db = await openDb();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(STORE, "readwrite");
      tx.objectStore(STORE).put(value, id);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
    db.close();
  } catch {
    /* quota or private mode */
  }
}

export async function idbGet<T>(id: string): Promise<T | undefined> {
  try {
    const db = await openDb();
    const value = await new Promise<T | undefined>((resolve, reject) => {
      const tx = db.transaction(STORE, "readonly");
      const req = tx.objectStore(STORE).get(id);
      req.onsuccess = () => resolve(req.result as T | undefined);
      req.onerror = () => reject(req.error);
    });
    db.close();
    return value;
  } catch {
    return undefined;
  }
}

export async function idbClear() {
  try {
    const db = await openDb();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(STORE, "readwrite");
      tx.objectStore(STORE).clear();
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
    db.close();
  } catch {
    /* ignore */
  }
}

export function srtTime(sec: number) {
  const ms = Math.max(0, Math.round(sec * 1000));
  const h = Math.floor(ms / 3600000);
  const m = Math.floor((ms % 3600000) / 60000);
  const s = Math.floor((ms % 60000) / 1000);
  const r = ms % 1000;
  const p = (n: number, l = 2) => String(n).padStart(l, "0");
  return `${p(h)}:${p(m)}:${p(s)},${p(r, 3)}`;
}

export function toSrt(cues: { start: number; end: number; text: string }[]) {
  return cues
    .filter((c) => c.text.trim())
    .map((c, i) => `${i + 1}\n${srtTime(c.start)} --> ${srtTime(c.end)}\n${c.text.trim()}\n`)
    .join("\n");
}
