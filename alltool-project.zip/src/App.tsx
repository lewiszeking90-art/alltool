import { Component, useEffect } from "react";
import type { ErrorInfo, ReactNode } from "react";
import { AppProvider, useApp } from "./store";
import { Shell } from "./components/shell";
import { Home } from "./pages/home";
import { BrowserPage } from "./pages/browser";
import { FavoritesPage, HistoryPage, QueuePage } from "./pages/lists";
import { ErrorsPage, PremiumPage, PrivacyPage, SettingsPage } from "./pages/settings";
import { ToolScreen } from "./pages/tools";
import { Icon } from "./components/ui";
import { AuthProvider, useAuth } from "./auth";
import { AuthScreen } from "./pages/auth";
import { TrialModals } from "./components/paywall";

class Boundary extends Component<{ resetKey: string; children: ReactNode }, { error: Error | null }> {
  state = { error: null as Error | null };
  static getDerivedStateFromError(error: Error) {
    return { error };
  }
  componentDidCatch(error: Error, info: ErrorInfo) {
    console.error(error, info);
  }
  componentDidUpdate(prev: { resetKey: string }) {
    if (prev.resetKey !== this.props.resetKey && this.state.error) this.setState({ error: null });
  }
  render() {
    if (this.state.error) return <Crash detail={this.state.error.message} />;
    return this.props.children;
  }
}

function Crash({ detail }: { detail: string }) {
  const app = useApp();
  return (
    <div className="solid hairline mx-auto max-w-md rounded-[28px] p-6 text-center">
      <Icon name="alert" className="mx-auto mb-3 h-8 w-8 text-rose-500" />
      <p className="font-semibold">{app.t("err.generic")}</p>
      <button type="button" className="brand-btn mt-4 h-11 rounded-2xl px-4 text-sm font-semibold" onClick={() => app.go({ name: "home" })}>
        {app.t("nav.home")}
      </button>
      <p className="sr-only">{detail}</p>
    </div>
  );
}

function Screen() {
  const app = useApp();
  const key = app.view.name === "tool" ? app.view.tool : app.view.name;
  let body: ReactNode = <Home />;
  if (app.view.name === "browser") body = <BrowserPage />;
  else if (app.view.name === "favorites") body = <FavoritesPage />;
  else if (app.view.name === "history") body = <HistoryPage />;
  else if (app.view.name === "queue") body = <QueuePage />;
  else if (app.view.name === "settings") body = <SettingsPage />;
  else if (app.view.name === "errors") body = <ErrorsPage />;
  else if (app.view.name === "privacy") body = <PrivacyPage />;
  else if (app.view.name === "premium") body = <PremiumPage />;
  else if (app.view.name === "tool") body = <ToolScreen id={app.view.tool} />;
  return <Boundary resetKey={key}>{body}</Boundary>;
}

function Gate() {
  const auth = useAuth();
  const app = useApp();
  useEffect(() => {
    if (auth.user?.name && auth.user.name !== app.name) app.setName(auth.user.name);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [auth.user?.name]);
  useEffect(() => {
    app.setPremium(auth.premium.active);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [auth.premium.active]);
  useEffect(() => {
    if (auth.remoteUsage) app.mergeUsage(auth.remoteUsage);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [auth.remoteUsage]);
  useEffect(() => {
    if (auth.user) auth.pushUsage(app.usage);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [app.usage, auth.user?.uid]);
  if (auth.enabled && auth.loading) return <div className="grid min-h-dvh place-items-center text-sm opacity-60">AllTool…</div>;
  if (auth.enabled && !auth.user) return <AuthScreen />;
  return (
    <Shell>
      <Screen />
      <TrialModals />
    </Shell>
  );
}

export default function App() {
  return (
    <AppProvider>
      <AuthProvider>
        <Gate />
      </AuthProvider>
    </AppProvider>
  );
}
