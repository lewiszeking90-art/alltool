import {App} from '@capacitor/app';
import {Filesystem,Directory} from '@capacitor/filesystem';
import {Share} from '@capacitor/share';
import {t,setLang,lang,LANGS} from './i18n.js';
import {signUpOrIn,onUser,loadProfile,saveUsage,auth} from './firebase.js';
import {TOOLS} from './tools.js';
let user=null,prof={name:'',premium:false,usage:{}},screen='home',lastBack=0;
const $=s=>document.querySelector(s),root=$('#app');
const toast=m=>{const e=$('#toast');e.textContent=m;e.style.display='block';setTimeout(()=>e.style.display='none',2500)};
const left=id=>prof.premium?'∞':Math.max(0,3-(prof.usage[id]||0));
const modal=h=>{const m=document.createElement('div');m.className='modal';m.innerHTML='<div>'+h+'</div>';document.body.appendChild(m);return m};
const tasks=[];
function home(){screen='home';
  root.innerHTML=`<header><b>AllTool</b><span>${user?prof.name:''}</span><select id=lg style="width:auto">${LANGS.map(l=>`<option ${l==lang()?'selected':''}>${l}</option>`).join('')}</select></header>
  <main><div class=grid>${TOOLS.map(x=>`<button class=card data-id=${x.id}><b>${x.icon}</b>${x.name}<br><small>${t('left')(left(x.id))}</small></button>`).join('')}</div>
  <h3>${t('tasks')}</h3><div id=tl></div></main>`;
  $('#lg').onchange=e=>{setLang(e.target.value);home()};
  root.querySelectorAll('.card').forEach(b=>b.onclick=()=>open(b.dataset.id));drawTasks()}
function drawTasks(){const e=$('#tl');if(e)e.innerHTML=tasks.map(k=>`<div class=box style="margin:6px 0">${k.tool.icon} ${k.tool.name}<progress value=${k.p} max=1></progress><small>${k.msg||''}</small></div>`).join('')}
async function gate(id){
  if(!user){await new Promise(res=>{const m=modal(`<input id=n placeholder="${t('name')}"><input id=e type=email placeholder="${t('email')}"><input id=p type=password placeholder="${t('pass')}"><small id=er></small><button class=p id=go>${t('go')}</button>`);
    m.querySelector('#go').onclick=async()=>{try{user=await signUpOrIn(m.querySelector('#n').value.trim(),m.querySelector('#e').value.trim(),m.querySelector('#p').value);prof=await loadProfile(user);m.remove();res()}catch(x){m.querySelector('#er').textContent=x.code||x.message}}})}
  if(!user)return false;
  if(!prof.premium&&(prof.usage[id]||0)>=3){const m=modal(`<h3>${t('premium')}</h3><p>${t('lim')}</p><button class=p id=ok>${t('ok')}</button>`);m.querySelector('#ok').onclick=()=>m.remove();return false}
  return true}
async function open(id){
  const tool=TOOLS.find(x=>x.id===id);if(!(await gate(id)))return;screen='tool';
  const lg=['fr','en','es','de','pt','it','ar','zh','sw'];
  root.innerHTML=`<header><b>${tool.icon} ${tool.name}</b><small>${t('left')(left(id))}</small></header><main>
  ${tool.inputs.map(i=>i.type=='file'?`<input type=file id=${i.k} accept="${i.accept}" ${i.multiple?'multiple':''}>`:i.type=='lang'?`<small>${t('fr')}</small><select id=${i.k}>${lg.map(l=>`<option>${l}</option>`).join('')}</select>`:i.type=='server'?`<small>${t('srv')}</small><input id=${i.k} value="${localStorage.srv||''}" placeholder="http://IP:8080">`:`<textarea id=${i.k} rows=5 placeholder="${i.type=='link'?t('link'):t('text')}"></textarea>`).join('')}
  <button class=p id=run>${t('run')}</button><div id=out></div></main>`;
  $('#run').onclick=()=>start(tool)}
function start(tool){
  const vals={};for(const i of tool.inputs){const e=$('#'+i.k);vals[i.k]=i.type=='file'?[...e.files]:e.value;if(i.type=='server')localStorage.srv=e.value}
  const ctl=new AbortController();let last=Date.now();
  const k={tool,p:0,msg:'',ctl};tasks.push(k);
  const c={signal:ctl.signal,progress:v=>{k.p=v;last=Date.now();drawTasks()},touch:()=>last=Date.now(),check:()=>{if(ctl.signal.aborted)throw new Error(t('cancelled'))}};
  const wd=setInterval(()=>{if(Date.now()-last>120000){ctl.abort();k.msg=t('stuck');toast(k.msg)}},5000);
  const out=$('#out');out.innerHTML=`<button id=cx>${t('cancel')}</button>`;$('#cx').onclick=()=>{ctl.abort();k.msg=t('cancelled')};
  tool.run(vals,c,lang()).then(async r=>{
    if(ctl.signal.aborted)return;
    prof.usage[tool.id]=(prof.usage[tool.id]||0)+1;if(!prof.premium)saveUsage(auth.currentUser,prof.usage).catch(()=>{});
    k.p=1;k.msg='✓';
    if(!$('#out'))return;
    if(r&&r.text)$('#out').innerHTML=`<div class=box>${r.text.replace(/</g,'&lt;')}</div>`;
    else if(r&&r.blob)result(r);else $('#out').innerHTML='✓'
  }).catch(e=>{k.msg=e.name==='AbortError'?t('cancelled'):e.message;if($('#out'))$('#out').textContent=k.msg}).finally(()=>{clearInterval(wd);setTimeout(()=>{tasks.splice(tasks.indexOf(k),1);drawTasks()},4000)})}
function b64(blob){return new Promise(r=>{const f=new FileReader();f.onload=()=>r(f.result.split(',')[1]);f.readAsDataURL(blob)})}
function result(r){let uri=null;
  $('#out').innerHTML=`<button class=p id=sv>${t('save')}</button><button id=sh>${t('share')}</button>`;
  const persist=async()=>{if(uri)return false;const n=Date.now()+'_'+r.name;
    const w=await Filesystem.writeFile({path:'AllTool/'+n,data:await b64(r.blob),directory:Directory.Documents,recursive:true});uri=w.uri;return true};
  $('#sv').onclick=async()=>{try{toast(await persist()?`${r.label} ${t('saved')}`:`${r.label} ${t('already')}`)}catch(e){toast(e.message)}};
  $('#sh').onclick=async()=>{try{await persist();await Share.share({url:uri})}catch(e){}}}
App.addListener('backButton',()=>{if(screen!=='home')return home();
  if(Date.now()-lastBack<2000)return App.exitApp();lastBack=Date.now();toast(t('quit'))});
setLang(lang());home();
onUser(async u=>{user=u;if(u){prof=await loadProfile(u).catch(()=>prof);if(screen==='home')home()}});
if(!localStorage.seen){localStorage.seen=1;const m=modal(`<p>${t('welcome')}</p><button class=p id=ok>${t('ok')}</button>`);m.querySelector('#ok').onclick=()=>m.remove()}
