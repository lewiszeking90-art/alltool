# AllTool – instructions (téléphone uniquement)
1. Sur github.com (navigateur mobile, mode « Version pour ordinateur »), crée un dépôt privé « alltool ».
2. Envoie TOUS les fichiers de ce projet (Add file → Upload files), y compris le dossier .github (si le dossier est refusé : Add file → Create new file, nom `.github/workflows/build-apk.yml`, colle le contenu).
3. Onglet Actions → « Build APK » → Run workflow. Attends ~8 min.
4. Ouvre l'exécution terminée → Artifacts → AllTool-apk → télécharge, décompresse, installe l'APK (autorise les sources inconnues).
5. Firebase (console.firebase.google.com, projet alltool-1a8e6) : Authentication → active E-mail/Mot de passe ; Firestore → Règles → colle `firestore.rules` → Publier.
6. Serveur vidéo (Oracle Cloud, Ubuntu) : `sudo apt update && sudo apt install -y nodejs ffmpeg python3-pip && sudo pip3 install -U yt-dlp --break-system-packages` ; copie `server/server.js` ; `PORT=8080 node server.js` ; ouvre le port 8080 dans la liste de sécurité Oracle ET `sudo iptables -I INPUT -p tcp --dport 8080 -j ACCEPT`. Dans l'app : outil vidéo → champ « URL du serveur » (http://IP:8080).
7. Premium : plus tard, un serveur (Cloud Function + webhook Flutterwave) mettra `premium:true` via le SDK admin ; les règles empêchent déjà l'utilisateur de le faire.
