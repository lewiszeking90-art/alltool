# AllTool — Boîte à Outils Android Tout-en-Un

Bienvenue Brayan ! Voici le code source Android complet de l'application **AllTool**.

## Compilation Automatique sur GitHub Actions (depuis votre téléphone)

1. Connectez-vous sur votre compte GitHub **lewiszeking90-art** dans Chrome sur votre téléphone.
2. Créez un nouveau dépôt public ou privé nommé `alltool`.
3. Cliquez sur **Add file** > **Upload files**, déposez ce fichier ZIP à la racine et validez (**Commit changes**).
4. Allez dans l'onglet **Actions**, sélectionnez le workflow **Build AllTool Android APK** et cliquez sur **Run workflow**.
5. Attendez 2 à 3 minutes que le run devienne **VERT**.
6. Cliquez sur le run, descendez en bas de page dans la section **Artifacts**, et téléchargez **AllTool-v1.0.0-Debug-APK.zip**.
7. Extrayez le ZIP téléchargé et installez `app-debug.apk` sur votre téléphone !
