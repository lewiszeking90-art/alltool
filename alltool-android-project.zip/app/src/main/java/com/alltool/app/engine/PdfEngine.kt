package com.alltool.app.engine

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import java.io.File
import java.io.FileOutputStream

object PdfEngine {

    /**
     * Converts a list of Bitmaps into a single A4 PDF document
     */
    fun imagesToPdf(context: Context, bitmaps: List<Bitmap>, outputFile: File): Boolean {
        val pdfDocument = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create() // A4 at 72dpi

        try {
            bitmaps.forEachIndexed { index, bitmap ->
                val page = pdfDocument.startPage(PdfDocument.PageInfo.Builder(595, 842, index + 1).create())
                val canvas: Canvas = page.canvas
                val paint = Paint(Paint.FILTER_BITMAP_FLAG)

                // Scale bitmap to fit page
                val scaled = Bitmap.createScaledBitmap(bitmap, 595, 842, true)
                canvas.drawBitmap(scaled, 0f, 0f, paint)
                pdfDocument.finishPage(page)
            }

            FileOutputStream(outputFile).use { out ->
                pdfDocument.writeTo(out)
            }
            return true
        } catch (e: Exception) {
            e.printStackTrace()
            return false
        } finally {
            pdfDocument.close()
        }
    }
}
