package com.alltool.app

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build

class AllToolApplication : Application() {

    companion object {
        const val CHANNEL_PROCESSING_ID = "alltool_processing_channel"
        const val CHANNEL_DOWNLOAD_ID = "alltool_download_channel"
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = getSystemService(NotificationManager::class.java)

            val processingChannel = NotificationChannel(
                CHANNEL_PROCESSING_ID,
                "Traitements AllTool",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Notifications de progression pour la vidéo, l'audio et les PDF"
            }

            val downloadChannel = NotificationChannel(
                CHANNEL_DOWNLOAD_ID,
                "Téléchargements AllTool",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Notifications d'état et fin de téléchargement"
            }

            notificationManager.createNotificationChannel(processingChannel)
            notificationManager.createNotificationChannel(downloadChannel)
        }
    }
}
