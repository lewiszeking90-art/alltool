package com.alltool.app.services

import android.app.Notification
import android.app.Service
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.alltool.app.AllToolApplication
import com.alltool.app.R

class MediaProcessingService : Service() {

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val taskName = intent?.getStringExtra("task_name") ?: "Traitement AllTool"

        val notification: Notification = NotificationCompat.Builder(this, AllToolApplication.CHANNEL_PROCESSING_ID)
            .setContentTitle(taskName)
            .setContentText("Opération en cours d'exécution...")
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setProgress(100, 0, true)
            .setOngoing(true)
            .build()

        startForeground(101, notification)
        return START_NOT_STICKY
    }
}
