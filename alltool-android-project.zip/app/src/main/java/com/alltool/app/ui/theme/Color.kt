package com.alltool.app.ui.theme

import androidx.compose.ui.graphics.Color

val IndigoPrimary = Color(0xFF4F46E5)
val PurpleAccent = Color(0xFF7C3AED)
val DarkBackground = Color(0xFF0F172A)
val DarkSurface = Color(0xFF1E293B)
val LightText = Color(0xFFF8FAFC)
val SubtitleText = Color(0xFF94A3B8)
